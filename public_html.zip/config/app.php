<?php
return [
  'timezone' => 'UTC+8',
  'app_name' => 'Payroll System',
  'company_start_time' => '10:00:00',
  'qr_valid_minutes' => 60
];
