<?php
// staff/salary.php
session_start();
require_once '../config/db.php';

// Check Login
if (!isset($_SESSION['employee_id'])) {
    header("Location: ../index.php");
    exit;
}

$emp_id = $_SESSION['employee_id'];

// --- FILTER LOGIC ---
$yearFilter = $_GET['year'] ?? date('Y');
$monthFilter = $_GET['month'] ?? 'all'; // Default to showing all months

// 1. Fetch available years for dropdown (Dynamic)
$yearStmt = $conn->prepare("SELECT DISTINCT YEAR(month_year) as y FROM payslips WHERE employee_id = ? ORDER BY y DESC");
$yearStmt->execute([$emp_id]);
$years = $yearStmt->fetchAll(PDO::FETCH_COLUMN);

// Ensure current year is always in the list
if(!in_array(date('Y'), $years)) array_unshift($years, date('Y'));

// 2. Build Query based on filters
$sql = "SELECT * FROM payslips WHERE employee_id = ? AND YEAR(month_year) = ?";
$params = [$emp_id, $yearFilter];

if ($monthFilter !== 'all') {
    $sql .= " AND MONTH(month_year) = ?";
    $params[] = $monthFilter;
}

$sql .= " ORDER BY month_year DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$payslips = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Helper: Month Names
$months = [
    1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
    5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
    9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Salary</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen pb-24">

    <?php include 'includes/header.php'; ?>

    <div class="max-w-4xl mx-auto p-4 md:p-6">
        
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
            <div>
                <h1 class="text-2xl font-bold text-gray-800">Salary & Payslips</h1>
                <p class="text-sm text-gray-500">
                    Showing: <span class="font-semibold text-blue-600">
                        <?= $monthFilter === 'all' ? 'All Months' : $months[$monthFilter] ?> <?= $yearFilter ?>
                    </span>
                </p>
            </div>

            <form method="GET" class="flex gap-2 bg-white p-1 rounded-lg shadow-sm border border-gray-200">
                
                <select name="month" onchange="this.form.submit()" class="bg-transparent text-sm font-semibold text-gray-700 py-2 px-3 rounded hover:bg-gray-50 outline-none cursor-pointer border-r border-gray-100">
                    <option value="all" <?= $monthFilter == 'all' ? 'selected' : '' ?>>All Months</option>
                    <?php foreach($months as $num => $name): ?>
                        <option value="<?= $num ?>" <?= $monthFilter == $num ? 'selected' : '' ?>><?= $name ?></option>
                    <?php endforeach; ?>
                </select>

                <select name="year" onchange="this.form.submit()" class="bg-transparent text-sm font-semibold text-gray-700 py-2 px-3 rounded hover:bg-gray-50 outline-none cursor-pointer">
                    <?php foreach($years as $y): ?>
                        <option value="<?= $y ?>" <?= $y == $yearFilter ? 'selected' : '' ?>><?= $y ?></option>
                    <?php endforeach; ?>
                </select>

            </form>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            <?php foreach ($payslips as $slip): 
                $dateObj = DateTime::createFromFormat('Y-m', $slip['month_year']);
                $fullDate = $dateObj->format('F Y');
                
                // Calculate Deductions
                $total_deductions = $slip['gross_salary'] - $slip['net_salary'];
            ?>
            
            <div class="bg-white rounded-xl shadow-sm hover:shadow-md transition border border-gray-100 overflow-hidden group">
                <div class="p-6">
                    <div class="flex justify-between items-start mb-4">
                        <div>
                            <span class="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded uppercase tracking-wider">
                                <?= $fullDate ?>
                            </span>
                            <div class="text-xs text-gray-400 mt-2">Generated: <?= date('d M Y', strtotime($slip['generated_at'])) ?></div>
                        </div>
                        <div class="text-right">
                            <div class="text-sm text-gray-500">Net Pay</div>
                            <div class="text-2xl font-bold text-gray-800">RM <?= number_format($slip['net_salary'], 2) ?></div>
                        </div>
                    </div>

                    <div class="border-t border-dashed border-gray-200 my-4"></div>

                    <div class="flex justify-between items-center text-sm mb-6">
                        <div class="text-gray-500">
                            Gross: <span class="font-semibold text-gray-700">RM <?= number_format($slip['gross_salary'], 2) ?></span>
                        </div>
                        <div class="text-red-500">
                            Deductions: <span class="font-semibold">-RM <?= number_format($total_deductions, 2) ?></span>
                        </div>
                    </div>

                    <a href="download_payslip.php?id=<?= $slip['id'] ?>" target="_blank" 
                       class="block w-full text-center bg-gray-50 hover:bg-blue-600 hover:text-white text-blue-600 font-bold py-3 rounded-lg transition duration-200 flex items-center justify-center gap-2 border border-blue-100 group-hover:border-blue-600">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                        Download PDF Payslip
                    </a>
                </div>
            </div>
            <?php endforeach; ?>

        </div>

        <?php if (empty($payslips)): ?>
            <div class="text-center py-16 bg-white rounded-xl shadow-sm border border-gray-100">
                <div class="bg-gray-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg class="w-10 h-10 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 14l6-6m-5.5.5h.01m4.99 5h.01M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16l3.5-2 3.5 2 3.5-2 3.5 2zM10 8.5a.5.5 0 11-1 0 .5.5 0 011 0zm5 5a.5.5 0 11-1 0 .5.5 0 011 0z"></path></svg>
                </div>
                <h3 class="text-lg font-bold text-gray-800">No Records Found</h3>
                <p class="text-gray-500 text-sm mt-1">
                    No payslips found for 
                    <?= $monthFilter === 'all' ? 'the year' : $months[$monthFilter] ?> 
                    <?= $yearFilter ?>.
                </p>
            </div>
        <?php endif; ?>

    </div>
</body>
</html>