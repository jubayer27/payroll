<?php
// staff/api_submit_request.php
ini_set('display_errors', 0);
error_reporting(E_ALL);

session_start();
require_once '../config/db.php';
header('Content-Type: application/json');

function sendJson($status, $message) {
    echo json_encode(['status' => $status, 'message' => $message]);
    exit;
}

// 1. Session Check (Flexible for Admin testing)
$empId = $_SESSION['user_id'] ?? $_SESSION['employee_id'] ?? null;
if (!$empId) {
    sendJson('error', 'Not logged in');
}

// 2. Validate Inputs
$type = $_POST['type'] ?? '';
$reason = trim($_POST['reason'] ?? '');

if (!$type || !$reason) sendJson('error', 'Type and Reason are required');

$requestData = [];

// 3. Build Data Array
if ($type === 'leave') {
    if (empty($_POST['from_date']) || empty($_POST['to_date'])) sendJson('error', 'Dates missing');
    $requestData = [
        'leave_type' => $_POST['leave_type'],
        'from_date' => $_POST['from_date'],
        'to_date' => $_POST['to_date']
    ];

} elseif ($type === 'attendance_correction') {
    if (empty($_POST['date']) || empty($_POST['time'])) sendJson('error', 'Date/Time missing');
    $requestData = [
        'date' => $_POST['date'],
        'time' => $_POST['time'],
        'scan_type' => $_POST['scan_type']
    ];

} elseif ($type === 'schedule_switch') {
    if (empty($_POST['work_date']) && empty($_POST['off_date'])) sendJson('error', 'Select dates');
    $requestData = [
        'work_date' => $_POST['work_date'],
        'off_date' => $_POST['off_date']
    ];

} elseif ($type === 'part_time_change') {
    $requestData = [
        'days' => $_POST['days'] ?? [],
        'pt_start' => $_POST['pt_start'],
        'pt_end' => $_POST['pt_end']
    ];
}

// 4. Save to DB
try {
    $stmt = $conn->prepare("INSERT INTO requests (employee_id, type, request_data, reason, status) VALUES (?, ?, ?, ?, 'pending')");
    
    // Use Safe JSON Encode
    $json = json_encode($requestData, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
    
    $stmt->execute([$empId, $type, $json, $reason]);
    
    sendJson('success', 'Request submitted!');

} catch (PDOException $e) {
    sendJson('error', 'DB Error: ' . $e->getMessage());
}
?>