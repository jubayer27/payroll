<?php
// staff/scan_attendance.php
header('Content-Type: application/json');

// 1. Set PHP Timezone FIRST
date_default_timezone_set('Asia/Kuala_Lumpur');

// 2. Database Connection
require_once '../config/db.php'; 

// Receive POST Data
$employee_id = $_POST['employee_id'] ?? null;
$token       = $_POST['token'] ?? null;
$type        = $_POST['type'] ?? null; 
$device_info = $_POST['device_info'] ?? 'Unknown Device';
$ip_address  = $_SERVER['REMOTE_ADDR'];

if (!$employee_id || !$token || !$type) {
    echo json_encode(['status' => 'error', 'message' => 'Missing required fields']);
    exit;
}

try {
    // 3. Validate Token
    $stmt = $conn->prepare("SELECT id FROM qr_tokens WHERE token = ? AND valid_until > NOW()");
    $stmt->execute([$token]);
    $validToken = $stmt->fetch();

    if (!$validToken) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid or expired QR Code']);
        exit;
    }

    // 4. Capture Current PHP Time (Kuala Lumpur)
    $current_timestamp = date('Y-m-d H:i:s'); // e.g., 2023-10-27 14:30:00
    $today_date = date('Y-m-d');
    $current_time_only = date('H:i:s');

    // 5. Prevent Duplicate Scans
    $stmt = $conn->prepare("SELECT id FROM attendance 
                           WHERE employee_id = ? 
                           AND type = ? 
                           AND DATE(scanned_at) = ?");
    $stmt->execute([$employee_id, $type, $today_date]);
    
    if ($stmt->fetch()) {
        echo json_encode(['status' => 'error', 'message' => "You have already scanned for '$type' today."]);
        exit;
    }

    // 6. Determine Status (Present vs Late)
    $status = 'present'; 
    
    if ($type === 'morning') {
        $ruleStmt = $conn->query("SELECT work_start_time FROM salary_rules ORDER BY id DESC LIMIT 1");
        $rules = $ruleStmt->fetch();
        
        if ($rules) {
            // Check if current KL time > work start time
            if ($current_time_only > $rules['work_start_time']) {
                $status = 'late';
            }
        }
    }

    // 7. Record Attendance (FIXED: Using PHP variable $current_timestamp instead of SQL NOW())
    $insertStmt = $conn->prepare("INSERT INTO attendance 
        (employee_id, scanned_at, type, status, qr_token, device_info, ip_address) 
        VALUES (?, ?, ?, ?, ?, ?, ?)");
    
    $insertStmt->execute([
        $employee_id,
        $current_timestamp, // This forces the DB to save the KL time we captured above
        $type,
        $status,
        $token,
        $device_info,
        $ip_address
    ]);

    // 8. Success Response
    echo json_encode([
        'status' => 'success', 
        'message' => 'Attendance marked successfully',
        'data' => [
            'type' => $type,
            'status' => $status,
            'time' => date('h:i A', strtotime($current_timestamp)) // Display nicely formatted time
        ]
    ]);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'System error: ' . $e->getMessage()]);
}
?>