<?php
// staff/scan.php
session_start();
if (!isset($_SESSION['employee_id'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scan Attendance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body class="bg-black h-screen flex flex-col items-center justify-center">

    <div class="w-full max-w-md bg-white rounded-lg overflow-hidden shadow-xl relative">
        <div class="bg-gray-900 p-4 flex justify-between items-center text-white">
            <a href="index.php" class="text-gray-400 hover:text-white">&larr; Back</a>
            <h1 class="font-bold">Scan Kiosk QR</h1>
            <div></div>
        </div>

        <div id="reader" style="width: 100%;" class="bg-black"></div>

        <div id="status-msg" class="p-4 text-center text-gray-600 bg-gray-100 border-t">
            Point camera at the Attendance Kiosk
        </div>
    </div>

    <script>
        const employeeId = <?php echo $_SESSION['employee_id']; ?>;
        
        function onScanSuccess(decodedText, decodedResult) {
            // 1. Stop scanning momentarily to prevent double firing
            html5QrcodeScanner.clear();

            $('#status-msg').html('<span class="text-blue-600 font-bold">Processing...</span>');

            try {
                // 2. Parse the QR Data (The Kiosk generates JSON)
                // Format: { "token": "abc...", "type": "morning" }
                const data = JSON.parse(decodedText);

                if(!data.token || !data.type) throw new Error("Invalid QR Format");

                // 3. Send to API
                $.post("scan_attendance.php", {
                    employee_id: employeeId,
                    token: data.token,
                    type: data.type,
                    device_info: navigator.userAgent
                }, function(response) {
                    if (response.status === 'success') {
                        // Success: Show nicely
                        const successHtml = `
                            <div class="text-center py-8">
                                <div class="text-5xl mb-2">✅</div>
                                <h2 class="text-2xl font-bold text-green-600">Success!</h2>
                                <p class="text-gray-700">Marked: <b>${response.data.type}</b></p>
                                <p class="text-gray-500 text-sm">${response.data.time}</p>
                                <a href="index.php" class="mt-6 inline-block bg-blue-600 text-white px-6 py-2 rounded-full">Done</a>
                            </div>
                        `;
                        $('.w-full').html(successHtml); // Replace entire card content
                    } else {
                        // Error (e.g., Duplicate scan)
                        alert("Error: " + response.message);
                        location.reload(); // Reload to scan again
                    }
                }).fail(function() {
                    alert("Network error. Please try again.");
                    location.reload();
                });

            } catch (e) {
                alert("Invalid QR Code. Please scan the official Kiosk code.");
                location.reload();
            }
        }

        function onScanFailure(error) {
            // handle scan failure, usually better to ignore and keep scanning.
            // console.warn(`Code scan error = ${error}`);
        }

        let html5QrcodeScanner = new Html5QrcodeScanner(
            "reader",
            { fps: 10, qrbox: {width: 250, height: 250} },
            /* verbose= */ false);
        html5QrcodeScanner.render(onScanSuccess, onScanFailure);
    </script>
</body>
</html>