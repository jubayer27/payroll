<?php
// staff/history.php
session_start();
require_once '../config/db.php';

// 1. Check Login
if (!isset($_SESSION['employee_id'])) {
    header("Location: ../index.php");
    exit;
}

$emp_id = $_SESSION['employee_id'];

// 2. Filter Logic (Default to Current Month)
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date   = $_GET['end_date'] ?? date('Y-m-t');

// 3. Fetch Raw Attendance Logs for the selected range
$sql = "SELECT * FROM attendance 
        WHERE employee_id = ? 
        AND DATE(scanned_at) BETWEEN ? AND ? 
        ORDER BY scanned_at ASC";
$stmt = $conn->prepare($sql);
$stmt->execute([$emp_id, $start_date, $end_date]);
$raw_logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 4. Process Data: Group by Date
$daily_logs = [];

foreach ($raw_logs as $log) {
    $date = date('Y-m-d', strtotime($log['scanned_at']));
    $time = date('h:i A', strtotime($log['scanned_at']));
    
    // Initialize day if not exists
    if (!isset($daily_logs[$date])) {
        $daily_logs[$date] = [
            'date_display' => date('d M, D', strtotime($date)),
            'clock_in' => '-',
            'lunch_out' => null,
            'lunch_in' => null,
            'clock_out' => '-',
            'status' => 'Absent',
            'is_late' => false
        ];
    }

    // Assign times based on type
    if ($log['type'] === 'morning') {
        $daily_logs[$date]['clock_in'] = $time;
        $daily_logs[$date]['status'] = 'Present';
        if ($log['status'] === 'late') $daily_logs[$date]['is_late'] = true;
    } 
    elseif ($log['type'] === 'lunch_start') {
        $daily_logs[$date]['lunch_out'] = $time;
    } 
    elseif ($log['type'] === 'lunch_end') {
        $daily_logs[$date]['lunch_in'] = $time;
    } 
    elseif ($log['type'] === 'leave') {
        $daily_logs[$date]['clock_out'] = $time;
    }
}

// Sort by date descending (newest first)
krsort($daily_logs);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Attendance History</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen pb-20">

    <?php include 'includes/header.php'; ?>

    <div class="max-w-6xl mx-auto p-4 md:p-6">
        
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-2">
            <h1 class="text-2xl font-bold text-gray-800">Attendance History</h1>
            <a href="index.php" class="text-blue-600 hover:underline text-sm flex items-center">
                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
                Back to Dashboard
            </a>
        </div>

        <div class="bg-white p-4 rounded-lg shadow mb-6">
            <form method="GET" class="flex flex-col md:flex-row items-end gap-4">
                <div class="w-full md:w-auto">
                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">From Date</label>
                    <input type="date" name="start_date" value="<?= $start_date ?>" class="w-full border border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none">
                </div>
                <div class="w-full md:w-auto">
                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">To Date</label>
                    <input type="date" name="end_date" value="<?= $end_date ?>" class="w-full border border-gray-300 rounded px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none">
                </div>
                <div class="w-full md:w-auto flex gap-2">
                    <button type="submit" class="bg-blue-600 text-white font-bold py-2 px-6 rounded hover:bg-blue-700 transition w-full md:w-auto">
                        Filter
                    </button>
                    <a href="history.php" class="bg-gray-200 text-gray-600 font-bold py-2 px-4 rounded hover:bg-gray-300 transition text-center w-full md:w-auto">
                        Reset
                    </a>
                </div>
            </form>
        </div>

        <div class="bg-white rounded-lg shadow overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse min-w-[600px]">
                    <thead class="bg-gray-50 border-b">
                        <tr>
                            <th class="p-4 text-xs font-bold text-gray-500 uppercase">Date</th>
                            <th class="p-4 text-xs font-bold text-green-700 uppercase">Clock In</th>
                            <th class="p-4 text-xs font-bold text-yellow-700 uppercase text-center">Lunch (Out &rarr; In)</th>
                            <th class="p-4 text-xs font-bold text-red-700 uppercase">Clock Out</th>
                            <th class="p-4 text-xs font-bold text-gray-500 uppercase text-right">Status</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100 text-sm">
                        <?php foreach($daily_logs as $day): ?>
                        <tr class="hover:bg-gray-50 transition">
                            <td class="p-4 font-bold text-gray-700 whitespace-nowrap">
                                <?= $day['date_display'] ?>
                            </td>

                            <td class="p-4">
                                <span class="bg-green-50 text-green-700 px-2 py-1 rounded font-mono font-bold border border-green-100">
                                    <?= $day['clock_in'] ?>
                                </span>
                            </td>

                            <td class="p-4 text-center">
                                <?php if($day['lunch_out'] || $day['lunch_in']): ?>
                                    <div class="inline-flex items-center bg-yellow-50 text-yellow-800 px-2 py-1 rounded border border-yellow-100 font-mono text-xs">
                                        <span><?= $day['lunch_out'] ?? '?' ?></span>
                                        <span class="mx-2 text-gray-400">&rarr;</span>
                                        <span><?= $day['lunch_in'] ?? '?' ?></span>
                                    </div>
                                <?php else: ?>
                                    <span class="text-gray-300">-</span>
                                <?php endif; ?>
                            </td>

                            <td class="p-4">
                                <?php if($day['clock_out'] !== '-'): ?>
                                    <span class="bg-red-50 text-red-700 px-2 py-1 rounded font-mono font-bold border border-red-100">
                                        <?= $day['clock_out'] ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-gray-300">-</span>
                                <?php endif; ?>
                            </td>

                            <td class="p-4 text-right">
                                <?php if($day['is_late']): ?>
                                    <span class="bg-red-100 text-red-700 px-2 py-1 rounded text-xs font-bold uppercase">LATE</span>
                                <?php elseif($day['status'] === 'Present'): ?>
                                    <span class="bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-bold uppercase">PRESENT</span>
                                <?php else: ?>
                                    <span class="bg-gray-100 text-gray-500 px-2 py-1 rounded text-xs font-bold uppercase">ABSENT</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>

                        <?php if(empty($daily_logs)): ?>
                            <tr>
                                <td colspan="5" class="p-8 text-center text-gray-400 flex flex-col items-center justify-center">
                                    <svg class="w-12 h-12 mb-2 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                                    <span>No records found for this date range.</span>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>