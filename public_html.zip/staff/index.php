<?php
// staff/index.php
session_start();
if (!isset($_SESSION['employee_id'])) {
    header("Location: ../index.php");
    exit;
}

// Fetch Latest Notice
require_once '../config/db.php';
$latestNotice = $conn->query("SELECT title, created_at FROM notices ORDER BY created_at DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-50 min-h-screen pb-24">
    
    <?php include 'includes/header.php'; ?>

    <div class="relative bg-gradient-to-br from-red-600 via-red-700 to-red-800 pb-24 pt-8 px-6 rounded-b-[3rem] shadow-2xl overflow-hidden">
        
        <div class="absolute top-0 right-0 w-64 h-64 bg-white opacity-5 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"></div>
        <div class="absolute bottom-0 left-0 w-48 h-48 bg-red-500 opacity-20 rounded-full blur-2xl -ml-10 -mb-10 pointer-events-none"></div>

        <div class="max-w-4xl mx-auto relative z-10 text-white">
            <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                
                <div>
                    <h1 class="text-3xl font-extrabold tracking-tight drop-shadow-md">Hello, <?php echo htmlspecialchars($_SESSION['name']); ?> 👋</h1>
                    <p class="text-red-100 mt-2 font-medium flex items-center gap-2 text-sm opacity-90">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                        <?php echo date('l, d F Y'); ?> 
                        <span class="mx-1 opacity-50">|</span> 
                        <span id="live-clock" class="font-mono font-bold tracking-widest">--:--:--</span>
                    </p>
                </div>

                <?php if($latestNotice): ?>
                <a href="notices.php" class="group bg-white/10 backdrop-blur-md border border-white/20 hover:bg-white hover:text-red-700 text-white transition-all duration-300 px-4 py-2 rounded-xl flex items-center gap-3 shadow-lg">
                    <span class="bg-red-500 group-hover:bg-red-100 group-hover:text-red-700 text-white text-[10px] px-2 py-0.5 rounded-full font-bold shadow-sm transition-colors">NEW</span>
                    <span class="truncate max-w-[150px] text-sm font-semibold"><?= htmlspecialchars($latestNotice['title']) ?></span>
                    <svg class="w-4 h-4 opacity-70 group-hover:opacity-100 transform group-hover:translate-x-1 transition-all" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="max-w-4xl mx-auto px-4 md:px-6 -mt-12 relative z-20">
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
            
            <a href="scan.php" class="group bg-white p-6 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 relative overflow-hidden">
                <div class="absolute right-0 top-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                    <svg class="w-24 h-24 text-red-600" fill="currentColor" viewBox="0 0 24 24"><path d="M3 5a2 2 0 012-2h14a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2V5zm2 0v14h14V5H5zm2 2h2v2H7V7zm4 0h2v2h-2V7zm4 0h2v2h-2V7z"></path></svg>
                </div>
                <div class="flex items-center gap-5">
                    <div class="bg-gradient-to-br from-red-500 to-red-700 text-white p-4 rounded-2xl shadow-lg shadow-red-500/30 group-hover:scale-110 transition-transform duration-300">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"></path></svg>
                    </div>
                    <div>
                        <h3 class="text-xl font-bold text-gray-800">Scan QR Code</h3>
                        <p class="text-gray-500 text-sm font-medium">Clock In/Out via Kiosk</p>
                    </div>
                </div>
            </a>

            <a href="history.php" class="group bg-white p-6 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                <div class="flex items-center gap-5">
                    <div class="bg-gray-50 text-red-600 border border-red-100 p-4 rounded-2xl group-hover:bg-red-50 transition-colors">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    </div>
                    <div>
                        <h3 class="text-lg font-bold text-gray-800 group-hover:text-red-600 transition-colors">Attendance History</h3>
                        <p class="text-gray-500 text-sm font-medium">View logs & status</p>
                    </div>
                </div>
            </a>

            <a href="leave_request.php" class="group bg-white p-6 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                <div class="flex items-center gap-5">
                    <div class="bg-gray-50 text-red-600 border border-red-100 p-4 rounded-2xl group-hover:bg-red-50 transition-colors">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                    </div>
                    <div>
                        <h3 class="text-lg font-bold text-gray-800 group-hover:text-red-600 transition-colors">Request Leave</h3>
                        <p class="text-gray-500 text-sm font-medium">Apply & check status</p>
                    </div>
                </div>
            </a>

            <a href="salary.php" class="group bg-white p-6 rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                <div class="flex items-center gap-5">
                    <div class="bg-gray-50 text-red-600 border border-red-100 p-4 rounded-2xl group-hover:bg-red-50 transition-colors">
                        <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    </div>
                    <div>
                        <h3 class="text-lg font-bold text-gray-800 group-hover:text-red-600 transition-colors">My Salary</h3>
                        <p class="text-gray-500 text-sm font-medium">Download payslips</p>
                    </div>
                </div>
            </a>

        </div>
    </div>

    <script>
    function updateClock() {
        const now = new Date();
        const timeString = now.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit' 
        });
        document.getElementById('live-clock').innerText = timeString;
    }
    updateClock();
    setInterval(updateClock, 1000);
    </script>
</body>
</html>