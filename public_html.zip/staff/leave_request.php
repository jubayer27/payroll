<?php
// staff/leave_request.php
session_start();
require_once '../config/db.php';

// 1. FIX: Check for 'user_id' OR 'employee_id' to prevent accidental redirect
$emp_id = $_SESSION['user_id'] ?? $_SESSION['employee_id'] ?? null;

if (!$emp_id) {
    header("Location: ../index.php");
    exit;
}

// 2. Fetch Employee Info (Check if Part-Time)
$stmtEmp = $conn->prepare("SELECT employment_type FROM employees WHERE id = ?");
$stmtEmp->execute([$emp_id]);
$currentUser = $stmtEmp->fetch();
$isPartTime = ($currentUser['employment_type'] === 'part_time');

// 3. Fetch Request History (From the generic 'requests' table we created)
$stmt = $conn->prepare("SELECT * FROM requests WHERE employee_id = ? ORDER BY created_at DESC");
$stmt->execute([$emp_id]);
$my_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Center</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-gray-100 min-h-screen pb-20">
    
    <?php include 'includes/header.php'; ?>
    
    <div class="max-w-6xl mx-auto p-4 md:p-6">
        
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-2">
            <h1 class="text-2xl font-bold text-gray-800">Request Center</h1>
            <a href="index.php" class="text-blue-600 hover:underline text-sm flex items-center">
                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
                Back to Dashboard
            </a>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            <div class="lg:col-span-1 space-y-6">
                
                <div class="bg-white rounded-lg shadow overflow-hidden">
                    <div class="flex border-b">
                        <button onclick="switchTab('leave')" id="tab-leave" class="flex-1 py-3 text-sm font-bold text-blue-600 border-b-2 border-blue-600 bg-blue-50 focus:outline-none">Leave</button>
                        <button onclick="switchTab('attendance')" id="tab-attendance" class="flex-1 py-3 text-sm font-bold text-gray-500 hover:bg-gray-50 focus:outline-none">Attend.</button>
                        <button onclick="switchTab('schedule')" id="tab-schedule" class="flex-1 py-3 text-sm font-bold text-gray-500 hover:bg-gray-50 focus:outline-none">Sched.</button>
                    </div>

                    <div class="p-6">
                        
                        <form id="form-leave" class="request-form space-y-4">
                            <input type="hidden" name="type" value="leave">
                            <div>
                                <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Leave Type</label>
                                <select name="leave_type" class="w-full border border-gray-300 rounded px-3 py-2 bg-white focus:outline-blue-500">
                                    <option value="annual">Annual Leave</option>
                                    <option value="sick">Sick Leave</option>
                                    <option value="emergency">Emergency</option>
                                    <option value="unpaid">Unpaid Leave</option>
                                </select>
                            </div>
                            <div class="grid grid-cols-2 gap-3">
                                <div>
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">From</label>
                                    <input type="date" name="from_date" class="w-full border rounded px-3 py-2">
                                </div>
                                <div>
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">To</label>
                                    <input type="date" name="to_date" class="w-full border rounded px-3 py-2">
                                </div>
                            </div>
                            <div>
                                <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Reason</label>
                                <textarea name="reason" rows="3" class="w-full border rounded px-3 py-2" required></textarea>
                            </div>
                            <button type="submit" class="w-full bg-blue-600 text-white font-bold py-2 rounded hover:bg-blue-700 transition">Submit Leave</button>
                        </form>

                        <form id="form-attendance" class="request-form space-y-4 hidden">
                            <input type="hidden" name="type" value="attendance_correction">
                            <div class="bg-yellow-50 border-l-4 border-yellow-400 p-3 mb-2 text-xs text-yellow-700">
                                Forgot to scan? Submit a correction request here.
                            </div>
                            <div>
                                <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Date</label>
                                <input type="date" name="date" class="w-full border rounded px-3 py-2" required>
                            </div>
                            <div class="grid grid-cols-2 gap-3">
                                <div>
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Scan Type</label>
                                    <select name="scan_type" class="w-full border rounded px-3 py-2 bg-white">
                                        <option value="morning">Clock In</option>
                                        <option value="lunch_start">Lunch Out</option>
                                        <option value="lunch_end">Lunch In</option>
                                        <option value="leave">Clock Out</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Time</label>
                                    <input type="time" name="time" class="w-full border rounded px-3 py-2" required>
                                </div>
                            </div>
                            <div>
                                <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Reason</label>
                                <textarea name="reason" rows="2" class="w-full border rounded px-3 py-2" placeholder="e.g. Forgot phone" required></textarea>
                            </div>
                            <button type="submit" class="w-full bg-yellow-600 text-white font-bold py-2 rounded hover:bg-yellow-700 transition">Request Fix</button>
                        </form>

                        <form id="form-schedule" class="request-form space-y-4 hidden">
                            <input type="hidden" name="type" id="sched_type" value="schedule_switch">
                            
                            <?php if($isPartTime): ?>
                            <div class="flex items-center gap-2 mb-2 p-2 bg-purple-50 rounded border border-purple-100">
                                <input type="checkbox" id="pt_check" name="is_part_time_change" value="1" class="w-4 h-4 text-purple-600">
                                <label for="pt_check" class="text-xs font-bold text-purple-800">Permanent Shift Change</label>
                            </div>
                            <?php endif; ?>

                            <div id="block-switch">
                                <div>
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">I will WORK on</label>
                                    <input type="date" name="work_date" class="w-full border rounded px-3 py-2">
                                </div>
                                <div class="mt-2">
                                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">I will take OFF on</label>
                                    <input type="date" name="off_date" class="w-full border rounded px-3 py-2">
                                </div>
                            </div>

                            <div id="block-pt" class="hidden space-y-2">
                                <label class="block text-xs font-bold text-gray-500 uppercase">Select New Days</label>
                                <div class="flex flex-wrap gap-2 text-sm">
                                    <?php $days=['Mon','Tue','Wed','Thu','Fri','Sat','Sun']; foreach($days as $k=>$d): ?>
                                        <label><input type="checkbox" name="days[]" value="<?=$k+1?>"> <?=$d?></label>
                                    <?php endforeach; ?>
                                </div>
                                <div class="grid grid-cols-2 gap-2">
                                    <input type="time" name="pt_start" class="border rounded p-1 text-sm">
                                    <input type="time" name="pt_end" class="border rounded p-1 text-sm">
                                </div>
                            </div>

                            <div class="mt-2">
                                <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Reason</label>
                                <textarea name="reason" rows="2" class="w-full border rounded px-3 py-2" required></textarea>
                            </div>
                            <button type="submit" class="w-full bg-purple-600 text-white font-bold py-2 rounded hover:bg-purple-700 transition">Submit Change</button>
                        </form>

                    </div>
                </div>
            </div>

            <div class="lg:col-span-2 bg-white p-6 rounded-lg shadow h-fit">
                <h2 class="text-lg font-bold text-gray-700 mb-4 border-b pb-2 flex items-center justify-between">
                    <span>My Request History</span>
                    <span class="text-xs font-normal text-gray-400">Latest 50 records</span>
                </h2>
                
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse min-w-[600px]">
                        <thead>
                            <tr class="bg-gray-50 text-gray-500 text-xs uppercase">
                                <th class="p-3 rounded-tl-lg">Type</th>
                                <th class="p-3">Details</th>
                                <th class="p-3">Reason</th>
                                <th class="p-3 text-right rounded-tr-lg">Status</th>
                            </tr>
                        </thead>
                        <tbody class="text-sm divide-y divide-gray-100">
                            <?php foreach($my_requests as $req): 
                                $data = json_decode($req['request_data'], true);
                                $statusColor = match($req['status']) {
                                    'approved' => 'bg-green-100 text-green-800',
                                    'rejected' => 'bg-red-100 text-red-800',
                                    default => 'bg-yellow-100 text-yellow-800'
                                };
                                $typeLabel = ucfirst(str_replace('_', ' ', $req['type']));
                            ?>
                            <tr class="hover:bg-gray-50 transition">
                                <td class="p-3 font-bold text-gray-700 text-xs uppercase"><?= $typeLabel ?></td>
                                <td class="p-3">
                                    <?php if($req['type'] == 'leave'): ?>
                                        <span class="font-bold text-blue-600"><?= ucfirst($data['leave_type']) ?></span><br>
                                        <?= date('d M', strtotime($data['from_date'])) ?> - <?= date('d M', strtotime($data['to_date'])) ?>
                                    <?php elseif($req['type'] == 'attendance_correction'): ?>
                                        <span class="font-bold text-yellow-600"><?= ucfirst($data['scan_type']) ?></span><br>
                                        <?= date('d M', strtotime($data['date'])) ?> @ <?= $data['time'] ?>
                                    <?php elseif($req['type'] == 'schedule_switch'): ?>
                                        Work: <?= date('d M', strtotime($data['work_date'])) ?><br>
                                        Off: <?= date('d M', strtotime($data['off_date'])) ?>
                                    <?php endif; ?>
                                </td>
                                <td class="p-3 text-gray-500 italic max-w-[150px] truncate"><?= htmlspecialchars($req['reason']) ?></td>
                                <td class="p-3 text-right">
                                    <span class="px-2 py-1 rounded text-xs font-bold uppercase <?= $statusColor ?>">
                                        <?= $req['status'] ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            
                            <?php if(empty($my_requests)): ?>
                                <tr>
                                    <td colspan="4" class="p-8 text-center text-gray-400">No history found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>

    <script>
        // 1. Tab Switching
        function switchTab(tab) {
            // Hide all forms
            $('#form-leave, #form-attendance, #form-schedule').addClass('hidden');
            // Show selected form
            $('#form-' + tab).removeClass('hidden');

            // Reset Tab Styles
            $('#tab-leave, #tab-attendance, #tab-schedule').removeClass('border-blue-600 bg-blue-50 text-blue-600').addClass('text-gray-500 hover:bg-gray-50 border-transparent');
            
            // Highlight Active Tab
            $('#tab-' + tab).addClass('border-b-2 border-blue-600 bg-blue-50 text-blue-600').removeClass('text-gray-500 border-transparent');
        }

        // 2. Part Time Toggle
        $('#pt_check').change(function() {
            if(this.checked) {
                $('#block-switch').addClass('hidden');
                $('#block-pt').removeClass('hidden');
                $('#sched_type').val('part_time_change');
            } else {
                $('#block-switch').removeClass('hidden');
                $('#block-pt').addClass('hidden');
                $('#sched_type').val('schedule_switch');
            }
        });

        // 3. AJAX Submission
        $('.request-form').on('submit', function(e) {
            e.preventDefault();
            Swal.fire({ title: 'Submitting...', didOpen: () => Swal.showLoading() });

            // Note: Ensure this path points to the API created in the previous step
            $.post('api_submit_request.php', $(this).serialize(), function(res) {
                if(res.status === 'success') {
                    Swal.fire('Submitted!', res.message, 'success').then(() => location.reload());
                } else {
                    Swal.fire('Error', res.message, 'error');
                }
            }, 'json').fail(() => Swal.fire('Error', 'Server Error', 'error'));
        });
    </script>
</body>
</html>