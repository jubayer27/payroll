<?php
// staff/notices.php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['employee_id'])) {
    header("Location: ../index.php");
    exit;
}

// Fetch All Notices
$notices = $conn->query("SELECT * FROM notices ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notices</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen pb-20">
    
    <?php include 'includes/header.php'; ?>

    <div class="max-w-4xl mx-auto p-4 md:p-6">
        <h1 class="text-2xl font-bold text-gray-800 mb-6">Company Notices</h1>

        <div class="space-y-4">
            <?php foreach($notices as $note): ?>
                <div class="bg-white p-5 rounded-lg shadow-sm border-l-4 
                    <?php 
                        if($note['priority'] == 'high') echo 'border-red-500 bg-red-50';
                        elseif($note['priority'] == 'medium') echo 'border-yellow-500 bg-yellow-50';
                        else echo 'border-blue-500';
                    ?>">
                    
                    <div class="flex justify-between items-start mb-2">
                        <h3 class="font-bold text-gray-900 text-lg"><?= htmlspecialchars($note['title']) ?></h3>
                        <span class="text-xs text-gray-500 whitespace-nowrap ml-2">
                            <?= date('d M', strtotime($note['created_at'])) ?>
                        </span>
                    </div>
                    
                    <p class="text-gray-700 text-sm whitespace-pre-wrap leading-relaxed"><?= nl2br(htmlspecialchars($note['message'])) ?></p>
                </div>
            <?php endforeach; ?>

            <?php if(empty($notices)): ?>
                <div class="text-center text-gray-400 py-10">
                    <svg class="w-16 h-16 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
                    <p>No notices at the moment.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>