<?php
// staff/includes/header.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$current_page = basename($_SERVER['PHP_SELF']);
$user_name = $_SESSION['name'] ?? 'Staff';

// Define the shiny red gradient class for reuse
$redGradient = "bg-gradient-to-br from-red-500 via-red-600 to-red-700";
?>

<link rel="manifest" href="../manifest.json">
<link rel="apple-touch-icon" href="../assets/icons/icon-192x192.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="theme-color" content="#dc2626">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<style>
    body {
        overscroll-behavior-y: contain; /* Prevents browser bounce/refresh chaining */
    }
    /* Pull to Refresh Indicator styling */
    #ptr-indicator {
        position: fixed; top: -50px; left: 0; right: 0; 
        text-align: center; transition: top 0.3s; z-index: 9999;
    }
    @media (max-width: 768px) {
        body { padding-bottom: 90px; }
    }
</style>

<div id="ptr-indicator" class="text-gray-500 text-sm font-bold bg-white p-2 shadow rounded-b-lg mx-auto w-32">
    Release to Refresh
</div>

<nav class="hidden md:block bg-white text-gray-800 shadow-sm border-b border-gray-200 relative z-50">
    <div class="max-w-7xl mx-auto px-6">
        <div class="flex justify-between items-center h-20">
            
            <div class="flex items-center">
                <a href="index.php" class="font-extrabold text-2xl tracking-widest uppercase flex items-center gap-3 group">
                    <div class="<?= $redGradient ?> p-2 rounded-lg shadow-md shadow-red-500/20 group-hover:scale-110 transition-transform duration-300">
                        <svg class="w-6 h-6 text-white drop-shadow-sm" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
                    </div>
                    <span class="text-gray-800 group-hover:text-red-600 transition-all">
                        Staff Portal
                    </span>
                </a>
            </div>

            <div class="flex space-x-2 items-center">
                <?php 
                $menu = [
                    'index.php' => 'Dashboard',
                    'notices.php' => 'Notices',
                    'scan.php' => 'Scan QR',
                    'history.php' => 'History',
                    'leave_request.php' => 'Leaves',
                    'salary.php' => 'My Salary'
                ];

                foreach ($menu as $link => $label): 
                    $isActive = ($current_page == $link);
                ?>
                    <a href="<?= $link ?>" class="px-4 py-2 rounded-lg text-sm font-bold transition-all duration-300 
                       <?= $isActive ? $redGradient . ' text-white shadow-md shadow-red-500/20 transform scale-105' : 'text-gray-500 hover:text-red-600 hover:bg-red-50' ?>">
                        <?= $label ?>
                    </a>
                <?php endforeach; ?>
                
                <div class="ml-6 pl-6 border-l border-gray-200 flex items-center gap-4">
                    <span class="text-sm font-medium text-gray-500">Hi, <span class="text-gray-800 font-bold"><?= htmlspecialchars($user_name) ?></span></span>
                    <a href="../logout.php" class="text-red-600 hover:text-white border border-red-200 hover:border-transparent hover:bg-gradient-to-r hover:from-red-500 hover:to-red-700 px-4 py-2 rounded-lg text-xs font-bold transition-all shadow-sm hover:shadow-md">
                        Logout
                    </a>
                </div>
            </div>
        </div>
    </div>
</nav>

<div class="md:hidden flex justify-between items-center <?= $redGradient ?> text-white p-4 shadow-lg sticky top-0 z-40">
    <span class="font-bold text-lg flex items-center gap-3">
        <div class="bg-white text-red-600 p-1.5 rounded shadow-sm shadow-black/10">
            <svg class="w-5 h-5 drop-shadow-sm" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
        </div>
        <span class="tracking-wide drop-shadow-md">Staff Portal</span>
    </span>
    <a href="../logout.php" class="text-white/90 hover:text-white transition transform active:scale-95">
        <svg class="w-6 h-6 drop-shadow-md" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
    </a>
</div>

<div class="md:hidden fixed bottom-0 w-full bg-white border-t border-gray-200 flex justify-around py-3 z-50 text-[10px] font-medium text-gray-400 shadow-[0_-4px_20px_-1px_rgba(0,0,0,0.05)]">
    
    <a href="index.php" class="flex flex-col items-center transition-colors duration-300 <?= $current_page == 'index.php' ? 'text-red-600 font-bold' : 'hover:text-red-500' ?>">
        <svg class="w-6 h-6 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
        Home
    </a>

    <a href="notices.php" class="flex flex-col items-center transition-colors duration-300 <?= $current_page == 'notices.php' ? 'text-red-600 font-bold' : 'hover:text-red-500' ?>">
        <svg class="w-6 h-6 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
        Notices
    </a>

    <a href="scan.php" class="flex flex-col items-center -mt-8 group relative z-10">
        <div class="<?= $redGradient ?> text-white p-4 rounded-full shadow-lg shadow-red-500/40 border-4 border-white transform transition-all duration-300 group-hover:scale-110 group-active:scale-95">
            <svg class="w-7 h-7 drop-shadow-sm" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"></path></svg>
        </div>
        <span class="mt-1 font-bold text-red-600 text-xs transition group-hover:text-red-700">Scan</span>
    </a>

    <a href="leave_request.php" class="flex flex-col items-center transition-colors duration-300 <?= $current_page == 'leave_request.php' ? 'text-red-600 font-bold' : 'hover:text-red-500' ?>">
        <svg class="w-6 h-6 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
        Leaves
    </a>

    <a href="salary.php" class="flex flex-col items-center transition-colors duration-300 <?= $current_page == 'salary.php' ? 'text-red-600 font-bold' : 'hover:text-red-500' ?>">
        <svg class="w-6 h-6 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
        Salary
    </a>
</div>

<script>
    // Service Worker for PWA
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('../sw.js')
                .then(reg => console.log('Service Worker registered'))
                .catch(err => console.log('Service Worker failed', err));
        });
    }

    // Pull to Refresh Logic
    let touchStart = 0;
    let touchEnd = 0;
    const ptr = document.getElementById('ptr-indicator');

    window.addEventListener('touchstart', e => {
        if (window.scrollY === 0) touchStart = e.changedTouches[0].screenY;
    });

    window.addEventListener('touchmove', e => {
        if (window.scrollY === 0) {
            touchEnd = e.changedTouches[0].screenY;
            if (touchEnd > touchStart + 100) { // Dragged down enough
                ptr.style.top = "10px";
            }
        }
    });

    window.addEventListener('touchend', e => {
        ptr.style.top = "-50px";
        if (window.scrollY === 0 && touchEnd > touchStart + 100) {
            location.reload(); // Trigger Reload
        }
    });
    
    // Back Button Logic for PWA History
    window.addEventListener('popstate', function(event) {
        history.pushState(null, null, window.location.pathname);
    }, false);
</script>