<?php
// admin/generate_payslip_pdf.php
session_start();
require_once '../config/db.php';

// 1. Load DomPDF (Using your confirmed working paths)
if (file_exists('pdf/autoload.inc.php')) {
    require_once 'pdf/autoload.inc.php';
} elseif (file_exists('dompdf/autoload.inc.php')) {
    require_once 'dompdf/autoload.inc.php';
} else {
    // Fallback standard composer
    require_once '../vendor/autoload.php';
}

use Dompdf\Dompdf;
use Dompdf\Options;

// 2. Security Check
if (!isset($_SESSION['user_role'])) {
    die("Access Denied");
}

$payslip_id = $_GET['id'] ?? null;
if (!$payslip_id) die("Invalid Payslip ID");

// 3. Fetch Data
// We join employees to get name, IC, Department, etc.
$sql = "SELECT p.*, e.first_name, e.last_name, e.department, e.bank_account, e.nic, e.salary_type, e.join_date, e.status
        FROM payslips p 
        JOIN employees e ON p.employee_id = e.id 
        WHERE p.id = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$payslip_id]);
$data = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$data) die("Payslip not found");

// Check ownership if not admin
if ($_SESSION['user_role'] !== 'admin' && $_SESSION['employee_id'] != $data['employee_id']) {
    die("Access Denied");
}

// 4. Decode JSON Data
$details = json_decode($data['deductions'], true);
$earn = $details['earnings'];
$deduct = $details['deductions_breakdown'];
$stats = $details['stats'];

// Date Formats
$month_start = date('01-m-Y', strtotime($data['month_year'] . '-01'));
$month_end   = date('t-m-Y', strtotime($data['month_year'] . '-01'));
$pay_period  = "$month_start TO $month_end";
$paid_on     = date('d/m/Y', strtotime($data['generated_at']));

// Calculations for "Total No Pay" section (Info only)
$late_hours = round($deduct['late_minutes'] / 60, 2);
$absent_days = $deduct['absent_days'];

// Total Deductions Value
$total_deductions_val = $data['gross_salary'] - $data['net_salary'];

// 5. HTML Template (Matching your Image)
$html = '
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Helvetica, sans-serif; font-size: 10px; color: #000; }
        table { width: 100%; border-collapse: collapse; }
        
        .company-header { margin-bottom: 15px; }
        .company-name { font-size: 14px; font-weight: bold; text-transform: uppercase; }
        .company-address { font-size: 9px; margin-top: 2px; }

        /* Header Grid (Employee Info) */
        .header-grid td { border: 1px solid #ccc; padding: 4px; vertical-align: top; }
        .label { font-weight: bold; color: #333; }

        /* Main Earnings/Deductions Table */
        .main-table { margin-top: 10px; border: 1px solid #000; }
        .main-table th { background-color: #f0f0f0; border: 1px solid #000; padding: 5px; text-align: left; font-weight: bold; }
        .main-table td { border-left: 1px solid #000; border-right: 1px solid #000; padding: 4px 5px; vertical-align: top; }
        
        .amount-col { text-align: right; }
        .section-title { font-weight: bold; text-decoration: underline; margin-bottom: 3px; display: block; }
        
        /* Bottom Totals */
        .total-row td { border-top: 1px solid #000; border-bottom: 1px solid #000; font-weight: bold; background-color: #f9f9f9; }
        
        /* Net Pay Box */
        .net-pay-section td { padding: 5px; }
        .net-box { border: 2px solid #000; padding: 5px; text-align: right; font-weight: bold; font-size: 12px; }

        /* Footer */
        .footer-grid td { vertical-align: top; padding: 5px; border: 1px solid #ccc; }
    </style>
</head>
<body>

    <div class="company-header">
        <div class="company-name">7 MASTER GAMING PLT.</div>
        <div class="company-address">Lot 4-28, 4th Floor, Plaza Low Yat, Jalan Bukit Bintang, 55100 Kuala Lumpur, Wilayah Persekutuan (KL)</div>
    </div>

    <table class="header-grid">
        <tr>
            <td width="15%"><span class="label">Employee Name</span></td>
            <td width="2%"><span class="label">:</span></td>
            <td width="30%">'. strtoupper($data['first_name'] . ' ' . $data['last_name']) .'</td>
            
            <td width="15%"><span class="label">Employee Code</span></td>
            <td width="2%"><span class="label">:</span></td>
            <td width="10%">'. str_pad($data['employee_id'], 4, '0', STR_PAD_LEFT) .'</td>
            
            <td width="12%"><span class="label">IC / Passport</span></td>
            <td width="2%"><span class="label">:</span></td>
            <td>'. ($data['nic'] ?? '-') .'</td>
        </tr>
        <tr>
            <td><span class="label">Tax Number</span></td>
            <td><span class="label">:</span></td>
            <td>-</td>
            
            <td><span class="label">SOCSO Number</span></td>
            <td><span class="label">:</span></td>
            <td>-</td>
            
            <td><span class="label">EPF Number</span></td>
            <td><span class="label">:</span></td>
            <td>-</td>
        </tr>
        <tr>
            <td><span class="label">Department</span></td>
            <td><span class="label">:</span></td>
            <td>'. strtoupper($data['department']) .'</td>
            
            <td><span class="label">Pay Group</span></td>
            <td><span class="label">:</span></td>
            <td>'. $stats['worked_days'] .' WORKING DAYS</td>
            
            <td><span class="label">Pay Period</span></td>
            <td><span class="label">:</span></td>
            <td>'. $pay_period .'</td>
        </tr>
    </table>

    <table class="main-table">
        <thead>
            <tr>
                <th width="40%">EARNING DESCRIPTION</th>
                <th width="10%" class="amount-col">EARNINGS</th>
                <th width="40%">DEDUCTIONS / INFO</th>
                <th width="10%" class="amount-col">DEDUCTIONS</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td height="200px">
                    BASIC PAY<br>
                    TRANSPORT ALLOWANCE<br>
                    OVERTIME<br>
                    PUBLIC HOLIDAY<br>
                    COMMISSION<br>
                    PERFECT ATTENDANCE ALLOWANCE<br>
                    CLAIM / MANUAL BONUS
                </td>
                <td class="amount-col">
                    '. number_format($earn['basic'], 2) .'<br>
                    0.00<br>
                    '. number_format($earn['ot'], 2) .'<br>
                    0.00<br>
                    '. number_format($earn['commission'], 2) .'<br>
                    '. number_format($earn['perfect_attendance'], 2) .'<br>
                    '. number_format($earn['claims'] + $earn['bonus'], 2) .'
                </td>

                <td>
                    <span class="section-title">TOTAL NO PAY INFO</span>
                    [Range: '. $pay_period .']<br>
                    - LATENESS: HOURS ('. $late_hours .' hrs)<br>
                    - UNPAID DAYS: ('. $absent_days .' days)<br>
                    - LEAVE W/O NOTICE PENALTY<br>
                    <br>
                    <span class="section-title">STATUTORY & FINES</span>
                    LATE FINES<br>
                    ABSENT PENALTY<br>
                    REJECTED LEAVE FINE<br>
                    EMPLOYEE EPF<br>
                    EMPLOYEE SOCSO<br>
                    EMPLOYEE EIS
                </td>
                <td class="amount-col">
                    <br><br>
                    -<br>
                    -<br>
                    -<br>
                    <br><br>
                    '. number_format($deduct['late_fine'], 2) .'<br>
                    '. number_format($deduct['absent_penalty'] + ($deduct['leave_without_notice_fine'] ?? 0), 2) .'<br>
                    '. number_format($deduct['rejected_leave_fine'] ?? 0, 2) .'<br>
                    0.00<br>
                    0.00<br>
                    0.00
                </td>
            </tr>
            
            <tr class="total-row">
                <td style="text-align: right; padding-right: 10px;">TOTAL EARNINGS</td>
                <td class="amount-col">'. number_format($data['gross_salary'], 2) .'</td>
                <td style="text-align: right; padding-right: 10px;">TOTAL DEDUCTIONS</td>
                <td class="amount-col">'. number_format($total_deductions_val, 2) .'</td>
            </tr>
        </tbody>
    </table>

    <table class="net-pay-section" style="margin-top: 5px;">
        <tr>
            <td width="15%">Gross Wages</td>
            <td width="2%">:</td>
            <td width="20%">'. number_format($data['gross_salary'], 2) .'</td>
            
            <td width="20%" style="text-align: right;">Nett Wages :</td>
            <td width="20%" class="net-box">'. number_format($data['net_salary'], 2) .'</td>
        </tr>
        <tr>
            <td>Advance Payment</td>
            <td>:</td>
            <td>0.00</td>
            
            <td style="text-align: right;">Amount Paid :</td>
            <td style="text-align: right; font-weight: bold;">'. number_format($data['net_salary'], 2) .'</td>
        </tr>
        <tr>
            <td colspan="3"></td>
            <td style="text-align: right; font-size: 9px;">Employer EPF :</td>
            <td style="text-align: right; font-size: 9px;">0.00</td>
        </tr>
        <tr>
            <td colspan="3"></td>
            <td style="text-align: right; font-size: 9px;">Employer SOCSO :</td>
            <td style="text-align: right; font-size: 9px;">0.00</td>
        </tr>
    </table>

    <table class="footer-grid" style="margin-top: 20px;">
        <tr>
            <td width="50%">
                <strong>Payment Details</strong><br>
                Pay Mode : CASH / TRANSFER<br>
                Bank Name : '. ($data['bank_account'] ? 'Maybank/Public' : '-') .'<br>
                AC. No. : '. ($data['bank_account'] ?? '-') .'<br>
                <br>
                Paid On : '. $paid_on .' CASH
            </td>
            <td width="25%">
                <strong>CLAIMED / LEAVE</strong><br>
                Annual Leave : -<br>
                Sick Leave : -
            </td>
            <td width="25%" style="vertical-align: bottom; text-align: center;">
                <br><br><br>
                _______________________<br>
                RECEIVE BY
            </td>
        </tr>
    </table>

</body>
</html>
';

// 6. Render PDF
$options = new Options();
$options->set('defaultFont', 'Helvetica');
$options->set('isHtml5ParserEnabled', true);

$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream("Payslip_" . $data['first_name'] . ".pdf", ["Attachment" => 0]);
?>