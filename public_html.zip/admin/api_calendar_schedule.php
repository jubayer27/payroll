<?php
// admin/api_calendar_schedule.php
require_once '../config/db.php';
header('Content-Type: application/json');

// Get FullCalendar range
$start = $_GET['start'] ?? date('Y-m-01');
$end   = $_GET['end'] ?? date('Y-m-t');

// 1. Fetch All Active Employees
$stmt = $conn->query("SELECT id, first_name, last_name, work_days FROM employees WHERE status='active'");
$employees = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 2. Fetch All Schedule Adjustments (Overrides) for this period
$stmtAdj = $conn->prepare("SELECT * FROM schedule_adjustments WHERE adjustment_date BETWEEN ? AND ? AND status='approved'");
$stmtAdj->execute([$start, $end]);
$adjustments = [];
while ($row = $stmtAdj->fetch(PDO::FETCH_ASSOC)) {
    // Key: "empID_date" => type ('work' or 'off')
    $adjustments[$row['employee_id'] . '_' . $row['adjustment_date']] = $row['type'];
}

// 3. Generate Events
$events = [];

// Loop through each day in the range
$current = strtotime($start);
$endDate = strtotime($end);

while ($current < $endDate) {
    $dateStr = date('Y-m-d', $current);
    $dayOfWeek = date('N', $current); // 1 (Mon) - 7 (Sun)
    
    $workingEmployees = [];

    foreach ($employees as $emp) {
        $empId = $emp['id'];
        $key = $empId . '_' . $dateStr;
        
        // DEFAULT STATUS
        $activeDays = explode(',', $emp['work_days']);
        $isWorking = in_array($dayOfWeek, $activeDays);

        // CHECK OVERRIDE
        if (isset($adjustments[$key])) {
            $isWorking = ($adjustments[$key] === 'work');
        }

        if ($isWorking) {
            $workingEmployees[] = $emp['first_name'] . ' ' . substr($emp['last_name'], 0, 1) . '.';
        }
    }

    if (!empty($workingEmployees)) {
        // Option A: Show Count (Cleaner for large teams)
        // $events[] = [
        //     'title' => count($workingEmployees) . ' Staff',
        //     'start' => $dateStr,
        //     'allDay' => true,
        //     'color' => '#10b981', // Green
        //     'extendedProps' => ['names' => implode('<br>', $workingEmployees)]
        // ];

        // Option B: Show Names directly (Better for small teams)
        foreach ($workingEmployees as $name) {
            $events[] = [
                'title' => $name,
                'start' => $dateStr,
                'allDay' => true,
                'color' => '#3b82f6', // Blue
                'textColor' => '#ffffff'
            ];
        }
    }

    $current = strtotime('+1 day', $current);
}

// 4. Also fetch Holidays (Optional: Keep your existing holidays)
$holStmt = $conn->prepare("SELECT title, start FROM holidays WHERE start BETWEEN ? AND ?");
$holStmt->execute([$start, $end]);
while($row = $holStmt->fetch(PDO::FETCH_ASSOC)) {
    $events[] = [
        'title' => '🏖️ ' . $row['title'],
        'start' => $row['start'],
        'color' => '#ef4444', // Red for holidays
        'display' => 'block'
    ];
}

echo json_encode($events);
?>