<?php
// admin/notices.php
session_start();
require_once '../config/db.php';

// 1. Security Check
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

$message = "";

// 2. Handle Actions (Add / Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'add') {
        $title = $_POST['title'];
        $msg = $_POST['message'];
        $priority = $_POST['priority'];
        
        $stmt = $conn->prepare("INSERT INTO notices (title, message, priority, created_by) VALUES (?, ?, ?, ?)");
        $stmt->execute([$title, $msg, $priority, $_SESSION['user_id']]);
        $message = "Notice published successfully!";
    }
    
    if (isset($_POST['action']) && $_POST['action'] === 'delete') {
        $id = $_POST['id'];
        $conn->prepare("DELETE FROM notices WHERE id = ?")->execute([$id]);
        $message = "Notice deleted.";
    }
}

// 3. Fetch Notices
$notices = $conn->query("SELECT * FROM notices ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Notices</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-gray-100 flex font-sans">
    
    <?php include 'includes/sidebar.php'; ?>

    <main class="flex-1 p-8 h-screen overflow-y-auto">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-bold text-gray-800">Notice Board</h1>
            <button onclick="openModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 font-bold shadow-lg">
                + New Notice
            </button>
        </div>

        <?php if($message): ?>
            <div class="bg-green-100 text-green-700 p-3 rounded mb-4 border border-green-200"><?= $message ?></div>
        <?php endif; ?>

        <div class="grid grid-cols-1 gap-4">
            <?php foreach($notices as $note): ?>
                <div class="bg-white p-6 rounded-lg shadow-sm border-l-4 
                    <?php 
                        if($note['priority'] == 'high') echo 'border-red-500';
                        elseif($note['priority'] == 'medium') echo 'border-yellow-500';
                        else echo 'border-blue-500';
                    ?> relative group">
                    
                    <div class="flex justify-between items-start">
                        <div>
                            <h3 class="text-lg font-bold text-gray-800"><?= htmlspecialchars($note['title']) ?></h3>
                            <p class="text-xs text-gray-400 mb-2">Posted on <?= date('d M Y, h:i A', strtotime($note['created_at'])) ?></p>
                        </div>
                        <span class="px-2 py-1 rounded text-xs font-bold uppercase
                            <?php 
                                if($note['priority'] == 'high') echo 'bg-red-100 text-red-700';
                                elseif($note['priority'] == 'medium') echo 'bg-yellow-100 text-yellow-800';
                                else echo 'bg-blue-100 text-blue-700';
                            ?>">
                            <?= $note['priority'] ?> Priority
                        </span>
                    </div>
                    
                    <p class="text-gray-600 mt-2 whitespace-pre-wrap"><?= nl2br(htmlspecialchars($note['message'])) ?></p>

                    <form method="POST" class="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?= $note['id'] ?>">
                        <button type="submit" class="text-red-500 hover:text-red-700 text-sm underline" onclick="return confirm('Delete this notice?')">Delete</button>
                    </form>
                </div>
            <?php endforeach; ?>
            
            <?php if(empty($notices)): ?>
                <p class="text-gray-400 text-center py-8">No notices posted yet.</p>
            <?php endif; ?>
        </div>
    </main>

    <div id="noticeModal" class="hidden fixed inset-0 bg-gray-900 bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white p-6 rounded-lg shadow-xl w-full max-w-md">
            <h3 class="text-xl font-bold mb-4">Post New Notice</h3>
            <form method="POST">
                <input type="hidden" name="action" value="add">
                
                <div class="mb-4">
                    <label class="block text-sm font-bold text-gray-700 mb-1">Title</label>
                    <input type="text" name="title" required class="w-full border rounded px-3 py-2">
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-bold text-gray-700 mb-1">Priority</label>
                    <select name="priority" class="w-full border rounded px-3 py-2">
                        <option value="low">Low (Blue)</option>
                        <option value="medium">Medium (Yellow)</option>
                        <option value="high">High (Red)</option>
                    </select>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-bold text-gray-700 mb-1">Message</label>
                    <textarea name="message" rows="4" required class="w-full border rounded px-3 py-2"></textarea>
                </div>

                <div class="flex justify-end gap-2">
                    <button type="button" onclick="document.getElementById('noticeModal').classList.add('hidden')" class="text-gray-500 px-4 py-2">Cancel</button>
                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded font-bold hover:bg-blue-700">Post Notice</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openModal() {
            document.getElementById('noticeModal').classList.remove('hidden');
        }
    </script>
</body>
</html>