<?php
// admin/employees.php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

// Fetch all employees
$stmt = $conn->query("SELECT * FROM employees ORDER BY id DESC");
$employees = $stmt->fetchAll();
include 'includes/sidebar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee List</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex">
    
    
    <main class="flex-1 p-8">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-bold text-gray-800">Employees</h1>
            <a href="add_employee.php" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">+ Add New</a>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($employees as $emp): ?>
            <div class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition">
                <div class="flex items-center space-x-4 mb-4">
                    <div class="bg-blue-100 text-blue-600 rounded-full h-12 w-12 flex items-center justify-center font-bold text-xl">
                        <?php echo substr($emp['first_name'], 0, 1) . substr($emp['last_name'], 0, 1); ?>
                    </div>
                    <div>
                        <h2 class="text-lg font-bold text-gray-800"><?php echo htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']); ?></h2>
                        <p class="text-sm text-gray-500"><?php echo htmlspecialchars($emp['department']); ?></p>
                    </div>
                </div>
                <div class="text-sm text-gray-600 space-y-2 mb-4">
                    <p>📧 <?php echo htmlspecialchars($emp['email']); ?></p>
                    <p>📱 <?php echo htmlspecialchars($emp['phone']); ?></p>
                    <p>💼 <?php echo ucfirst($emp['status']); ?></p>
                </div>
                <div class="border-t pt-4">
                    <a href="view_employee.php?id=<?php echo $emp['id']; ?>" class="block w-full text-center bg-gray-50 text-blue-600 py-2 rounded hover:bg-blue-50 font-semibold">
                        View History & Details
                    </a>
                    <a href="edit_employee.php?id=<?php echo $emp['id']; ?>" class="block w-full text-center bg-yellow-50 text-black-600 py-2 rounded hover:bg-blue-50 font-semibold">Edit</a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </main>
</body>
</html>