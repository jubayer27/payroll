<?php
// admin/salary_settings.php
session_start();
require_once '../config/db.php';

// 1. Security Check
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    die("Access denied");
}

$message = "";
$error = "";

// 2. Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fields = [
        // Work Times
        'work_start_time', 'work_end_time', 
        'break_start', 'break_end', 'break_duration', 
        'allow_early_punch_minutes',
        
        // Overtime & Full Time
        'overtime_start', 'overtime_end', 'fulltime_week_days', 
        'annual_leave_days', 'sick_leave_days', 
        'maternity_leave_days', // [NEW]
        
        // Part Time
        'parttime_hourly_rate', 'parttime_start_time', 'parttime_end_time',
        
        // Financials
        'perfect_attendance_bonus', 'extra_day_pay', 'salesperson_commission',
        'public_holiday_pay_ratio', // [NEW] Double Pay setting
        
        // Fines & Penalties
        'late_fine_per_5min', 'double_absence_penalty', 'leave_without_notice_fine', 
        'rejected_leave_fine', 'advance_salary_limit',
        
        // Misc
        'remarks'
    ];

    $data = [];
    foreach ($fields as $f) {
        $data[$f] = $_POST[$f] ?? null;
    }
    
    // Checkboxes
    $parttime_work_days = isset($_POST['parttime_work_days']) ? implode(',', $_POST['parttime_work_days']) : '1,2,3,4,5,6';
    $work_days = isset($_POST['work_days']) ? implode(',', $_POST['work_days']) : '1,2,3,4,5,6';

    try {
        $stmt = $conn->query("SELECT id FROM salary_rules WHERE id = 1");
        $exists = $stmt->fetch();

        if ($exists) {
            $sql = "UPDATE salary_rules SET 
                work_start_time = :work_start_time, work_end_time = :work_end_time,
                break_start = :break_start, break_end = :break_end, break_duration = :break_duration,
                allow_early_punch_minutes = :allow_early_punch_minutes, work_days = :work_days,
                overtime_start = :overtime_start, overtime_end = :overtime_end,
                fulltime_week_days = :fulltime_week_days,
                annual_leave_days = :annual_leave_days, sick_leave_days = :sick_leave_days,
                maternity_leave_days = :maternity_leave_days,
                parttime_hourly_rate = :parttime_hourly_rate, parttime_work_days = :parttime_work_days,
                parttime_start_time = :parttime_start_time, parttime_end_time = :parttime_end_time,
                perfect_attendance_bonus = :perfect_attendance_bonus, extra_day_pay = :extra_day_pay,
                salesperson_commission = :salesperson_commission,
                public_holiday_pay_ratio = :public_holiday_pay_ratio,
                late_fine_per_5min = :late_fine_per_5min, double_absence_penalty = :double_absence_penalty,
                leave_without_notice_fine = :leave_without_notice_fine, rejected_leave_fine = :rejected_leave_fine,
                advance_salary_limit = :advance_salary_limit, remarks = :remarks
                WHERE id = 1";
        } else {
            $sql = "INSERT INTO salary_rules (
                id, work_start_time, work_end_time, break_start, break_end, break_duration, allow_early_punch_minutes,
                work_days, overtime_start, overtime_end, fulltime_week_days, annual_leave_days, sick_leave_days, maternity_leave_days,
                parttime_hourly_rate, parttime_work_days, parttime_start_time, parttime_end_time,
                perfect_attendance_bonus, extra_day_pay, salesperson_commission, public_holiday_pay_ratio,
                late_fine_per_5min, double_absence_penalty, leave_without_notice_fine, rejected_leave_fine, 
                advance_salary_limit, remarks
            ) VALUES (
                1, :work_start_time, :work_end_time, :break_start, :break_end, :break_duration, :allow_early_punch_minutes,
                :work_days, :overtime_start, :overtime_end, :fulltime_week_days, :annual_leave_days, :sick_leave_days, :maternity_leave_days,
                :parttime_hourly_rate, :parttime_work_days, :parttime_start_time, :parttime_end_time,
                :perfect_attendance_bonus, :extra_day_pay, :salesperson_commission, :public_holiday_pay_ratio,
                :late_fine_per_5min, :double_absence_penalty, :leave_without_notice_fine, :rejected_leave_fine, 
                :advance_salary_limit, :remarks
            )";
        }

        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':parttime_work_days', $parttime_work_days);
        $stmt->bindValue(':work_days', $work_days);
        foreach ($fields as $f) {
            $stmt->bindValue(":$f", $data[$f]);
        }
        $stmt->execute();
        $message = "Salary rules updated successfully!";
    } catch (PDOException $e) {
        $error = "Database Error: " . $e->getMessage();
    }
}

// 3. Fetch Existing Rules
$stmt = $conn->query("SELECT * FROM salary_rules WHERE id = 1");
$rule = $stmt->fetch(PDO::FETCH_ASSOC);

// Defaults
if (!$rule) {
    $rule = [
        'work_start_time' => '10:00', 'work_end_time' => '19:00', 
        'break_start' => '13:00', 'break_end' => '14:00', 'break_duration' => 60,
        'allow_early_punch_minutes' => 30, 'work_days' => '1,2,3,4,5,6',
        'overtime_start' => '19:00', 'overtime_end' => '22:00',
        'fulltime_week_days' => 6, 'annual_leave_days' => 22, 'sick_leave_days' => 14,
        'maternity_leave_days' => 60,
        'parttime_hourly_rate' => 15, 'parttime_work_days' => '1,2,3,4,5,6',
        'parttime_start_time' => '10:00', 'parttime_end_time' => '18:00',
        'perfect_attendance_bonus' => 50, 'extra_day_pay' => 120, 'salesperson_commission' => 5,
        'public_holiday_pay_ratio' => 2.00,
        'late_fine_per_5min' => 5, 'double_absence_penalty' => 200,
        'leave_without_notice_fine' => 0, 'rejected_leave_fine' => 0, 
        'advance_salary_limit' => 0, 'remarks' => ''
    ];
}

$active_days = explode(',', $rule['work_days'] ?? '');
$pt_active_days = explode(',', $rule['parttime_work_days'] ?? '');
$days_map = [1 => 'Mon', 2 => 'Tue', 3 => 'Wed', 4 => 'Thu', 5 => 'Fri', 6 => 'Sat', 7 => 'Sun'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Salary Rules - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex font-sans">
    <?php include 'includes/sidebar.php'; ?>
    <main class="flex-1 p-8 h-screen overflow-y-auto">
        <div class="flex items-center justify-between mb-6">
            <h1 class="text-2xl font-bold text-gray-800">Global Salary Rules</h1>
        </div>
        <?php if($message): ?><div class="bg-green-100 text-green-700 p-4 rounded mb-6 border border-green-200"><?= $message ?></div><?php endif; ?>
        <?php if($error): ?><div class="bg-red-100 text-red-700 p-4 rounded mb-6 border border-red-200"><?= $error ?></div><?php endif; ?>

        <form method="POST" class="space-y-6">
            
            <div class="bg-white p-6 rounded-lg shadow border border-gray-100">
                <div class="bg-gray-50 -mx-6 -mt-6 px-6 py-3 border-b border-gray-100 mb-6 rounded-t-lg">
                    <h2 class="text-lg font-bold text-gray-700">🏢 General Work Settings</h2>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div><label class="block text-sm font-semibold text-gray-600 mb-1">Work Start</label><input type="time" name="work_start_time" value="<?= $rule['work_start_time'] ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label class="block text-sm font-semibold text-gray-600 mb-1">Work End</label><input type="time" name="work_end_time" value="<?= $rule['work_end_time'] ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label class="block text-sm font-semibold text-gray-600 mb-1">Break Start</label><input type="time" name="break_start" value="<?= $rule['break_start'] ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label class="block text-sm font-semibold text-gray-600 mb-1">Break End</label><input type="time" name="break_end" value="<?= $rule['break_end'] ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label class="block text-sm font-semibold text-gray-600 mb-1">Total Break (Mins)</label><input type="number" name="break_duration" value="<?= $rule['break_duration'] ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label class="block text-sm font-semibold text-gray-600 mb-1">Early Punch Tolerance</label><input type="number" name="allow_early_punch_minutes" value="<?= $rule['allow_early_punch_minutes'] ?>" class="w-full border rounded px-3 py-2"></div>
                    <div class="md:col-span-4"><label class="block text-sm font-semibold text-gray-600 mb-2">Company Working Days</label><div class="flex gap-4"><?php foreach($days_map as $key => $day): ?><label class="inline-flex items-center"><input type="checkbox" name="work_days[]" value="<?= $key ?>" class="form-checkbox h-4 w-4 text-blue-600" <?= in_array($key, $active_days) ? 'checked' : '' ?>><span class="ml-2 text-gray-700"><?= $day ?></span></label><?php endforeach; ?></div></div>
                </div>
            </div>

            <div class="bg-white p-6 rounded-lg shadow border border-gray-100">
                <div class="bg-gray-50 -mx-6 -mt-6 px-6 py-3 border-b border-gray-100 mb-6 rounded-t-lg">
                    <h2 class="text-lg font-bold text-gray-700">📅 Leaves & Overtime</h2>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div><label class="block text-sm font-semibold text-gray-600 mb-1">Annual Leave (Days)</label><input type="number" name="annual_leave_days" value="<?= $rule['annual_leave_days'] ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label class="block text-sm font-semibold text-gray-600 mb-1">Sick Leave (Days)</label><input type="number" name="sick_leave_days" value="<?= $rule['sick_leave_days'] ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label class="block text-sm font-bold text-pink-600 mb-1">Maternity Leave (Days)</label><input type="number" name="maternity_leave_days" value="<?= $rule['maternity_leave_days'] ?>" class="w-full border border-pink-200 rounded px-3 py-2 bg-pink-50"></div>
                    <div><label class="block text-sm font-semibold text-gray-600 mb-1">Full-Time Days/Week</label><input type="number" name="fulltime_week_days" value="<?= $rule['fulltime_week_days'] ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label class="block text-sm font-semibold text-gray-600 mb-1">Overtime Start</label><input type="time" name="overtime_start" value="<?= $rule['overtime_start'] ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label class="block text-sm font-semibold text-gray-600 mb-1">Overtime End</label><input type="time" name="overtime_end" value="<?= $rule['overtime_end'] ?>" class="w-full border rounded px-3 py-2"></div>
                </div>
            </div>

            <div class="bg-white p-6 rounded-lg shadow border border-gray-100">
                <div class="bg-gray-50 -mx-6 -mt-6 px-6 py-3 border-b border-gray-100 mb-6 rounded-t-lg">
                    <h2 class="text-lg font-bold text-gray-700">⏳ Part-Time Defaults</h2>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div><label class="block text-sm font-semibold text-gray-600 mb-1">Hourly Rate (RM)</label><input type="number" step="0.01" name="parttime_hourly_rate" value="<?= $rule['parttime_hourly_rate'] ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label class="block text-sm font-semibold text-gray-600 mb-1">Start Time</label><input type="time" name="parttime_start_time" value="<?= $rule['parttime_start_time'] ?>" class="w-full border rounded px-3 py-2"></div>
                    <div><label class="block text-sm font-semibold text-gray-600 mb-1">End Time</label><input type="time" name="parttime_end_time" value="<?= $rule['parttime_end_time'] ?>" class="w-full border rounded px-3 py-2"></div>
                    <div class="md:col-span-4 mt-2"><label class="block text-sm font-semibold text-gray-600 mb-2">Part-Time Allowed Days</label><div class="flex gap-4"><?php foreach($days_map as $key => $day): ?><label class="inline-flex items-center"><input type="checkbox" name="parttime_work_days[]" value="<?= $key ?>" class="form-checkbox h-4 w-4 text-purple-600" <?= in_array($key, $pt_active_days) ? 'checked' : '' ?>><span class="ml-2 text-gray-700"><?= $day ?></span></label><?php endforeach; ?></div></div>
                </div>
            </div>

            <div class="bg-white p-6 rounded-lg shadow border border-gray-100">
                <div class="bg-gray-50 -mx-6 -mt-6 px-6 py-3 border-b border-gray-100 mb-6 rounded-t-lg flex justify-between items-center"><h2 class="text-lg font-bold text-gray-700">💰 Financials & Penalties</h2></div>
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div class="md:col-span-4 grid grid-cols-1 md:grid-cols-4 gap-6 mb-4 border-b pb-6">
                        <div><label class="block text-sm font-bold text-green-700 mb-1">Perfect Attendance (RM)</label><input type="number" step="0.01" name="perfect_attendance_bonus" value="<?= $rule['perfect_attendance_bonus'] ?>" class="w-full border border-green-200 rounded px-3 py-2 bg-green-50"></div>
                        <div><label class="block text-sm font-bold text-green-700 mb-1">Public Hol. Pay Ratio</label><input type="number" step="0.01" name="public_holiday_pay_ratio" value="<?= $rule['public_holiday_pay_ratio'] ?>" class="w-full border border-green-200 rounded px-3 py-2 bg-green-50" placeholder="2.0"></div>
                        <div><label class="block text-sm font-bold text-blue-700 mb-1">Sales Commission (%)</label><input type="number" step="0.01" name="salesperson_commission" value="<?= $rule['salesperson_commission'] ?>" class="w-full border border-blue-200 rounded px-3 py-2 bg-blue-50"></div>
                        <div><label class="block text-sm font-semibold text-gray-600 mb-1">Advance Limit (RM)</label><input type="number" step="0.01" name="advance_salary_limit" value="<?= $rule['advance_salary_limit'] ?>" class="w-full border rounded px-3 py-2"></div>
                    </div>
                    <div><label class="block text-sm font-bold text-red-600 mb-1">Late Fine (Per 5 min)</label><input type="number" step="0.01" name="late_fine_per_5min" value="<?= $rule['late_fine_per_5min'] ?>" class="w-full border border-red-200 rounded px-3 py-2 bg-red-50"></div>
                    <div><label class="block text-sm font-bold text-red-600 mb-1">Penalty: Absent (No Notice)</label><input type="number" step="0.01" name="double_absence_penalty" value="<?= $rule['double_absence_penalty'] ?>" class="w-full border border-red-200 rounded px-3 py-2 bg-red-50"></div>
                    <div><label class="block text-sm font-bold text-red-800 mb-1">Fine: Leave w/o Notice</label><input type="number" step="0.01" name="leave_without_notice_fine" value="<?= $rule['leave_without_notice_fine'] ?>" class="w-full border border-red-300 rounded px-3 py-2 bg-red-100"></div>
                    <div><label class="block text-sm font-bold text-red-900 mb-1">Fine: Rejected Leave Taken</label><input type="number" step="0.01" name="rejected_leave_fine" value="<?= $rule['rejected_leave_fine'] ?>" class="w-full border border-red-400 rounded px-3 py-2 bg-red-200"></div>
                </div>
            </div>

            <div class="flex justify-end pt-4 pb-12">
                <button type="submit" class="bg-blue-600 text-white font-bold py-3 px-8 rounded-lg shadow-lg hover:bg-blue-700 hover:scale-105 transition transform">Save Configuration</button>
            </div>
        </form>
    </main>
</body>
</html>