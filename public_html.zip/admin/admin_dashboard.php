<?php
// admin/dashboard.php

// 1. ENABLE ERROR REPORTING (Remove this line when going live)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once '../config/db.php';

// 2. Security Check
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

// 3. Fetch Today's Stats
$today = date('Y-m-d');

// Count Total Active Employees
$totalEmpStmt = $conn->query("SELECT COUNT(*) FROM employees WHERE status='active'");
$totalEmployees = $totalEmpStmt->fetchColumn();

// Count Present (Everyone who scanned today)
$presentStmt = $conn->prepare("SELECT COUNT(DISTINCT employee_id) FROM attendance WHERE DATE(scanned_at) = ?");
$presentStmt->execute([$today]);
$presentCount = $presentStmt->fetchColumn();

// Count Late
$lateStmt = $conn->prepare("SELECT COUNT(DISTINCT employee_id) FROM attendance WHERE DATE(scanned_at) = ? AND status = 'late'");
$lateStmt->execute([$today]);
$lateCount = $lateStmt->fetchColumn();

// Count On Leave (Approved leaves spanning today)
$leaveStmt = $conn->prepare("SELECT COUNT(*) FROM leaves WHERE ? BETWEEN from_date AND to_date AND status = 'approved'");
$leaveStmt->execute([$today]);
$leaveCount = $leaveStmt->fetchColumn();

// Calculate Absent (Total Active - Present - On Leave)
// Note: This is an approximation. Real-time accuracy depends on shift start times.
$absentCount = $totalEmployees - $presentCount - $leaveCount;
if ($absentCount < 0) $absentCount = 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - HRM</title>
    <script src="https://cdn.tailwindcss.com"></script>
    
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.js'></script>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        /* Custom Scrollbar for Calendar Events */
        .fc-event-title { font-size: 0.75rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .fc-daygrid-event { cursor: pointer; }
    </style>
</head>
<body class="bg-gray-100 font-sans">

    <div class="flex h-screen overflow-hidden">
        
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="flex-1 flex flex-col overflow-y-auto">
            
            <header class="bg-white shadow p-4 flex justify-between items-center sticky top-0 z-20">
                <div>
                    <h2 class="text-xl font-bold text-gray-800">Dashboard Overview</h2>
                    <p class="text-gray-500 text-sm flex items-center gap-2">
                        <span><?php echo date('l, d F Y'); ?></span>
                        <span class="text-gray-300">|</span>
                        <span id="live-clock" class="font-mono font-bold text-blue-600">--:--:--</span>
                    </p>
                </div>
                
                <a href="../attender/attender_dashboard.php" target="_blank" class="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 shadow-lg transition transform hover:scale-105">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z"></path></svg>
                    <span>Launch Kiosk</span>
                </a>
            </header>

            <main class="p-6">
                
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <div class="bg-white p-6 rounded-xl shadow-sm border-l-4 border-green-500 hover:shadow-md transition">
                        <div class="text-gray-500 text-xs font-bold uppercase tracking-wider">Scanned Today</div>
                        <div class="flex items-end mt-2">
                            <div class="text-3xl font-bold text-gray-800"><?php echo $presentCount; ?></div>
                            <div class="text-sm text-green-600 font-semibold ml-2 mb-1">Present</div>
                        </div>
                    </div>

                    <div class="bg-white p-6 rounded-xl shadow-sm border-l-4 border-yellow-500 hover:shadow-md transition">
                        <div class="text-gray-500 text-xs font-bold uppercase tracking-wider">Late Arrivals</div>
                        <div class="flex items-end mt-2">
                            <div class="text-3xl font-bold text-gray-800"><?php echo $lateCount; ?></div>
                            <div class="text-sm text-yellow-600 font-semibold ml-2 mb-1">Late</div>
                        </div>
                    </div>

                    <div class="bg-white p-6 rounded-xl shadow-sm border-l-4 border-blue-500 hover:shadow-md transition">
                        <div class="text-gray-500 text-xs font-bold uppercase tracking-wider">On Leave</div>
                        <div class="flex items-end mt-2">
                            <div class="text-3xl font-bold text-gray-800"><?php echo $leaveCount; ?></div>
                            <div class="text-sm text-blue-600 font-semibold ml-2 mb-1">Approved</div>
                        </div>
                    </div>

                    <div class="bg-white p-6 rounded-xl shadow-sm border-l-4 border-red-500 hover:shadow-md transition">
                        <div class="text-gray-500 text-xs font-bold uppercase tracking-wider">Absent / Pending</div>
                        <div class="flex items-end mt-2">
                            <div class="text-3xl font-bold text-gray-800"><?php echo $absentCount; ?></div>
                            <div class="text-sm text-red-600 font-semibold ml-2 mb-1">Unaccounted</div>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-xl shadow p-6">
                    <div class="flex flex-col md:flex-row justify-between items-center mb-6">
                        <div>
                            <h3 class="text-lg font-bold text-gray-800">📅 Staff Schedule & Holidays</h3>
                            <p class="text-sm text-gray-500">View who is working today or scheduled for the month.</p>
                        </div>
                        
                        <div class="flex gap-4 text-xs mt-4 md:mt-0 bg-gray-50 p-2 rounded-lg">
                            <div class="flex items-center">
                                <span class="w-3 h-3 bg-blue-500 rounded-full mr-2"></span>
                                <span class="font-semibold text-gray-600">Staff Scheduled</span>
                            </div>
                            <div class="flex items-center">
                                <span class="w-3 h-3 bg-red-500 rounded-full mr-2"></span>
                                <span class="font-semibold text-gray-600">Holiday</span>
                            </div>
                        </div>
                    </div>
                    
                    <div id="calendar" class="min-h-[600px]"></div>
                </div>

            </main>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');
            
            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,listWeek'
                },
                height: 'auto',
                
                // DATA SOURCE: Using the API we created to fetch working days & holidays
                events: 'api_calendar_schedule.php',

                // Custom Styling for Event Bars
                eventClassNames: function(arg) {
                    return ['hover:opacity-75', 'transition', 'duration-200'];
                },

                // EVENT CLICK HANDLER
                eventClick: function(info) {
                    // Prevent default navigation
                    info.jsEvent.preventDefault();

                    // If it's a holiday (Red events usually)
                    if (info.event.backgroundColor === '#ef4444') {
                        Swal.fire({
                            title: info.event.title,
                            text: 'This is a public holiday.',
                            icon: 'info',
                            confirmButtonColor: '#3b82f6'
                        });
                    } 
                    // If it's a Staff Member (Blue events)
                    else {
                        Swal.fire({
                            title: 'Staff Schedule',
                            text: info.event.title + ' is scheduled to work on this day.',
                            icon: 'info',
                            confirmButtonColor: '#3b82f6'
                        });
                    }
                },
                
                // Loading State
                loading: function(isLoading) {
                    if (isLoading) {
                        // Optional: Show a spinner or loading text
                    }
                }
            });
            
            calendar.render();
        });

        // Live Clock Function
        function updateClock() {
            const now = new Date();
            const timeString = now.toLocaleTimeString('en-US', { 
                hour: '2-digit', 
                minute: '2-digit', 
                second: '2-digit' 
            });
            document.getElementById('live-clock').innerText = timeString;
        }
    
        // Start Clock
        updateClock();
        setInterval(updateClock, 1000);
    </script>
</body>
</html>