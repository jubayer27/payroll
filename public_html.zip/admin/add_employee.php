<?php
// admin/add_employee.php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

$message = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Personal Info
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $nic = trim($_POST['nic']); // New: IC/Passport
    $nationality = $_POST['nationality']; // New
    $race = trim($_POST['race']); // New
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    
    // 2. Job Info
    $department = trim($_POST['department']);
    $employment_type = $_POST['employment_type']; // New: Full/Part time
    
    // Handle Dates
    $join_date = !empty($_POST['join_date']) ? $_POST['join_date'] : date('Y-m-d');
    $resign_date = !empty($_POST['resign_date']) ? $_POST['resign_date'] : null; // New

    // Salary & Benefits
    $salary_type = $_POST['salary_type'];
    $salary_amount = $_POST['salary_amount'];
    $transport_allowance = !empty($_POST['transport_allowance']) ? $_POST['transport_allowance'] : 0.00; // New
    $custom_sick_leave = !empty($_POST['custom_sick_leave_days']) ? $_POST['custom_sick_leave_days'] : null; // New

    // Handle Shift Times (Only save if provided/relevant)
    $shift_start = !empty($_POST['shift_start']) ? $_POST['shift_start'] : null; // New
    $shift_end = !empty($_POST['shift_end']) ? $_POST['shift_end'] : null; // New
    
    // 3. Bank Info
    $bank_name = trim($_POST['bank_name']);
    $bank_account = trim($_POST['bank_account']);
    $account_holder_name = trim($_POST['account_holder_name']);

    // 4. Login Access
    $username = trim($_POST['username']);
    $raw_password = $_POST['password'];
    $role = $_POST['role']; 
    $password_hash = password_hash($raw_password, PASSWORD_DEFAULT);
    
    // Work Days
    $work_days = isset($_POST['work_days']) ? implode(',', $_POST['work_days']) : '';

    try {
        $conn->beginTransaction();

        // A. Insert into EMPLOYEES (Profile)
        $sqlEmp = "INSERT INTO employees 
            (first_name, last_name, nic, nationality, race, email, phone, 
             department, employment_type, join_date, resign_date,
             salary_type, salary_amount, transport_allowance, custom_sick_leave_days,
             shift_start, shift_end,
             bank_name, bank_account, account_holder_name,
             status, username, password, work_days) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?)";
        
        $stmt = $conn->prepare($sqlEmp);
        $stmt->execute([
            $first_name, $last_name, $nic, $nationality, $race, $email, $phone,
            $department, $employment_type, $join_date, $resign_date,
            $salary_type, $salary_amount, $transport_allowance, $custom_sick_leave,
            $shift_start, $shift_end,
            $bank_name, $bank_account, $account_holder_name,
            $username, $password_hash, $work_days
        ]);
        
        // B. Insert into EMPLOYEES_USERS (Login Table)
        // Note: We also save NIC here as per your schema structure
        $sqlUser = "INSERT INTO employees_users 
            (first_name, last_name, nic, email, phone, department, salary_type, salary_amount, 
             status, join_date, username, password_hash, role) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, ?)";
        
        $stmtUser = $conn->prepare($sqlUser);
        $stmtUser->execute([
            $first_name, $last_name, $nic, $email, $phone, $department, 
            $salary_type, $salary_amount, $join_date, $username, $password_hash, $role
        ]);

        $conn->commit();
        $message = "Employee added successfully!";

    } catch (PDOException $e) {
        $conn->rollBack();
        $error = "Error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Employee</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex font-sans">
    
    <?php include 'includes/sidebar.php'; ?>

    <main class="flex-1 p-8 h-screen overflow-y-auto">
        <h1 class="text-2xl font-bold text-gray-800 mb-6">Onboard New Employee</h1>

        <?php if($message): ?>
            <div class="bg-green-100 text-green-700 p-4 rounded mb-6 border border-green-200"><?= $message ?></div>
        <?php endif; ?>
        <?php if($error): ?>
            <div class="bg-red-100 text-red-700 p-4 rounded mb-6 border border-red-200"><?= $error ?></div>
        <?php endif; ?>

        <form method="POST" class="space-y-6">
            
            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-lg font-bold text-gray-700 mb-4 border-b pb-2">Personal Information</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">First Name</label>
                        <input type="text" name="first_name" required class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Last Name</label>
                        <input type="text" name="last_name" required class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">IC / Passport No.</label>
                        <input type="text" name="nic" required class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Nationality</label>
                        <select name="nationality" class="w-full border rounded px-3 py-2 bg-white">
                            <option value="Malaysian">Malaysian</option>
                            <option value="Foreigner">Foreigner</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Race</label>
                        <input type="text" name="race" placeholder="e.g. Malay, Chinese" class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Phone</label>
                        <input type="text" name="phone" required class="w-full border rounded px-3 py-2">
                    </div>
                    <div class="md:col-span-3">
                        <label class="block text-sm text-gray-600 mb-1">Email</label>
                        <input type="email" name="email" required class="w-full border rounded px-3 py-2">
                    </div>
                </div>
            </div>

            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-lg font-bold text-gray-700 mb-4 border-b pb-2">Job & Employment Details</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Department</label>
                        <select name="department" class="w-full border rounded px-3 py-2 bg-white">
                            <option>Sales</option>
                            <option>IT</option>
                            <option>HR</option>
                            <option>Stock</option>
                            <option>HQ</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Employment Type</label>
                        <select name="employment_type" id="empType" onchange="togglePartTime()" class="w-full border rounded px-3 py-2 bg-white">
                            <option value="full_time">Full Time</option>
                            <option value="part_time">Part Time</option>
                            <option value="contract">Contract</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Start Date (Join)</label>
                        <input type="date" name="join_date" value="<?= date('Y-m-d') ?>" class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">End Date (Resign)</label>
                        <input type="date" name="resign_date" class="w-full border rounded px-3 py-2 text-gray-400">
                    </div>

                    <div class="part-time-field hidden">
                        <label class="block text-sm font-bold text-purple-600 mb-1">Shift Start</label>
                        <input type="time" name="shift_start" class="w-full border border-purple-200 rounded px-3 py-2 bg-purple-50">
                    </div>
                    <div class="part-time-field hidden">
                        <label class="block text-sm font-bold text-purple-600 mb-1">Shift End</label>
                        <input type="time" name="shift_end" class="w-full border border-purple-200 rounded px-3 py-2 bg-purple-50">
                    </div>
                </div>

                <div class="mt-4 bg-gray-50 p-3 rounded border">
                    <label class="block text-xs font-bold text-gray-500 uppercase mb-2">Working Days</label>
                    <div class="flex flex-wrap gap-4">
                        <?php 
                        $days = [1=>'Mon', 2=>'Tue', 3=>'Wed', 4=>'Thu', 5=>'Fri', 6=>'Sat', 7=>'Sun'];
                        foreach($days as $num => $name): ?>
                            <label class="inline-flex items-center text-sm">
                                <input type="checkbox" name="work_days[]" value="<?= $num ?>" 
                                <?= ($num <= 6) ? 'checked' : '' ?> class="mr-1 text-blue-600">
                                <?= $name ?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-lg font-bold text-gray-700 mb-4 border-b pb-2">Salary & Benefits</h3>
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Salary Type</label>
                        <select name="salary_type" class="w-full border rounded px-3 py-2 bg-white">
                            <option value="fixed">Fixed Monthly</option>
                            <option value="hourly">Hourly</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Basic Amount (RM)</label>
                        <input type="number" step="0.01" name="salary_amount" class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Transport Allowance (RM)</label>
                        <input type="number" step="0.01" name="transport_allowance" class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Sick Leave Limit (Days)</label>
                        <input type="number" name="custom_sick_leave_days" placeholder="Global Default" class="w-full border rounded px-3 py-2">
                    </div>
                </div>
            </div>

            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-lg font-bold text-gray-700 mb-4 border-b pb-2">Bank Details</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Bank Name</label>
                        <input type="text" name="bank_name" placeholder="e.g. Maybank" class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Account Number</label>
                        <input type="text" name="bank_account" class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Account Holder Name</label>
                        <input type="text" name="account_holder_name" class="w-full border rounded px-3 py-2">
                    </div>
                </div>
            </div>

            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-lg font-bold text-gray-700 mb-4 border-b pb-2">System Access</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">System Role</label>
                        <select name="role" class="w-full border rounded px-3 py-2 bg-white border-blue-300">
                            <option value="staff">Staff (Standard)</option>
                            <option value="admin">Administrator</option>
                            <option value="attender">Attendance Kiosk</option>
                            <option value="breaker">Lunch Station</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Username</label>
                        <input type="text" name="username" required class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm text-gray-600 mb-1">Password</label>
                        <input type="text" name="password" required class="w-full border rounded px-3 py-2" placeholder="Initial Password">
                    </div>
                </div>
            </div>

            <div class="flex justify-end pb-8">
                <button type="submit" class="bg-blue-600 text-white font-bold py-3 px-8 rounded hover:bg-blue-700 shadow-lg transform transition hover:scale-105">
                    Create Employee Profile
                </button>
            </div>

        </form>
    </main>

    <script>
        function togglePartTime() {
            const type = document.getElementById('empType').value;
            const fields = document.querySelectorAll('.part-time-field');
            fields.forEach(f => {
                if(type === 'part_time'){
                    f.classList.remove('hidden');
                } else {
                    f.classList.add('hidden');
                }
            });
        }
    </script>
</body>
</html>