<?php
// admin/api_request_handler.php

// 1. Error Reporting (Crucial for debugging)
ini_set('display_errors', 0);
error_reporting(E_ALL);

session_start();
require_once '../config/db.php';
header('Content-Type: application/json');

function sendJson($status, $message) {
    echo json_encode(['status' => $status, 'message' => $message]);
    exit;
}

$action = $_GET['action'] ?? '';

// --- ACTION: PROCESS REQUEST ---
if ($action === 'process') {
    // 1. Security Check
    if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
        sendJson('error', 'Unauthorized');
    }

    // 2. Get Inputs
    $reqId = $_POST['request_id'] ?? 0;
    $status = $_POST['status'] ?? '';
    $type = $_POST['type'] ?? '';
    $empId = $_POST['employee_id'] ?? 0;
    $comment = $_POST['admin_comment'] ?? '';

    if (!$reqId || !$status) sendJson('error', 'Missing ID or Status');

    try {
        $conn->beginTransaction();

        // 3. Update Request Table Status
        $stmt = $conn->prepare("UPDATE requests SET status = ?, admin_comment = ? WHERE id = ?");
        $stmt->execute([$status, $comment, $reqId]);

        // 4. IF APPROVED, UPDATE REAL DATA TABLES
        if ($status === 'approved') {
            
            // --- TYPE A: ATTENDANCE CORRECTION ---
            if ($type === 'attendance_correction') {
                $date = $_POST['final_date'];
                $time = $_POST['final_time'];
                $scanType = $_POST['final_scan_type'];
                
                if(!$date || !$time) throw new Exception("Date and Time required");
                
                $dateTime = "$date $time:00";

                // Delete potential duplicate first to avoid errors
                $del = $conn->prepare("DELETE FROM attendance WHERE employee_id=? AND DATE(scanned_at)=? AND type=?");
                $del->execute([$empId, $date, $scanType]);

                // Insert Correction (Marked as manual entry)
                $ins = $conn->prepare("INSERT INTO attendance (employee_id, scanned_at, type, status, is_manual_entry, admin_approval_status) VALUES (?, ?, ?, 'present', 1, 'approved')");
                $ins->execute([$empId, $dateTime, $scanType]);

            // --- TYPE B: LEAVE APPROVAL ---
            } elseif ($type === 'leave') {
                $lType = $_POST['final_leave_type'];
                $from = $_POST['final_from'];
                $to = $_POST['final_to'];
                
                if(!$from || !$to) throw new Exception("Dates required");

                // Calculate number of days
                $days = (strtotime($to) - strtotime($from)) / (60 * 60 * 24) + 1;

                $ins = $conn->prepare("INSERT INTO leaves (employee_id, leave_type, from_date, to_date, days_count, reason, status) VALUES (?, ?, ?, ?, ?, ?, 'approved')");
                $ins->execute([$empId, $lType, $from, $to, $days, "Approved Request #$reqId"]);

            // --- TYPE C: SCHEDULE SWITCH ---
            } elseif ($type === 'schedule_switch') {
                $workDate = $_POST['final_work_date'];
                $offDate = $_POST['final_off_date'];

                // Remove existing adjustments for these dates
                $delAdj = $conn->prepare("DELETE FROM schedule_adjustments WHERE employee_id=? AND adjustment_date=?");
                
                // Insert New Adjustments
                $insAdj = $conn->prepare("INSERT INTO schedule_adjustments (employee_id, adjustment_date, type, status, reason) VALUES (?, ?, ?, 'approved', ?)");

                if (!empty($workDate)) {
                    $delAdj->execute([$empId, $workDate]);
                    $insAdj->execute([$empId, $workDate, 'work', 'Switch Approved']);
                }
                if (!empty($offDate)) {
                    $delAdj->execute([$empId, $offDate]);
                    $insAdj->execute([$empId, $offDate, 'off', 'Switch Approved']);
                }

            // --- TYPE D: PART TIME PROFILE CHANGE ---
            } elseif ($type === 'part_time_change') {
                $days = $_POST['final_days']; 
                
                // FIX: Handle Empty Time Values (Convert "" to NULL)
                // Database time columns cannot accept empty strings
                $start = !empty($_POST['final_start']) ? $_POST['final_start'] : null;
                $end = !empty($_POST['final_end']) ? $_POST['final_end'] : null;

                $upd = $conn->prepare("UPDATE employees SET work_days=?, shift_start=?, shift_end=? WHERE id=?");
                $upd->execute([$days, $start, $end, $empId]);
            }
        }

        $conn->commit();
        sendJson('success', 'Request processed successfully');

    } catch (PDOException $e) {
        $conn->rollBack();
        sendJson('error', 'Database Error: ' . $e->getMessage());
    } catch (Exception $e) {
        $conn->rollBack();
        sendJson('error', 'Error: ' . $e->getMessage());
    }
} else {
    sendJson('error', 'Invalid Action');
}
?>