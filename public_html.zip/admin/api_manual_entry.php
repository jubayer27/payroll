<?php
// admin/api_manual_entry.php
session_start();
require_once '../config/db.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    echo json_encode(['status' => 'error', 'message' => 'Access Denied']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $emp_id = $_POST['employee_id'];
    $date = $_POST['date']; // YYYY-MM-DD
    $time = $_POST['time']; // HH:MM
    $type = $_POST['type']; // morning, lunch_start, lunch_end, leave

    if (!$emp_id || !$date || !$time || !$type) {
        echo json_encode(['status' => 'error', 'message' => 'Missing fields']);
        exit;
    }

    $scanned_at = $date . ' ' . $time . ':00';
    $status = 'present';

    try {
        // 1. Calculate Late Status if Morning
        if ($type === 'morning') {
            // Fetch employee shift start logic or use global rule
            // For simplicity here, we assume standard 10am rule or fetch from salary_rules
            $rules = $conn->query("SELECT work_start_time, allow_early_punch_minutes FROM salary_rules LIMIT 1")->fetch();
            $work_start = $rules['work_start_time'] ?? '10:00:00';
            
            // Calculate lateness
            $scan_time_str = date('H:i:s', strtotime($time));
            if ($scan_time_str > $work_start) {
                $status = 'late';
            }
        } elseif ($type === 'leave') {
            // Note: In your DB schema, 'leave' type = Clock Out
            // We don't change status to 'on_leave' here, as that is for the Leaves table
            $status = 'present'; 
        }

        // 2. Check if record already exists for this type on this day
        // (Optional: You might want to allow overwriting, but inserting is safer for logs)
        $stmtCheck = $conn->prepare("SELECT id FROM attendance WHERE employee_id = ? AND DATE(scanned_at) = ? AND type = ?");
        $stmtCheck->execute([$emp_id, $date, $type]);
        $existing = $stmtCheck->fetch();

        if ($existing) {
            // Update existing record
            $stmt = $conn->prepare("UPDATE attendance SET scanned_at = ?, status = ? WHERE id = ?");
            $stmt->execute([$scanned_at, $status, $existing['id']]);
            $msg = "Record updated successfully.";
        } else {
            // Insert new record
            $stmt = $conn->prepare("INSERT INTO attendance (employee_id, scanned_at, type, status, created_at) VALUES (?, ?, ?, ?, NOW())");
            $stmt->execute([$emp_id, $scanned_at, $type, $status]);
            $msg = "Manual entry added successfully.";
        }

        echo json_encode(['status' => 'success', 'message' => $msg]);

    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}
?>