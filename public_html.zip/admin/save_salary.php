<?php
// admin/save_salary.php
require_once '../config/db.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Request']);
    exit;
}

$raw = $_POST['data'] ?? '';
$data = json_decode($raw, true);

if (!$data) {
    echo json_encode(['status' => 'error', 'message' => 'No data received']);
    exit;
}

$empId = $data['employee_id'];
$month = $data['month'];
$f = $data['financials'];

try {
    // 1. Check if payslip exists for this month
    $stmtCheck = $conn->prepare("SELECT id FROM payslips WHERE employee_id = ? AND month_year = ?");
    $stmtCheck->execute([$empId, $month]);
    $exists = $stmtCheck->fetch();

    if ($exists) {
        // Update
        $sql = "UPDATE payslips SET 
            basic_salary = :basic,
            allowances = :allow,
            commissions = :comm,
            bonus = :bonus,
            deductions = :deduct,
            net_salary = :net,
            generated_at = NOW()
            WHERE id = :id";
        
        $params = [
            ':basic' => $f['basic_salary'],
            ':allow' => ($f['transport_allowance'] + $f['claims']),
            ':comm' => $f['commission'],
            ':bonus' => ($f['manual_bonus'] + $f['perfect_attendance']),
            ':deduct' => $f['total_deductions'],
            ':net' => $f['net_salary'],
            ':id' => $exists['id']
        ];
    } else {
        // Insert
        $sql = "INSERT INTO payslips (employee_id, month_year, basic_salary, allowances, commissions, bonus, deductions, net_salary, generated_at)
                VALUES (:eid, :my, :basic, :allow, :comm, :bonus, :deduct, :net, NOW())";
        
        $params = [
            ':eid' => $empId,
            ':my' => $month,
            ':basic' => $f['basic_salary'],
            ':allow' => ($f['transport_allowance'] + $f['claims']),
            ':comm' => $f['commission'],
            ':bonus' => ($f['manual_bonus'] + $f['perfect_attendance']),
            ':deduct' => $f['total_deductions'],
            ':net' => $f['net_salary']
        ];
    }

    $stmt = $conn->prepare($sql);
    $stmt->execute($params);

    echo json_encode(['status' => 'success', 'message' => 'Payslip saved']);

} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>