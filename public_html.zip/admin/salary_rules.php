<?php
session_start();
require_once "../config/db.php";

// ONLY ADMIN
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    die("Access denied");
}

// FETCH EXISTING RULES
$stmt = $conn->query("SELECT * FROM salary_rules ORDER BY id DESC LIMIT 1");
$rule = $stmt->fetch(PDO::FETCH_ASSOC);

// HANDLE FORM SUBMISSION
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fields = [
        'work_start_time','work_end_time','break_start','break_end','allow_early_punch_minutes','work_days',
        'public_holidays','overtime_start','overtime_end','fulltime_week_days','annual_leave_days','sick_leave_days',
        'perfect_attendance_bonus','unpaid_leave_deduction','extra_day_pay','salesperson_commission',
        'parttime_hourly_rate','parttime_work_days','parttime_start_time','parttime_end_time',
        // ADDED 'leave_without_notice_fine' HERE
        'late_fine_per_5min','double_absence_penalty','leave_without_notice_fine','advance_salary_limit','remarks'
    ];

    $data = [];
    foreach ($fields as $f) {
        $data[$f] = $_POST[$f] ?? null;
    }

    if ($rule) {
        // UPDATE
        $setStr = implode(", ", array_map(fn($f) => "$f = :$f", $fields));
        $sql = "UPDATE salary_rules SET $setStr WHERE id = ".$rule['id'];
    } else {
        // INSERT
        $cols = implode(",", $fields);
        $vals = implode(",", array_map(fn($f)=>":$f",$fields));
        $sql = "INSERT INTO salary_rules ($cols) VALUES ($vals)";
    }

    $stmt2 = $conn->prepare($sql);
    $stmt2->execute($data);
    header("Location: salary_rules.php");
    exit;
}
include __DIR__ . '/../includes/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Salary Rules - Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
<style>
body { background: #f4f6f9; }
.sidebar { height:100vh; background:#EE4B2B; color:white; padding-top:20px; position:fixed; width:220px; }
.sidebar a { color:white; text-decoration:none; padding:12px 18px; display:block; }
.sidebar a:hover { background:#374151; color:white; }
.content { margin-left:230px; padding:20px; }
.card-custom { border-radius:12px; }
</style>
</head>
<body>

<div class="sidebar">
    <h4 class="text-center">ADMIN PANEL</h4>
    <a href="admin_dashboard.php"><i class="bi bi-grid"></i> Dashboard</a>
    <a href="notices.php"><i class="bi bi-megaphone"></i> Notice Board</a>
    <a href="staffs.php"><i class="bi bi-people"></i> Manage Staffs</a>
    <a href="attendance.php"><i class="bi bi-calendar-check"></i> Attendance</a>
    <a href="salary_rules.php"><i class="bi bi-gear"></i> Salary Rules</a>
    <a href="salary_calc.php"><i class="bi bi-calculator"></i> Calculate Salary</a>
    <a href="payslip_generate.php"><i class="bi bi-receipt"></i> Pay Slips</a>
    <a href="holidays.php"><i class="bi bi-calendar-event"></i> Holidays</a>
    <a href="../logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
</div>

<div class="content">
<h3 class="mb-4"><i class="bi bi-gear"></i> Salary Rules & Settings</h3>

<form method="POST">
    <div class="card shadow card-custom mb-4">
        <div class="card-header bg-dark text-white">General Settings</div>
        <div class="card-body row g-3">
            <div class="col-md-3"><label>Work Start</label><input type="time" name="work_start_time" class="form-control" value="<?= $rule['work_start_time'] ?? '10:00' ?>"></div>
            <div class="col-md-3"><label>Work End</label><input type="time" name="work_end_time" class="form-control" value="<?= $rule['work_end_time'] ?? '19:00' ?>"></div>
            <div class="col-md-3"><label>Break Start</label><input type="time" name="break_start" class="form-control" value="<?= $rule['break_start'] ?? '13:00' ?>"></div>
            <div class="col-md-3"><label>Break End</label><input type="time" name="break_end" class="form-control" value="<?= $rule['break_end'] ?? '14:00' ?>"></div>
            <div class="col-md-3"><label>Early Punch Allowed (min)</label><input type="number" name="allow_early_punch_minutes" class="form-control" value="<?= $rule['allow_early_punch_minutes'] ?? 30 ?>"></div>
            <div class="col-md-6"><label>Work Days (1=Mon ... 7=Sun, CSV)</label><input type="text" name="work_days" class="form-control" value="<?= $rule['work_days'] ?? '1,2,3,4,5,6' ?>"></div>
            <div class="col-md-12"><label>Public Holidays (CSV YYYY-MM-DD)</label><input type="text" name="public_holidays" class="form-control" value="<?= $rule['public_holidays'] ?? '' ?>"></div>
        </div>
    </div>

    <div class="card shadow card-custom mb-4">
        <div class="card-header bg-dark text-white">Full-Time Settings</div>
        <div class="card-body row g-3">
            <div class="col-md-3"><label>Overtime Start</label><input type="time" name="overtime_start" class="form-control" value="<?= $rule['overtime_start'] ?? '19:00' ?>"></div>
            <div class="col-md-3"><label>Overtime End</label><input type="time" name="overtime_end" class="form-control" value="<?= $rule['overtime_end'] ?? '22:00' ?>"></div>
            <div class="col-md-3"><label>Week Days</label><input type="number" name="fulltime_week_days" class="form-control" value="<?= $rule['fulltime_week_days'] ?? 6 ?>"></div>
            <div class="col-md-3"><label>Annual Leave Days</label><input type="number" name="annual_leave_days" class="form-control" value="<?= $rule['annual_leave_days'] ?? 22 ?>"></div>
            <div class="col-md-3"><label>Sick Leave Days</label><input type="number" name="sick_leave_days" class="form-control" value="<?= $rule['sick_leave_days'] ?? 14 ?>"></div>
            <div class="col-md-3"><label>Perfect Attendance Bonus</label><input type="number" step="0.01" name="perfect_attendance_bonus" class="form-control" value="<?= $rule['perfect_attendance_bonus'] ?? 50 ?>"></div>
            <div class="col-md-3"><label>Unpaid Leave Deduction</label><input type="number" step="0.01" name="unpaid_leave_deduction" class="form-control" value="<?= $rule['unpaid_leave_deduction'] ?? 100 ?>"></div>
            <div class="col-md-3"><label>Extra Day Pay</label><input type="number" step="0.01" name="extra_day_pay" class="form-control" value="<?= $rule['extra_day_pay'] ?? 120 ?>"></div>
            <div class="col-md-3"><label>Salesperson Commission %</label><input type="number" step="0.01" name="salesperson_commission" class="form-control" value="<?= $rule['salesperson_commission'] ?? 5 ?>"></div>
        </div>
    </div>

    <div class="card shadow card-custom mb-4">
        <div class="card-header bg-dark text-white">Part-Time Settings</div>
        <div class="card-body row g-3">
            <div class="col-md-3"><label>Hourly Rate</label><input type="number" step="0.01" name="parttime_hourly_rate" class="form-control" value="<?= $rule['parttime_hourly_rate'] ?? 15 ?>"></div>
            <div class="col-md-3"><label>Work Days (CSV)</label><input type="text" name="parttime_work_days" class="form-control" value="<?= $rule['parttime_work_days'] ?? '1,2,3,4,5,6' ?>"></div>
            <div class="col-md-3"><label>Start Time</label><input type="time" name="parttime_start_time" class="form-control" value="<?= $rule['parttime_start_time'] ?? '10:00' ?>"></div>
            <div class="col-md-3"><label>End Time</label><input type="time" name="parttime_end_time" class="form-control" value="<?= $rule['parttime_end_time'] ?? '18:00' ?>"></div>
        </div>
    </div>

    <div class="card shadow card-custom mb-4">
        <div class="card-header bg-dark text-white">Late & Penalties</div>
        <div class="card-body row g-3">
            <div class="col-md-3"><label>Late Fine (per 5min)</label><input type="number" step="0.01" name="late_fine_per_5min" class="form-control" value="<?= $rule['late_fine_per_5min'] ?? 5 ?>"></div>
            
            <div class="col-md-3"><label>Absent Penalty (No Notice)</label><input type="number" step="0.01" name="double_absence_penalty" class="form-control" value="<?= $rule['double_absence_penalty'] ?? 200 ?>"></div>

            <div class="col-md-3">
                <label class="text-danger fw-bold">Fine: Leave w/o Notice</label>
                <input type="number" step="0.01" name="leave_without_notice_fine" class="form-control border-danger" value="<?= $rule['leave_without_notice_fine'] ?? 0 ?>">
            </div>

            <div class="col-md-3"><label>Advance Salary Limit</label><input type="number" step="0.01" name="advance_salary_limit" class="form-control" value="<?= $rule['advance_salary_limit'] ?? 0 ?>"></div>
            <div class="col-md-12"><label>Remarks</label><textarea name="remarks" class="form-control"><?= $rule['remarks'] ?? '' ?></textarea></div>
        </div>
    </div>

    <button class="btn btn-primary w-100">Save Rules</button>
</form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>