<?php
// admin/view_employee.php
session_start();
require_once '../config/db.php';

// 1. Security Check
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

$id = $_GET['id'] ?? 0;
$filterMonth = $_GET['month'] ?? date('m');
$filterYear = $_GET['year'] ?? date('Y');

// 2. Fetch Employee Profile
$stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
$stmt->execute([$id]);
$emp = $stmt->fetch();

if (!$emp) die("Employee not found.");

// 3. CALCULATE STATISTICS FOR SELECTED MONTH
$start_date = "$filterYear-$filterMonth-01";
$end_date = date("Y-m-t", strtotime($start_date));

// Fetch logs for the specific month
$stmtStats = $conn->prepare("SELECT * FROM attendance WHERE employee_id = ? AND DATE(scanned_at) BETWEEN ? AND ? ORDER BY scanned_at ASC");
$stmtStats->execute([$id, $start_date, $end_date]);
$month_logs = $stmtStats->fetchAll(PDO::FETCH_GROUP | PDO::FETCH_ASSOC); // Group by Date

// Initialize Counters
$stats = [
    'present' => 0,
    'late' => 0,
    'leave' => 0,
    'absent' => 0,
    'working_days' => 0
];

// Calculate Working Days & Attendance
$current = strtotime($start_date);
$end = strtotime($end_date);
$now = time();

while ($current <= $end) {
    // Stop counting future dates for absent/present
    if ($current > $now) break;

    $dateStr = date('Y-m-d', $current);
    $dayOfWeek = date('N', $current); // 1 (Mon) - 7 (Sun)
    
    // Check if it's a working day (Basic check, can be enhanced with Roster logic)
    $active_days = explode(',', $emp['work_days'] ?? '1,2,3,4,5'); // Default Mon-Fri if empty
    $isWorkingDay = in_array($dayOfWeek, $active_days);

    if ($isWorkingDay) {
        $stats['working_days']++;
        
        // Check Attendance
        // Note: $month_logs keys might be datetime strings or dates depending on fetch mode. 
        // Let's refine fetch or filter manually.
        // Simplified approach: Iterate logs to find match.
        $hasLog = false;
        $isLate = false;
        $isOnLeave = false;

        // Check DB for Leave on this day
        // (Optimization: Fetch all leaves for month once, but query inside loop is okay for single emp view)
        $leaveChk = $conn->prepare("SELECT id FROM leaves WHERE employee_id = ? AND ? BETWEEN from_date AND to_date AND status='approved'");
        $leaveChk->execute([$id, $dateStr]);
        if ($leaveChk->fetch()) {
            $isOnLeave = true;
        }

        // Check Attendance Logs
        // We re-query locally or filter the big array. Let's query specifically for cleaner logic here.
        // (Note: For high traffic, fetching all once is better, but this is admin view for 1 person)
        $logChk = $conn->prepare("SELECT * FROM attendance WHERE employee_id = ? AND DATE(scanned_at) = ?");
        $logChk->execute([$id, $dateStr]);
        $dayLogs = $logChk->fetchAll();

        if (count($dayLogs) > 0) {
            $hasLog = true;
            foreach ($dayLogs as $l) {
                if ($l['type'] == 'morning' && $l['status'] == 'late') $isLate = true;
            }
        }

        // Tally
        if ($isOnLeave) {
            $stats['leave']++;
        } elseif ($hasLog) {
            $stats['present']++;
            if ($isLate) $stats['late']++;
        } else {
            $stats['absent']++;
        }
    }
    
    $current = strtotime('+1 day', $current);
}


// 4. Fetch Raw Attendance Logs (All Time for list below)
$stmtLogs = $conn->prepare("SELECT * FROM attendance WHERE employee_id = ? ORDER BY scanned_at DESC LIMIT 60");
$stmtLogs->execute([$id]);
$raw_logs = $stmtLogs->fetchAll(PDO::FETCH_ASSOC);

// Group Logs by Date (Visual List)
$daily_attendance = [];
foreach ($raw_logs as $log) {
    $date = date('Y-m-d', strtotime($log['scanned_at']));
    if (!isset($daily_attendance[$date])) {
        $daily_attendance[$date] = [
            'morning' => '-', 'lunch_start' => '-', 'lunch_end' => '-', 'leave' => '-', 'status' => 'Absent', 'late' => false
        ];
    }
    $time = date('h:i A', strtotime($log['scanned_at']));
    if ($log['type'] === 'morning') {
        $daily_attendance[$date]['morning'] = $time;
        if ($log['status'] === 'late') $daily_attendance[$date]['late'] = true;
        $daily_attendance[$date]['status'] = 'Present';
    } elseif ($log['type'] === 'lunch_start') $daily_attendance[$date]['lunch_start'] = $time;
    elseif ($log['type'] === 'lunch_end') $daily_attendance[$date]['lunch_end'] = $time;
    elseif ($log['type'] === 'leave') $daily_attendance[$date]['leave'] = $time;
}

// 5. Fetch Salary History
$stmtPayslips = $conn->prepare("SELECT * FROM payslips WHERE employee_id = ? ORDER BY generated_at DESC");
$stmtPayslips->execute([$id]);
$payslips = $stmtPayslips->fetchAll();

// Helper for Employment Type Color
$type_colors = ['full_time' => 'bg-blue-100 text-blue-800', 'part_time' => 'bg-purple-100 text-purple-800', 'contract' => 'bg-orange-100 text-orange-800'];
$emp_type_color = $type_colors[$emp['employment_type']] ?? 'bg-gray-100 text-gray-800';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Details</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex font-sans">
    
    <?php include 'includes/sidebar.php'; ?>

    <main class="flex-1 p-8 h-screen overflow-y-auto">
        
        <div class="mb-6 flex justify-between items-center">
            <a href="employees.php" class="text-blue-600 hover:underline flex items-center">
                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
                Back to Employee List
            </a>
            <a href="edit_employee.php?id=<?= $emp['id'] ?>" class="bg-blue-600 text-white px-4 py-2 rounded text-sm font-bold hover:bg-blue-700">
                Edit Profile
            </a>
        </div>

        <div class="bg-white rounded-lg shadow mb-8 p-6 relative overflow-hidden">
            <div class="flex justify-between items-start border-b border-gray-100 pb-6">
                <div>
                    <h1 class="text-3xl font-bold text-gray-800 mb-2">
                        <?php echo htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']); ?>
                    </h1>
                    <div class="flex flex-wrap items-center gap-2">
                        <span class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide">
                            <?php echo $emp['status']; ?>
                        </span>
                        <span class="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide">
                            <?php echo $emp['department']; ?>
                        </span>
                        <span class="<?= $emp_type_color ?> px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide">
                            <?php echo str_replace('_', ' ', $emp['employment_type']); ?>
                        </span>
                        <?php if($emp['nationality'] === 'Foreigner'): ?>
                            <span class="bg-red-100 text-red-800 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide">Foreigner</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="text-right text-gray-500 text-sm">
                    <p class="mb-1">Joined: <span class="font-semibold text-gray-700"><?php echo date('d M Y', strtotime($emp['join_date'])); ?></span></p>
                    <div class="mt-2 bg-gray-50 p-2 rounded text-right">
                        <p>Base Salary: <span class="font-bold text-gray-800">RM <?php echo number_format($emp['salary_amount'], 2); ?></span> <span class="text-xs">(<?php echo ucfirst($emp['salary_type']); ?>)</span></p>
                    </div>
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-6 text-sm">
                <div>
                    <span class="text-gray-400 block text-xs uppercase font-bold mb-1">Contact Info</span>
                    <a href="mailto:<?php echo $emp['email']; ?>" class="text-blue-600 hover:underline block mb-1"><?php echo $emp['email']; ?></a>
                    <span class="text-gray-700"><?php echo $emp['phone']; ?></span>
                </div>
                <div>
                    <span class="text-gray-400 block text-xs uppercase font-bold mb-1">Identity</span>
                    <p class="text-gray-700 mb-1"><span class="font-semibold">IC/Passport:</span> <?php echo $emp['nic']; ?></p>
                    <p class="text-gray-700"><span class="font-semibold">Race/Nat:</span> <?php echo $emp['race'] . ' (' . $emp['nationality'] . ')'; ?></p>
                </div>
                <div>
                    <span class="text-gray-400 block text-xs uppercase font-bold mb-1">Work Details</span>
                    <?php if($emp['employment_type'] === 'part_time' && $emp['shift_start']): ?>
                        <p class="text-purple-700 font-semibold mb-2">Shift: <?php echo date('h:i A', strtotime($emp['shift_start'])) . ' - ' . date('h:i A', strtotime($emp['shift_end'])); ?></p>
                    <?php else: ?>
                        <p class="text-gray-500 mb-2">Standard Shift</p>
                    <?php endif; ?>
                    <div class="mb-2">
                        <span class="text-[10px] text-gray-400 uppercase font-bold">Working Days</span>
                        <div class="flex gap-1 mt-1">
                            <?php 
                            $active_days = explode(',', $emp['work_days'] ?? '');
                            $days_short = [1=>'M', 2=>'T', 3=>'W', 4=>'T', 5=>'F', 6=>'S', 7=>'S'];
                            foreach($days_short as $num => $label): 
                                $isActive = in_array($num, $active_days);
                                $class = $isActive ? 'bg-blue-600 text-white font-bold shadow-sm' : 'bg-gray-100 text-gray-300';
                            ?>
                            <div class="w-6 h-6 flex items-center justify-center rounded text-xs <?php echo $class; ?>" title="<?php echo $isActive ? 'Working' : 'Off'; ?>">
                                <?php echo $label; ?>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow mb-8 p-6">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-lg font-bold text-gray-800">Monthly Performance</h3>
                <form method="GET" class="flex gap-2">
                    <input type="hidden" name="id" value="<?= $id ?>">
                    <select name="month" class="border rounded px-2 py-1 text-sm bg-gray-50">
                        <?php for($m=1; $m<=12; $m++): ?>
                            <option value="<?= str_pad($m, 2, '0', STR_PAD_LEFT) ?>" <?= $filterMonth == $m ? 'selected' : '' ?>>
                                <?= date('F', mktime(0, 0, 0, $m, 1)) ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                    <select name="year" class="border rounded px-2 py-1 text-sm bg-gray-50">
                        <?php for($y=date('Y'); $y>=2023; $y--): ?>
                            <option value="<?= $y ?>" <?= $filterYear == $y ? 'selected' : '' ?>><?= $y ?></option>
                        <?php endfor; ?>
                    </select>
                    <button type="submit" class="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700">View</button>
                </form>
            </div>

            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div class="bg-green-50 p-4 rounded-lg border border-green-100 text-center">
                    <span class="block text-2xl font-bold text-green-700"><?= $stats['present'] ?></span>
                    <span class="text-xs font-semibold text-green-600 uppercase tracking-wide">Days Present</span>
                </div>
                <div class="bg-yellow-50 p-4 rounded-lg border border-yellow-100 text-center">
                    <span class="block text-2xl font-bold text-yellow-700"><?= $stats['late'] ?></span>
                    <span class="text-xs font-semibold text-yellow-600 uppercase tracking-wide">Late Arrivals</span>
                </div>
                <div class="bg-blue-50 p-4 rounded-lg border border-blue-100 text-center">
                    <span class="block text-2xl font-bold text-blue-700"><?= $stats['leave'] ?></span>
                    <span class="text-xs font-semibold text-blue-600 uppercase tracking-wide">Approved Leave</span>
                </div>
                <div class="bg-red-50 p-4 rounded-lg border border-red-100 text-center">
                    <span class="block text-2xl font-bold text-red-700"><?= $stats['absent'] ?></span>
                    <span class="text-xs font-semibold text-red-600 uppercase tracking-wide">Days Absent</span>
                </div>
            </div>
            <div class="mt-4 text-center text-xs text-gray-400">
                Calculated based on <?= $stats['working_days'] ?> scheduled working days elapsed this month.
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div class="lg:col-span-2">
                <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                    <svg class="w-5 h-5 mr-2 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    Recent Activity Logs
                </h2>
                <div class="bg-white rounded-lg shadow overflow-hidden">
                    <table class="min-w-full text-left">
                        <thead class="bg-gray-50 border-b">
                            <tr>
                                <th class="px-4 py-3 text-gray-500 font-semibold text-xs uppercase">Date</th>
                                <th class="px-4 py-3 text-gray-500 font-semibold text-xs uppercase text-green-700 bg-green-50">Clock In</th>
                                <th class="px-4 py-3 text-gray-500 font-semibold text-xs uppercase text-yellow-700 bg-yellow-50 text-center">Lunch</th>
                                <th class="px-4 py-3 text-gray-500 font-semibold text-xs uppercase text-red-700 bg-red-50">Clock Out</th>
                                <th class="px-4 py-3 text-gray-500 font-semibold text-xs uppercase text-right">Status</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100 text-sm">
                            <?php foreach ($daily_attendance as $date => $day): ?>
                            <tr class="hover:bg-gray-50 transition">
                                <td class="px-4 py-4 font-bold text-gray-700 whitespace-nowrap">
                                    <?php echo date('d M, D', strtotime($date)); ?>
                                </td>
                                
                                <td class="px-4 py-4">
                                    <span class="font-mono font-semibold text-green-700 bg-green-50 px-2 py-1 rounded">
                                        <?php echo $day['morning']; ?>
                                    </span>
                                </td>

                                <td class="px-4 py-4 text-center">
                                    <div class="inline-flex items-center text-xs font-mono bg-yellow-50 text-yellow-800 px-2 py-1 rounded border border-yellow-100">
                                        <span><?php echo $day['lunch_start']; ?></span>
                                        <span class="mx-1 text-gray-400">&rarr;</span>
                                        <span><?php echo $day['lunch_end']; ?></span>
                                    </div>
                                </td>

                                <td class="px-4 py-4">
                                    <span class="font-mono font-semibold text-red-700 bg-red-50 px-2 py-1 rounded">
                                        <?php echo $day['leave']; ?>
                                    </span>
                                </td>

                                <td class="px-4 py-4 text-right">
                                    <?php if ($day['late']): ?>
                                        <span class="bg-red-100 text-red-700 px-2 py-1 rounded text-xs font-bold uppercase">LATE</span>
                                    <?php else: ?>
                                        <span class="bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-bold uppercase">PRESENT</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            
                            <?php if(empty($daily_attendance)): ?>
                                <tr><td colspan="5" class="px-6 py-8 text-center text-gray-400">No recent attendance history found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="lg:col-span-1">
                <h2 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                    <svg class="w-5 h-5 mr-2 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                    Salary & Payslips
                </h2>
                <div class="bg-white rounded-lg shadow overflow-hidden">
                    <table class="min-w-full text-left">
                        <thead class="bg-gray-50 border-b">
                            <tr>
                                <th class="px-4 py-3 text-gray-500 font-semibold text-xs uppercase">Month</th>
                                <th class="px-4 py-3 text-gray-500 font-semibold text-xs uppercase text-right">Net Salary</th>
                                <th class="px-4 py-3 text-gray-500 font-semibold text-xs uppercase text-right">PDF</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100 text-sm">
                            <?php foreach ($payslips as $slip): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-3">
                                    <div class="font-bold text-gray-700"><?php echo date('M Y', strtotime($slip['month_year'] . '-01')); ?></div>
                                    <div class="text-[10px] text-gray-400"><?php echo date('d/m/y', strtotime($slip['generated_at'])); ?></div>
                                </td>
                                <td class="px-4 py-3 text-right font-bold text-gray-800">
                                    RM <?php echo number_format($slip['net_salary'], 2); ?>
                                </td>
                                <td class="px-4 py-3 text-right">
                                    <a href="generate_payslip_pdf.php?id=<?php echo $slip['id']; ?>" target="_blank" 
                                       class="text-blue-600 hover:text-blue-800 font-bold text-xs underline">
                                        Download
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if(empty($payslips)): ?>
                                <tr><td colspan="3" class="px-4 py-6 text-center text-gray-400 text-xs">No payslips yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

    </main>
</body>
</html>