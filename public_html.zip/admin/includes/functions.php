<?php
// includes/functions.php

function get_schedule_status($conn, $employee_id, $date) {
    // 1. Check for Specific Date Adjustment (The Override)
    $stmt = $conn->prepare("SELECT * FROM schedule_adjustments 
                           WHERE employee_id = ? AND adjustment_date = ? AND status = 'approved'");
    $stmt->execute([$employee_id, $date]);
    $adjustment = $stmt->fetch(PDO::FETCH_ASSOC);

    // If there is an override, return that
    if ($adjustment) {
        return [
            'is_working' => ($adjustment['type'] === 'work'),
            'start_time' => $adjustment['shift_start'], // Can be null
            'end_time'   => $adjustment['shift_end'],   // Can be null
            'source'     => 'adjustment'
        ];
    }

    // 2. If no override, check Default Employee Settings
    $stmtEmp = $conn->prepare("SELECT work_days, shift_start, shift_end, employment_type FROM employees WHERE id = ?");
    $stmtEmp->execute([$employee_id]);
    $emp = $stmtEmp->fetch(PDO::FETCH_ASSOC);

    if (!$emp) return null;

    // Convert "1,2,3" to array
    $active_days = explode(',', $emp['work_days']);
    $day_of_week = date('N', strtotime($date)); // 1 (Mon) to 7 (Sun)

    $is_working = in_array($day_of_week, $active_days);

    return [
        'is_working' => $is_working,
        'start_time' => $emp['shift_start'], // Default times
        'end_time'   => $emp['shift_end'],
        'source'     => 'default'
    ];
}
?>