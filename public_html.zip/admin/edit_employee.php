<?php
// admin/edit_employee.php
session_start();
require_once '../config/db.php';

// 1. Security Check
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) {
    header("Location: employees.php");
    exit;
}

$message = "";
$error = "";

// 2. Fetch Existing Data
// We fetch role from 'employees_users' by joining tables
$sqlFetch = "SELECT e.*, u.role, u.username as user_login 
             FROM employees e 
             LEFT JOIN employees_users u ON e.username = u.username 
             WHERE e.id = ?";
$stmt = $conn->prepare($sqlFetch);
$stmt->execute([$id]);
$emp = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$emp) {
    die("Employee not found.");
}

// 3. Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Personal Info
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $nic = trim($_POST['nic']);
    $nationality = $_POST['nationality'];
    $race = trim($_POST['race']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    
    // Job & Salary Info
    $department = trim($_POST['department']);
    $employment_type = $_POST['employment_type'];
    $join_date = $_POST['join_date'];
    $resign_date = !empty($_POST['resign_date']) ? $_POST['resign_date'] : null;
    $salary_type = $_POST['salary_type'];
    $salary_amount = $_POST['salary_amount'];
    $transport_allowance = !empty($_POST['transport_allowance']) ? $_POST['transport_allowance'] : 0.00;
    $custom_sick_leave = !empty($_POST['custom_sick_leave_days']) ? $_POST['custom_sick_leave_days'] : null;
    $status = $_POST['status'];

    // Shift Info
    $shift_start = !empty($_POST['shift_start']) ? $_POST['shift_start'] : null;
    $shift_end = !empty($_POST['shift_end']) ? $_POST['shift_end'] : null;
    
    // Bank Info
    $bank_name = trim($_POST['bank_name']);
    $bank_account = trim($_POST['bank_account']);
    $account_holder_name = trim($_POST['account_holder_name']);
    
    // Login Details
    $new_username = trim($_POST['username']);
    $old_username = $emp['username']; 
    $new_password = $_POST['password'];
    $new_role = $_POST['role'];

    // Work Days
    $work_days = isset($_POST['work_days']) ? implode(',', $_POST['work_days']) : '';

    try {
        $conn->beginTransaction();

        // A. Update EMPLOYEES Table
        $sqlEmp = "UPDATE employees SET 
            first_name=?, last_name=?, nic=?, nationality=?, race=?, email=?, phone=?, 
            department=?, employment_type=?, join_date=?, resign_date=?,
            salary_type=?, salary_amount=?, transport_allowance=?, custom_sick_leave_days=?,
            shift_start=?, shift_end=?,
            status=?, username=?, bank_name=?, bank_account=?, account_holder_name=?, work_days=?";
        
        $paramsEmp = [
            $first_name, $last_name, $nic, $nationality, $race, $email, $phone,
            $department, $employment_type, $join_date, $resign_date,
            $salary_type, $salary_amount, $transport_allowance, $custom_sick_leave,
            $shift_start, $shift_end,
            $status, $new_username, $bank_name, $bank_account, $account_holder_name, $work_days
        ];

        if (!empty($new_password)) {
            $sqlEmp .= ", password=?";
            $paramsEmp[] = password_hash($new_password, PASSWORD_DEFAULT);
        }

        $sqlEmp .= " WHERE id=?";
        $paramsEmp[] = $id;

        $stmtUpdate = $conn->prepare($sqlEmp);
        $stmtUpdate->execute($paramsEmp);

        // B. Update EMPLOYEES_USERS Table (Syncing shared fields)
        $sqlUser = "UPDATE employees_users SET 
            first_name=?, last_name=?, nic=?, email=?, phone=?, 
            department=?, salary_type=?, salary_amount=?, join_date=?,
            status=?, username=?, role=?";
        
        $paramsUser = [
            $first_name, $last_name, $nic, $email, $phone, 
            $department, $salary_type, $salary_amount, $join_date,
            $status, $new_username, $new_role
        ];

        if (!empty($new_password)) {
            $sqlUser .= ", password_hash=?";
            $paramsUser[] = password_hash($new_password, PASSWORD_DEFAULT);
        }

        $sqlUser .= " WHERE username=?"; // Match by OLD username
        $paramsUser[] = $old_username;

        $stmtUserUpdate = $conn->prepare($sqlUser);
        $stmtUserUpdate->execute($paramsUser);

        $conn->commit();
        
        // Refresh page to show new data
        header("Location: edit_employee.php?id=$id&msg=updated");
        exit;

    } catch (PDOException $e) {
        $conn->rollBack();
        $error = "Error updating record: " . $e->getMessage();
    }
}

// Check for success msg in URL
if (isset($_GET['msg']) && $_GET['msg'] == 'updated') {
    $message = "Employee updated successfully!";
}

// Helpers
$active_days = explode(',', $emp['work_days'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Employee</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex font-sans">
    
    <?php include 'includes/sidebar.php'; ?>

    <main class="flex-1 p-8 h-screen overflow-y-auto">
        <div class="flex items-center justify-between mb-6">
            <h1 class="text-2xl font-bold text-gray-800">Edit Employee</h1>
            <a href="employees.php" class="text-blue-600 hover:underline">&larr; Back to List</a>
        </div>

        <?php if($message): ?>
            <div class="bg-green-100 text-green-700 p-4 rounded mb-4 border border-green-200"><?= $message ?></div>
        <?php endif; ?>
        <?php if($error): ?>
            <div class="bg-red-100 text-red-700 p-4 rounded mb-4 border border-red-200"><?= $error ?></div>
        <?php endif; ?>

        <form method="POST" class="space-y-6">
            
            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-lg font-bold text-gray-700 mb-4 border-b pb-2">Personal Information</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                        <label class="block text-sm font-semibold text-gray-600 mb-1">First Name</label>
                        <input type="text" name="first_name" value="<?= htmlspecialchars($emp['first_name']) ?>" required class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-600 mb-1">Last Name</label>
                        <input type="text" name="last_name" value="<?= htmlspecialchars($emp['last_name']) ?>" required class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-600 mb-1">IC / Passport</label>
                        <input type="text" name="nic" value="<?= htmlspecialchars($emp['nic']) ?>" required class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-600 mb-1">Nationality</label>
                        <select name="nationality" class="w-full border rounded px-3 py-2 bg-white">
                            <option value="Malaysian" <?= ($emp['nationality'] == 'Malaysian') ? 'selected' : '' ?>>Malaysian</option>
                            <option value="Foreigner" <?= ($emp['nationality'] == 'Foreigner') ? 'selected' : '' ?>>Foreigner</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-600 mb-1">Race</label>
                        <input type="text" name="race" value="<?= htmlspecialchars($emp['race']) ?>" class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-600 mb-1">Phone</label>
                        <input type="text" name="phone" value="<?= htmlspecialchars($emp['phone']) ?>" required class="w-full border rounded px-3 py-2">
                    </div>
                    <div class="md:col-span-3">
                        <label class="block text-sm font-semibold text-gray-600 mb-1">Email</label>
                        <input type="email" name="email" value="<?= htmlspecialchars($emp['email']) ?>" required class="w-full border rounded px-3 py-2">
                    </div>
                </div>
            </div>

            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-lg font-bold text-gray-700 mb-4 border-b pb-2">Job & Employment Details</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                        <label class="block text-sm font-semibold text-gray-600 mb-1">Department</label>
                        <select name="department" class="w-full border rounded px-3 py-2 bg-white">
                            <?php 
                            $depts = ['IT', 'HR', 'Sales', 'Stock Keeping', 'HQ'];
                            foreach($depts as $d) {
                                $sel = ($emp['department'] == $d) ? 'selected' : '';
                                echo "<option value='$d' $sel>$d</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-600 mb-1">Employment Type</label>
                        <select name="employment_type" id="empType" onchange="togglePartTime()" class="w-full border rounded px-3 py-2 bg-white">
                            <option value="full_time" <?= ($emp['employment_type'] == 'full_time') ? 'selected' : '' ?>>Full Time</option>
                            <option value="part_time" <?= ($emp['employment_type'] == 'part_time') ? 'selected' : '' ?>>Part Time</option>
                            <option value="contract" <?= ($emp['employment_type'] == 'contract') ? 'selected' : '' ?>>Contract</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-600 mb-1">Status</label>
                        <select name="status" class="w-full border rounded px-3 py-2 bg-white">
                            <option value="active" <?= $emp['status'] == 'active' ? 'selected' : '' ?>>Active</option>
                            <option value="inactive" <?= $emp['status'] == 'inactive' ? 'selected' : '' ?>>Inactive</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-600 mb-1">Start Date (Join)</label>
                        <input type="date" name="join_date" value="<?= $emp['join_date'] ?>" class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-600 mb-1">End Date (Resign)</label>
                        <input type="date" name="resign_date" value="<?= $emp['resign_date'] ?>" class="w-full border rounded px-3 py-2 text-gray-500">
                    </div>

                    <div class="part-time-field hidden">
                        <label class="block text-sm font-bold text-purple-600 mb-1">Shift Start</label>
                        <input type="time" name="shift_start" value="<?= $emp['shift_start'] ?>" class="w-full border border-purple-200 rounded px-3 py-2 bg-purple-50">
                    </div>
                    <div class="part-time-field hidden">
                        <label class="block text-sm font-bold text-purple-600 mb-1">Shift End</label>
                        <input type="time" name="shift_end" value="<?= $emp['shift_end'] ?>" class="w-full border border-purple-200 rounded px-3 py-2 bg-purple-50">
                    </div>
                </div>

                <div class="mt-4 pt-4 border-t">
                    <label class="block text-xs font-bold text-gray-500 uppercase mb-2">Work Days</label>
                    <div class="flex flex-wrap gap-4">
                        <?php 
                        $days = [1=>'Mon', 2=>'Tue', 3=>'Wed', 4=>'Thu', 5=>'Fri', 6=>'Sat', 7=>'Sun'];
                        foreach($days as $num => $name): ?>
                            <label class="inline-flex items-center text-sm">
                                <input type="checkbox" name="work_days[]" value="<?= $num ?>" 
                                <?= in_array($num, $active_days) ? 'checked' : '' ?> class="mr-1">
                                <?= $name ?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-lg font-bold text-gray-700 mb-4 border-b pb-2">Salary & Benefits</h3>
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div>
                        <label class="block text-sm font-semibold text-gray-600 mb-1">Salary Type</label>
                        <select name="salary_type" class="w-full border rounded px-3 py-2 bg-white">
                            <option value="fixed" <?= $emp['salary_type'] == 'fixed' ? 'selected' : '' ?>>Fixed Monthly</option>
                            <option value="hourly" <?= $emp['salary_type'] == 'hourly' ? 'selected' : '' ?>>Hourly</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-600 mb-1">Basic Amount (RM)</label>
                        <input type="number" step="0.01" name="salary_amount" value="<?= $emp['salary_amount'] ?>" class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-600 mb-1">Transport Allow. (RM)</label>
                        <input type="number" step="0.01" name="transport_allowance" value="<?= $emp['transport_allowance'] ?>" class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-600 mb-1">Sick Leave Limit (Days)</label>
                        <input type="number" name="custom_sick_leave_days" value="<?= $emp['custom_sick_leave_days'] ?>" placeholder="Default" class="w-full border rounded px-3 py-2">
                    </div>
                </div>
            </div>

            <div class="bg-white p-6 rounded-lg shadow">
                <h3 class="text-lg font-bold text-gray-700 mb-4 border-b pb-2">Bank & System Access</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                        <label class="block text-sm font-semibold text-gray-600 mb-1">Bank Name</label>
                        <input type="text" name="bank_name" value="<?= htmlspecialchars($emp['bank_name']) ?>" class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-600 mb-1">Account No</label>
                        <input type="text" name="bank_account" value="<?= htmlspecialchars($emp['bank_account'] ?? '') ?>" class="w-full border rounded px-3 py-2">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-600 mb-1">Account Holder</label>
                        <input type="text" name="account_holder_name" value="<?= htmlspecialchars($emp['account_holder_name'] ?? '') ?>" class="w-full border rounded px-3 py-2">
                    </div>

                    <div class="md:col-span-3 border-t pt-4 grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div>
                            <label class="block text-sm font-semibold text-gray-600 mb-1">System Role</label>
                            <select name="role" class="w-full border rounded px-3 py-2 bg-white border-blue-300">
                                <?php 
                                $roles = ['staff'=>'Staff', 'admin'=>'Admin', 'attender'=>'Kiosk', 'breaker'=>'Lunch Station'];
                                foreach($roles as $val => $label) {
                                    $sel = ($emp['role'] == $val) ? 'selected' : '';
                                    echo "<option value='$val' $sel>$label</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-semibold text-gray-600 mb-1">Username</label>
                            <input type="text" name="username" value="<?= htmlspecialchars($emp['username']) ?>" required class="w-full border rounded px-3 py-2">
                        </div>
                        <div>
                            <label class="block text-sm font-semibold text-gray-600 mb-1">New Password</label>
                            <input type="text" name="password" placeholder="Leave blank to keep current" class="w-full border rounded px-3 py-2">
                        </div>
                    </div>
                </div>
            </div>

            <div class="flex justify-end pb-8">
                <button type="submit" class="bg-blue-600 text-white font-bold py-3 px-8 rounded hover:bg-blue-700 shadow-lg transform transition hover:scale-105">
                    Save Changes
                </button>
            </div>

        </form>
    </main>

    <script>
        function togglePartTime() {
            const type = document.getElementById('empType').value;
            const fields = document.querySelectorAll('.part-time-field');
            fields.forEach(f => {
                if(type === 'part_time'){
                    f.classList.remove('hidden');
                } else {
                    f.classList.add('hidden');
                }
            });
        }
        // Run on load
        togglePartTime();
    </script>
</body>
</html>