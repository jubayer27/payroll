<?php
// admin/api_roster_actions.php

// 1. Enable Error Logging for debugging
ini_set('display_errors', 0);
error_reporting(E_ALL);

session_start();
require_once '../config/db.php';
header('Content-Type: application/json');

function sendJson($status, $message, $data = []) {
    echo json_encode(['status' => $status, 'message' => $message, 'data' => $data]);
    exit;
}

// Security Check
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    sendJson('error', 'Unauthorized access');
}

$action = $_POST['action'] ?? '';

// =========================================================
// ACTION: FETCH ROSTER (Load the Calendar)
// =========================================================
if ($action === 'fetch') {
    $empId = $_POST['employee_id'] ?? 0;
    $month = $_POST['month'] ?? date('Y-m');

    if (!$empId || !$month) sendJson('error', 'Missing inputs');

    // 1. Get Employee Defaults (Profile)
    $stmt = $conn->prepare("SELECT work_days, shift_start, shift_end FROM employees WHERE id = ?");
    $stmt->execute([$empId]);
    $emp = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$emp) sendJson('error', 'Employee not found');

    $default_days = explode(',', $emp['work_days'] ?? ''); 
    
    // 2. Fetch Overrides (Schedule Adjustments)
    $start_date = "$month-01";
    $end_date = date("Y-m-t", strtotime($start_date));

    $stmtAdj = $conn->prepare("SELECT * FROM schedule_adjustments WHERE employee_id = ? AND adjustment_date BETWEEN ? AND ? AND status='approved'");
    $stmtAdj->execute([$empId, $start_date, $end_date]);
    $adjustments = [];
    while ($row = $stmtAdj->fetch(PDO::FETCH_ASSOC)) {
        $adjustments[$row['adjustment_date']] = $row;
    }

    // 3. Build Calendar Data
    $result_days = [];
    $current = strtotime($start_date);
    $end = strtotime($end_date);

    while ($current <= $end) {
        $dateStr = date('Y-m-d', $current);
        $dayOfWeek = date('N', $current); // 1 (Mon) - 7 (Sun)

        // Default Logic (From Profile)
        $isWorking = in_array($dayOfWeek, $default_days);
        $startTime = $emp['shift_start'];
        $endTime = $emp['shift_end'];
        $source = 'default';

        // Override Logic (From Adjustments)
        if (isset($adjustments[$dateStr])) {
            $adj = $adjustments[$dateStr];
            $isWorking = ($adj['type'] === 'work');
            $source = 'adjustment';
            // Use specific time if set
            if (!empty($adj['shift_start'])) $startTime = $adj['shift_start'];
            if (!empty($adj['shift_end'])) $endTime = $adj['shift_end'];
        }

        $result_days[] = [
            'date' => $dateStr,
            'is_working' => (bool)$isWorking,
            'start_time' => $startTime ? date('H:i', strtotime($startTime)) : '',
            'end_time' => $endTime ? date('H:i', strtotime($endTime)) : '',
            'source' => $source
        ];

        $current = strtotime('+1 day', $current);
    }

    sendJson('success', 'Loaded', $result_days);
}

// =========================================================
// ACTION: SAVE CHANGES
// =========================================================
elseif ($action === 'save') {
    $empId = $_POST['employee_id'] ?? 0;
    $changeType = $_POST['change_type'] ?? 'temporary';
    $json = $_POST['roster_data'] ?? '[]';
    $rosterData = json_decode($json, true);

    if (!$empId || empty($rosterData)) sendJson('error', 'No data to save');

    // Get the start date of the month being edited
    $firstDate = $rosterData[0]['date'];
    $monthStart = date('Y-m-01', strtotime($firstDate));

    try {
        $conn->beginTransaction();

        // --- OPTION 1: TEMPORARY CHANGE ---
        if ($changeType === 'temporary') {
            $sql = "INSERT INTO schedule_adjustments (employee_id, adjustment_date, type, shift_start, shift_end, status, reason)
                    VALUES (:eid, :date, :type, :start, :end, 'approved', 'Admin Roster Update')
                    ON DUPLICATE KEY UPDATE type=:type, shift_start=:start, shift_end=:end, status='approved'";
            
            $stmt = $conn->prepare($sql);

            foreach ($rosterData as $day) {
                $type = $day['is_working'] ? 'work' : 'off';
                $start = !empty($day['start_time']) ? $day['start_time'] : null;
                $end = !empty($day['end_time']) ? $day['end_time'] : null;

                $stmt->execute([
                    ':eid' => $empId,
                    ':date' => $day['date'],
                    ':type' => $type,
                    ':start' => $start,
                    ':end' => $end
                ]);
            }
            $msg = "Temporary schedule updated successfully.";
        }

        // --- OPTION 2: PERMANENT CHANGE ---
        elseif ($changeType === 'permanent') {
            
            // 1. Analyze the Grid to find the new "Standard Pattern"
            $newWorkingDays = [];
            $capturedStartTime = null;
            $capturedEndTime = null;

            foreach ($rosterData as $day) {
                if ($day['is_working']) {
                    $dayNum = date('N', strtotime($day['date'])); 
                    
                    if (!in_array($dayNum, $newWorkingDays)) {
                        $newWorkingDays[] = $dayNum;
                    }

                    // Capture time from the first valid working day found
                    if (!$capturedStartTime && !empty($day['start_time'])) $capturedStartTime = $day['start_time'];
                    if (!$capturedEndTime && !empty($day['end_time'])) $capturedEndTime = $day['end_time'];
                }
            }

            // Convert to string (e.g., "1,2,3,4,5")
            sort($newWorkingDays);
            $workDaysStr = implode(',', $newWorkingDays);

            // 2. Fallback: If no time set in grid, keep existing profile time
            $currStmt = $conn->prepare("SELECT shift_start, shift_end FROM employees WHERE id = ?");
            $currStmt->execute([$empId]);
            $curr = $currStmt->fetch(PDO::FETCH_ASSOC);

            $finalStart = $capturedStartTime ?? $curr['shift_start'];
            $finalEnd = $capturedEndTime ?? $curr['shift_end'];

            // 3. Update the Profile
            $upd = $conn->prepare("UPDATE employees SET work_days = ?, shift_start = ?, shift_end = ? WHERE id = ?");
            $upd->execute([$workDaysStr, $finalStart, $finalEnd, $empId]);

            // 4. CRITICAL FIX: Remove ALL adjustments for this month and future
            // This clears the "Override" badges because the profile now matches the schedule
            $cleanup = $conn->prepare("DELETE FROM schedule_adjustments WHERE employee_id = ? AND adjustment_date >= ?");
            $cleanup->execute([$empId, $monthStart]);

            $msg = "Permanent profile updated. New Schedule: " . ($workDaysStr ?: 'None');
        }

        $conn->commit();
        sendJson('success', $msg);

    } catch (Exception $e) {
        $conn->rollBack();
        sendJson('error', 'Database Error: ' . $e->getMessage());
    }
}
?>