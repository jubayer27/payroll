<?php
// admin/salary_calculator.php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

// Fetch active employees
$empStmt = $conn->query("SELECT id, first_name, last_name, department FROM employees WHERE status='active' ORDER BY first_name ASC");
$employees = $empStmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Salary Calculator</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-gray-100 flex font-sans">
    
    <?php include 'includes/sidebar.php'; ?>

    <main class="flex-1 p-8 h-screen overflow-y-auto">
        <h1 class="text-2xl font-bold text-gray-800 mb-6">Generate Salary & Payslip</h1>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            <div class="lg:col-span-1">
                <div class="bg-white p-6 rounded-lg shadow">
                    <h2 class="text-lg font-bold text-gray-700 border-b pb-2 mb-4">1. Select Criteria</h2>
                    
                    <form id="calcForm" class="space-y-4">
                        <div>
                            <label class="block text-sm font-semibold text-gray-600 mb-1">Employee</label>
                            <select name="employee_id" id="employee_id" class="w-full border rounded px-3 py-2 bg-white" required>
                                <option value="">-- Select Employee --</option>
                                <?php foreach ($employees as $emp): ?>
                                    <option value="<?= $emp['id'] ?>">
                                        <?= htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']) ?> (<?= $emp['department'] ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-600 mb-1">Month</label>
                            <input type="month" name="month" id="month" value="<?= date('Y-m') ?>" class="w-full border rounded px-3 py-2" required>
                        </div>

                        <hr class="border-gray-100 my-4">
                        <h3 class="text-sm font-bold text-blue-600 uppercase">Additional Earnings</h3>

                        <div>
                            <label class="block text-sm text-gray-600 mb-1">Total Sales (for Commission)</label>
                            <div class="flex">
                                <span class="bg-gray-100 border border-r-0 rounded-l px-3 py-2 text-gray-500">RM</span>
                                <input type="number" step="0.01" name="sales_amount" value="0" class="w-full border rounded-r px-3 py-2">
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm text-gray-600 mb-1">Claims / Allowances</label>
                            <div class="flex">
                                <span class="bg-gray-100 border border-r-0 rounded-l px-3 py-2 text-gray-500">RM</span>
                                <input type="number" step="0.01" name="claims" value="0" class="w-full border rounded-r px-3 py-2">
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm text-gray-600 mb-1">Manual Bonus</label>
                            <div class="flex">
                                <span class="bg-gray-100 border border-r-0 rounded-l px-3 py-2 text-gray-500">RM</span>
                                <input type="number" step="0.01" name="bonus" value="0" class="w-full border rounded-r px-3 py-2">
                            </div>
                        </div>

                        <button type="submit" class="w-full bg-blue-600 text-white font-bold py-3 rounded hover:bg-blue-700 transition mt-4">
                            Calculate Salary
                        </button>
                    </form>
                </div>
            </div>

            <div class="lg:col-span-2">
                <div id="preview-area" class="hidden bg-white p-8 rounded-lg shadow relative">
                    <h2 class="text-xl font-bold text-gray-800 mb-4 flex justify-between items-center">
                        <span>Payslip Preview</span>
                        <span id="preview-month" class="text-sm bg-blue-100 text-blue-800 px-3 py-1 rounded-full"></span>
                    </h2>

                    <div id="calculation-result" class="space-y-4">
                        </div>
                    
                    <div class="mt-6 flex justify-between items-center border-t pt-4 bg-gray-50 p-4 rounded">
                        <span class="text-lg font-bold text-gray-700">Net Salary:</span>
                        <span id="net-salary-display" class="text-2xl font-extrabold text-green-700">RM 0.00</span>
                    </div>

                    <div class="mt-8 flex justify-end gap-4">
                        <button type="button" onclick="location.reload()" class="text-gray-500 hover:text-gray-800 px-4">Cancel</button>
                        <button type="button" id="btn-save" class="bg-green-600 text-white font-bold py-2 px-6 rounded hover:bg-green-700 shadow-lg">
                            Confirm & Generate Payslip
                        </button>
                    </div>
                </div>

                <div id="empty-state" class="bg-gray-50 border-2 border-dashed border-gray-300 rounded-lg p-12 text-center h-full flex flex-col items-center justify-center text-gray-400">
                    <svg class="w-16 h-16 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path></svg>
                    <p>Select an employee and click Calculate to view the breakdown.</p>
                </div>
            </div>
        </div>
    </main>

    <script>
        let currentCalculationData = null;

        // 1. Handle Form Submit (Calculate)
        $('#calcForm').on('submit', function(e) {
            e.preventDefault();
            Swal.fire({ title: 'Calculating...', didOpen: () => Swal.showLoading() });

            $.post('api_calculate_salary.php', $(this).serialize(), function(response) {
                Swal.close();
                if (response.status === 'success') {
                    $('#empty-state').addClass('hidden');
                    $('#preview-area').removeClass('hidden');
                    $('#preview-month').text(response.data.month_display);
                    $('#calculation-result').html(response.html);
                    
                    // Store the initial data object coming from API
                    currentCalculationData = response.data;
                    
                    // Initialize the net salary display
                    recalculateTotals(); 
                } else {
                    Swal.fire('Error', response.message, 'error');
                }
            }, 'json')
            .fail(function() {
                Swal.fire('Error', 'Server communication error', 'error');
            });
        });

        // 2. Handle Editable Fines (Recalculate on input change)
        // Note: The HTML returned by API must have inputs with class 'calc-input' and data-field attributes
        $(document).on('input', '.calc-input', function() {
            if(!currentCalculationData) return;

            // Get field name and new value from the input user edited
            let field = $(this).data('field');
            let newVal = parseFloat($(this).val());
            if(isNaN(newVal) || newVal < 0) newVal = 0;

            // Update local data object's financial record
            currentCalculationData.financials[field] = newVal;

            // Recalculate Totals immediately
            recalculateTotals();
        });

        function recalculateTotals() {
            if(!currentCalculationData) return;
            
            let f = currentCalculationData.financials;

            // --- A. Earnings ---
            // Ensure we use 0 if undefined
            let basic = parseFloat(f.basic_salary) || 0;
            let comm = parseFloat(f.commission) || 0;
            let claims = parseFloat(f.claims) || 0;
            let bonus = parseFloat(f.manual_bonus) || 0;
            let perf = parseFloat(f.perfect_attendance) || 0;
            let ot = parseFloat(f.ot_pay) || 0;
            let transport = parseFloat(f.transport_allowance) || 0; // Integrated new field

            let totalEarnings = basic + comm + claims + bonus + perf + ot + transport;

            // --- B. Deductions ---
            let late = parseFloat(f.late_deduction) || 0;
            let absent = parseFloat(f.absent_deduction) || 0;
            let fine_no_notice = parseFloat(f.leave_without_notice_fine) || 0;
            let fine_rejected = parseFloat(f.rejected_leave_fine) || 0;
            let advance = parseFloat(f.advance_salary) || 0;

            let totalDeductions = late + absent + fine_no_notice + fine_rejected + advance;

            // --- C. Net ---
            let netSalary = totalEarnings - totalDeductions;

            // Update UI
            $('#net-salary-display').text('RM ' + netSalary.toFixed(2));

            // Update Data Object so we save the CORRECT numbers
            currentCalculationData.financials.gross_salary = totalEarnings;
            currentCalculationData.financials.total_deductions = totalDeductions; // Store total for consistency
            currentCalculationData.financials.net_salary = netSalary;
        }

        // 3. Save Final Data
        $('#btn-save').on('click', function() {
            if (!currentCalculationData) return;

            Swal.fire({
                title: 'Confirm Generation?',
                text: "Net Salary: RM " + currentCalculationData.financials.net_salary.toFixed(2),
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#16a34a',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, Save it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.post('save_salary.php', { data: JSON.stringify(currentCalculationData) }, function(res) {
                        if (res.status === 'success') {
                            Swal.fire({
                                title: 'Success!', 
                                text: 'Payslip generated successfully.', 
                                icon: 'success'
                            }).then(() => {
                                // Reload to clear form or redirect to view employee
                                window.location.href = 'view_employee.php?id=' + currentCalculationData.employee_id;
                            });
                        } else {
                            Swal.fire('Error', res.message, 'error');
                        }
                    }, 'json');
                }
            });
        });
    </script>
</body>
</html>