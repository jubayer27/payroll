<?php
// admin/view_attendance.php
session_start();
require_once '../config/db.php';

// 1. Security & Settings
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}
date_default_timezone_set('Asia/Kuala_Lumpur');

// 2. Filter Inputs
$dateFilter = $_GET['date'] ?? date('Y-m-d');
$nameFilter = $_GET['search'] ?? '';

// 3. DATA FETCHING STRATEGY
// A. Get All Active Employees
$sqlEmp = "SELECT id, first_name, last_name, department, employment_type FROM employees WHERE status='active'";
if (!empty($nameFilter)) {
    $sqlEmp .= " AND (first_name LIKE '%$nameFilter%' OR last_name LIKE '%$nameFilter%')";
}
$sqlEmp .= " ORDER BY first_name ASC";
$employees = $conn->query($sqlEmp)->fetchAll(PDO::FETCH_ASSOC);

// B. Get Attendance Logs for Date
// FIX: Select employee_id first so the grouping works correctly
$sqlLog = "SELECT employee_id, scanned_at, type, status FROM attendance WHERE DATE(scanned_at) = ?";
$stmtLog = $conn->prepare($sqlLog);
$stmtLog->execute([$dateFilter]);
$logs = $stmtLog->fetchAll(PDO::FETCH_GROUP | PDO::FETCH_ASSOC); // Now groups by employee_id

// C. Get Approved Leaves for Date
$sqlLeave = "SELECT employee_id FROM leaves WHERE ? BETWEEN from_date AND to_date AND status='approved'";
$stmtLeave = $conn->prepare($sqlLeave);
$stmtLeave->execute([$dateFilter]);
$leaves = $stmtLeave->fetchAll(PDO::FETCH_COLUMN); // Array of IDs on leave

// 4. Process & Merge Data
$attendance_list = [];

foreach ($employees as $emp) {
    $id = $emp['id'];
    $emp_logs = $logs[$id] ?? [];
    
    // Default State
    $row = [
        'id' => $id,
        'name' => $emp['first_name'] . ' ' . $emp['last_name'],
        'department' => $emp['department'],
        'clock_in' => '-',
        'lunch_out' => '-',
        'lunch_in' => '-',
        'clock_out' => '-',
        'status' => 'Absent', // Default to absent
        'status_color' => 'bg-red-100 text-red-700',
        'is_late' => false
    ];

    // Check if On Leave
    if (in_array($id, $leaves)) {
        $row['status'] = 'On Leave';
        $row['status_color'] = 'bg-blue-100 text-blue-700';
    }

    // Process Scans
    if (!empty($emp_logs)) {
        $row['status'] = 'Present'; // Has at least one scan
        $row['status_color'] = 'bg-green-100 text-green-700';

        foreach ($emp_logs as $log) {
            $time = date('h:i A', strtotime($log['scanned_at']));
            
            if ($log['type'] === 'morning') {
                $row['clock_in'] = $time;
                if ($log['status'] === 'late') {
                    $row['is_late'] = true;
                    $row['status'] = 'Late';
                    $row['status_color'] = 'bg-yellow-100 text-yellow-800';
                }
            } elseif ($log['type'] === 'lunch_start') {
                $row['lunch_out'] = $time;
            } elseif ($log['type'] === 'lunch_end') {
                $row['lunch_in'] = $time;
            } elseif ($log['type'] === 'leave') { // 'leave' type in attendance table means Clock Out
                $row['clock_out'] = $time;
            }
        }
    }
    
    // Hide Absent status for future dates
    if ($dateFilter > date('Y-m-d') && $row['status'] === 'Absent') {
        $row['status'] = '-';
        $row['status_color'] = 'bg-gray-100 text-gray-500';
    }

    $attendance_list[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Daily Attendance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-gray-100 flex font-sans">

    <?php include 'includes/sidebar.php'; ?>

    <main class="flex-1 p-8 h-screen overflow-y-auto">
        
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
            <div>
                <h1 class="text-2xl font-bold text-gray-800">Daily Attendance Log</h1>
                <p class="text-sm text-gray-500">Overview for <span class="font-bold text-blue-600"><?php echo date('d F Y', strtotime($dateFilter)); ?></span></p>
            </div>
            
            <form method="GET" class="flex flex-col md:flex-row gap-2 bg-white p-2 rounded shadow-sm">
                <input type="date" name="date" value="<?php echo $dateFilter; ?>" 
                       class="border border-gray-300 rounded px-3 py-2 text-gray-700 text-sm focus:outline-blue-500">
                
                <input type="text" name="search" value="<?php echo htmlspecialchars($nameFilter); ?>" placeholder="Search Employee..." 
                       class="border border-gray-300 rounded px-3 py-2 text-gray-700 text-sm w-48 focus:outline-blue-500">
                
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 text-sm font-bold transition">
                    Filter
                </button>
                
                <?php if($nameFilter || $dateFilter != date('Y-m-d')): ?>
                    <a href="view_attendance.php" class="bg-gray-200 text-gray-600 px-3 py-2 rounded hover:bg-gray-300 text-sm font-bold transition flex items-center justify-center">Reset</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="bg-white rounded-lg shadow overflow-hidden border border-gray-200">
            <table class="min-w-full leading-normal">
                <thead>
                    <tr class="bg-gray-50 text-gray-600 uppercase text-xs border-b">
                        <th class="px-5 py-3 text-left font-bold">Employee</th>
                        <th class="px-5 py-3 text-left font-bold text-green-700">Clock In</th>
                        <th class="px-5 py-3 text-center font-bold text-yellow-700 bg-yellow-50 border-l border-r border-yellow-100">
                            Lunch <span class="text-[10px] text-gray-400 font-normal block">(Out &rarr; In)</span>
                        </th>
                        <th class="px-5 py-3 text-left font-bold text-red-700">Clock Out</th>
                        <th class="px-5 py-3 text-center font-bold">Status</th>
                        <th class="px-5 py-3 text-right font-bold">Action</th>
                    </tr>
                </thead>
                <tbody class="text-sm divide-y divide-gray-100">
                    <?php if (count($attendance_list) > 0): ?>
                        <?php foreach ($attendance_list as $row): ?>
                        <tr class="hover:bg-gray-50 transition group">
                            <td class="px-5 py-4">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0 w-10 h-10 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-sm">
                                        <?= substr($row['name'], 0, 1) ?>
                                    </div>
                                    <div class="ml-3">
                                        <p class="text-gray-900 font-bold whitespace-no-wrap"><?= htmlspecialchars($row['name']) ?></p>
                                        <p class="text-gray-500 text-xs"><?= htmlspecialchars($row['department']) ?></p>
                                    </div>
                                </div>
                            </td>

                            <td class="px-5 py-4">
                                <span class="font-mono font-bold text-green-700 bg-green-50 px-2 py-1 rounded border border-green-100">
                                    <?= $row['clock_in'] ?>
                                </span>
                            </td>

                            <td class="px-5 py-4 text-center bg-yellow-50/30 border-l border-r border-gray-100">
                                <div class="inline-flex items-center text-xs font-mono text-yellow-800 bg-yellow-100 px-2 py-1 rounded">
                                    <span><?= $row['lunch_out'] ?></span>
                                    <span class="mx-2 text-gray-400">&rarr;</span>
                                    <span><?= $row['lunch_in'] ?></span>
                                </div>
                            </td>

                            <td class="px-5 py-4">
                                <span class="font-mono font-bold text-red-700 bg-red-50 px-2 py-1 rounded border border-red-100">
                                    <?= $row['clock_out'] ?>
                                </span>
                            </td>

                            <td class="px-5 py-4 text-center">
                                <span class="<?= $row['status_color'] ?> px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide">
                                    <?= $row['status'] ?>
                                </span>
                            </td>

                            <td class="px-5 py-4 text-right">
                                <button onclick="openManualEntry('<?= $row['id'] ?>', '<?= htmlspecialchars($row['name']) ?>')" 
                                        class="text-blue-600 hover:text-blue-900 bg-blue-50 hover:bg-blue-100 p-2 rounded transition" 
                                        title="Manual Update">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="6" class="px-5 py-8 text-center text-gray-400">No employees found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

    <script>
    function openManualEntry(empId, empName) {
        Swal.fire({
            title: 'Manual Attendance Update',
            html: `
                <div class="text-left mb-4">
                    <p class="text-sm text-gray-500">Employee:</p>
                    <p class="font-bold text-gray-800">${empName}</p>
                    <p class="text-sm text-gray-500 mt-1">Date:</p>
                    <p class="font-bold text-gray-800"><?php echo $dateFilter; ?></p>
                </div>
                <form id="manualForm" class="space-y-3 text-left">
                    <div>
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Scan Type</label>
                        <select id="type" class="w-full border rounded p-2 bg-gray-50">
                            <option value="morning">Clock In (Morning)</option>
                            <option value="lunch_start">Lunch OUT</option>
                            <option value="lunch_end">Lunch IN</option>
                            <option value="leave">Clock Out (End of Day)</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Time</label>
                        <input type="time" id="time" class="w-full border rounded p-2" value="09:00">
                    </div>
                </form>
            `,
            showCancelButton: true,
            confirmButtonText: 'Update Record',
            confirmButtonColor: '#2563eb',
            preConfirm: () => {
                const type = Swal.getPopup().querySelector('#type').value;
                const time = Swal.getPopup().querySelector('#time').value;
                if (!time) {
                    Swal.showValidationMessage('Please select a time');
                }
                return { type: type, time: time }
            }
        }).then((result) => {
            if (result.isConfirmed) {
                // Send AJAX Request
                $.post('api_manual_entry.php', {
                    employee_id: empId,
                    date: '<?php echo $dateFilter; ?>',
                    type: result.value.type,
                    time: result.value.time
                }, function(response) {
                    if (response.status === 'success') {
                        Swal.fire('Success', response.message, 'success').then(() => location.reload());
                    } else {
                        Swal.fire('Error', response.message, 'error');
                    }
                }, 'json').fail(() => {
                    Swal.fire('Error', 'Server error', 'error');
                });
            }
        });
    }
    </script>

</body>
</html>