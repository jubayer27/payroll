<?php
// admin/manage_requests.php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    die("Access Denied");
}

// Fetch Pending Requests
$sql = "SELECT r.*, e.first_name, e.last_name, e.department 
        FROM requests r 
        JOIN employees e ON r.employee_id = e.id 
        WHERE r.status = 'pending' 
        ORDER BY r.created_at DESC";
$requests = $conn->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Requests</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body class="bg-gray-100 flex font-sans">
    
    <?php include 'includes/sidebar.php'; ?>

    <main class="flex-1 p-8 h-screen overflow-y-auto">
        <h1 class="text-2xl font-bold text-gray-800 mb-6">Pending Requests</h1>

        <div class="grid gap-4">
            <?php foreach($requests as $req): 
                $data = json_decode($req['request_data'], true);
                $typeLabel = str_replace('_', ' ', strtoupper($req['type']));
                
                $color = match($req['type']) {
                    'attendance_correction' => 'border-blue-500 bg-blue-50',
                    'leave' => 'border-green-500 bg-green-50',
                    default => 'border-purple-500 bg-purple-50'
                };

                // Safe JSON encoding for HTML attribute
                $reqJson = htmlspecialchars(json_encode($req), ENT_QUOTES, 'UTF-8');
                $dataJson = htmlspecialchars(json_encode($data), ENT_QUOTES, 'UTF-8');
            ?>
            <div class="bg-white rounded-lg shadow border-l-4 <?= $color ?> p-6 flex justify-between items-center">
                <div>
                    <div class="flex items-center gap-2 mb-1">
                        <span class="text-xs font-bold px-2 py-1 rounded bg-gray-200 text-gray-700"><?= $typeLabel ?></span>
                        <span class="text-gray-400 text-xs"><?= date('d M H:i', strtotime($req['created_at'])) ?></span>
                    </div>
                    <h3 class="font-bold text-lg"><?= htmlspecialchars($req['first_name'] . ' ' . $req['last_name']) ?></h3>
                    <p class="text-gray-600 text-sm italic">"<?= htmlspecialchars($req['reason']) ?>"</p>
                    
                    <div class="mt-2 text-sm text-gray-800">
                        <?php if($req['type'] == 'attendance_correction'): ?>
                            Request to: <strong><?= ucfirst(str_replace('_', ' ', $data['scan_type'])) ?></strong> at <strong><?= $data['time'] ?></strong> on <?= $data['date'] ?>
                        <?php elseif($req['type'] == 'leave'): ?>
                            <strong><?= ucfirst($data['leave_type']) ?></strong>: <?= $data['from_date'] ?> to <?= $data['to_date'] ?>
                        <?php elseif($req['type'] == 'schedule_switch'): ?>
                            Work on: <strong><?= $data['work_date'] ?></strong>, Off on: <strong><?= $data['off_date'] ?></strong>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="flex gap-2">
                    <button onclick='openActionModal(<?= $reqJson ?>, <?= $dataJson ?>)' class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 font-bold text-sm">Review</button>
                </div>
            </div>
            <?php endforeach; ?>

            <?php if(empty($requests)): ?>
                <div class="text-center text-gray-400 py-10">No pending requests.</div>
            <?php endif; ?>
        </div>
    </main>

    <div id="actionModal" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50">
        <div class="bg-white rounded-lg shadow-xl w-full max-w-lg p-6">
            <h2 class="text-xl font-bold mb-4 border-b pb-2">Process Request</h2>
            
            <form id="processForm">
                <input type="hidden" name="request_id" id="modal_req_id">
                <input type="hidden" name="type" id="modal_req_type">
                <input type="hidden" name="employee_id" id="modal_emp_id">

                <div id="modalContent" class="space-y-4 mb-6">
                    </div>

                <div class="mb-4">
                    <label class="block text-sm font-bold text-gray-700">Admin Comment (Optional)</label>
                    <input type="text" name="admin_comment" class="w-full border rounded p-2">
                </div>

                <div class="flex justify-end gap-3">
                    <button type="button" onclick="$('#actionModal').addClass('hidden')" class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded">Cancel</button>
                    <button type="submit" name="status" value="rejected" class="px-4 py-2 bg-red-100 text-red-600 hover:bg-red-200 rounded font-bold">Reject</button>
                    <button type="submit" name="status" value="approved" class="px-4 py-2 bg-green-600 text-white hover:bg-green-700 rounded font-bold">Approve & Update</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openActionModal(req, data) {
            $('#modal_req_id').val(req.id);
            $('#modal_req_type').val(req.type);
            $('#modal_emp_id').val(req.employee_id);

            let html = '';

            // Handle Null Data gracefully
            if(!data) data = {};

            if (req.type === 'attendance_correction') {
                html = `
                    <div class="bg-blue-50 p-2 rounded mb-2 text-xs text-blue-700">Review the time before approving.</div>
                    <div><label class="text-xs font-bold uppercase text-gray-500">Date</label>
                    <input type="date" name="final_date" value="${data.date || ''}" class="w-full border p-2 rounded"></div>
                    <div><label class="text-xs font-bold uppercase text-gray-500">Time</label>
                    <input type="time" name="final_time" value="${data.time || ''}" class="w-full border p-2 rounded"></div>
                    <div><label class="text-xs font-bold uppercase text-gray-500">Type</label>
                    <select name="final_scan_type" class="w-full border p-2 rounded bg-white">
                        <option value="morning" ${data.scan_type=='morning'?'selected':''}>Clock In</option>
                        <option value="lunch_start" ${data.scan_type=='lunch_start'?'selected':''}>Lunch Out</option>
                        <option value="lunch_end" ${data.scan_type=='lunch_end'?'selected':''}>Lunch In</option>
                        <option value="leave" ${data.scan_type=='leave'?'selected':''}>Clock Out</option>
                    </select></div>
                `;
            } else if (req.type === 'leave') {
                html = `
                    <div><label class="text-xs font-bold uppercase text-gray-500">Leave Type</label>
                    <input type="text" name="final_leave_type" value="${data.leave_type || ''}" class="w-full border p-2 rounded" readonly></div>
                    <div class="grid grid-cols-2 gap-2">
                        <div><label class="text-xs font-bold uppercase text-gray-500">From</label>
                        <input type="date" name="final_from" value="${data.from_date || ''}" class="w-full border p-2 rounded"></div>
                        <div><label class="text-xs font-bold uppercase text-gray-500">To</label>
                        <input type="date" name="final_to" value="${data.to_date || ''}" class="w-full border p-2 rounded"></div>
                    </div>
                `;
            } else if (req.type === 'schedule_switch') {
                html = `
                    <div class="grid grid-cols-2 gap-2">
                        <div><label class="text-xs font-bold uppercase text-gray-500">Work On</label>
                        <input type="date" name="final_work_date" value="${data.work_date || ''}" class="w-full border p-2 rounded"></div>
                        <div><label class="text-xs font-bold uppercase text-gray-500">Off On</label>
                        <input type="date" name="final_off_date" value="${data.off_date || ''}" class="w-full border p-2 rounded"></div>
                    </div>
                `;
            } else if (req.type === 'part_time_change') {
                let days = data.days ? data.days.join(',') : '';
                html = `<p class="text-sm text-gray-600 mb-2">Part Time Update Requested.</p>
                <div><label class="text-xs font-bold">Days (1=Mon, 7=Sun)</label><input type="text" name="final_days" value="${days}" class="w-full border p-2 rounded"></div>
                <div class="grid grid-cols-2 gap-2 mt-2">
                    <div><label class="text-xs font-bold">Start</label><input type="time" name="final_start" value="${data.pt_start || ''}" class="w-full border p-2 rounded"></div>
                    <div><label class="text-xs font-bold">End</label><input type="time" name="final_end" value="${data.pt_end || ''}" class="w-full border p-2 rounded"></div>
                </div>`;
            }

            $('#modalContent').html(html);
            $('#actionModal').removeClass('hidden');
        }

        // Handle Approval/Rejection AJAX
        $('#processForm').on('click', 'button[type=submit]', function(e) {
            e.preventDefault();
            const status = $(this).val();
            const formData = $('#processForm').serialize() + '&status=' + status;

            $.post('api_request_handler.php?action=process', formData, function(res) {
                if(res.status === 'success') {
                    Swal.fire('Success', res.message, 'success').then(() => location.reload());
                } else {
                    Swal.fire('Error', res.message, 'error');
                }
            }, 'json').fail(function(xhr, status, error) {
                Swal.fire('Server Error', xhr.responseText || error, 'error');
            });
        });
    </script>
</body>
</html>