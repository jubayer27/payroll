<?php
// admin/calendar_action.php
require_once '../config/db.php';
header('Content-Type: application/json');

$action = $_REQUEST['action'] ?? '';

try {
    // 1. FETCH EVENTS
    if ($action == 'fetch') {
        $stmt = $conn->query("SELECT id, title, start, color FROM holidays");
        $events = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($events);
        exit;
    }

    // 2. ADD EVENT
    if ($action == 'add' && $_SERVER['REQUEST_METHOD'] == 'POST') {
        $title = $_POST['title'];
        $start = $_POST['start'];
        $color = '#ef4444'; // Default red for holidays

        $stmt = $conn->prepare("INSERT INTO holidays (title, start, color) VALUES (?, ?, ?)");
        $stmt->execute([$title, $start, $color]);

        echo json_encode(['status' => 'success']);
        exit;
    }

    // 3. DELETE EVENT
    if ($action == 'delete' && $_SERVER['REQUEST_METHOD'] == 'POST') {
        $id = $_POST['id'];
        $stmt = $conn->prepare("DELETE FROM holidays WHERE id = ?");
        $stmt->execute([$id]);
        
        echo json_encode(['status' => 'success']);
        exit;
    }

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>