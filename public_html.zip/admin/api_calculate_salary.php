<?php
// admin/api_calculate_salary.php
require_once '../config/db.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Request']);
    exit;
}

$empId = $_POST['employee_id'];
$month = $_POST['month']; // YYYY-MM
$input_sales = floatval($_POST['sales_amount'] ?? 0);
$input_claims = floatval($_POST['claims'] ?? 0);
$input_bonus = floatval($_POST['bonus'] ?? 0);

if (!$empId || !$month) {
    echo json_encode(['status' => 'error', 'message' => 'Missing Employee or Month']);
    exit;
}

// ---------------------------------------------------
// 1. FETCH DATA
// ---------------------------------------------------

// A. Employee Details
$stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
$stmt->execute([$empId]);
$emp = $stmt->fetch(PDO::FETCH_ASSOC);

// B. Global Salary Rules
$rules = $conn->query("SELECT * FROM salary_rules LIMIT 1")->fetch(PDO::FETCH_ASSOC);

// C. Date Range
$start_date = "$month-01";
$end_date = date("Y-m-t", strtotime($start_date));

// ---------------------------------------------------
// 2. ANALYZE ATTENDANCE & ROSTER
// ---------------------------------------------------

$total_days_in_month = date('t', strtotime($start_date));
$scheduled_work_days = 0;
$days_worked = 0;
$days_absent = 0;
$total_late_minutes = 0;
$late_occasions = 0;

// Fetch Attendance Logs
$stmtLogs = $conn->prepare("SELECT * FROM attendance WHERE employee_id = ? AND DATE(scanned_at) BETWEEN ? AND ?");
$stmtLogs->execute([$empId, $start_date, $end_date]);
$logs = $stmtLogs->fetchAll(PDO::FETCH_GROUP | PDO::FETCH_ASSOC); // Group by Date

// Fetch Roster Adjustments
$stmtAdj = $conn->prepare("SELECT * FROM schedule_adjustments WHERE employee_id = ? AND adjustment_date BETWEEN ? AND ?");
$stmtAdj->execute([$empId, $start_date, $end_date]);
$adjustments = [];
while ($row = $stmtAdj->fetch(PDO::FETCH_ASSOC)) {
    $adjustments[$row['adjustment_date']] = $row['type'];
}

// Fetch Approved Leaves
$stmtLeaves = $conn->prepare("SELECT * FROM leaves WHERE employee_id = ? AND status = 'approved' AND (from_date <= ? AND to_date >= ?)");
$stmtLeaves->execute([$empId, $end_date, $start_date]);
$leaves = $stmtLeaves->fetchAll(PDO::FETCH_ASSOC);

// --- DAY-BY-DAY LOOP ---
$current = strtotime($start_date);
$end = strtotime($end_date);

while ($current <= $end) {
    $dateStr = date('Y-m-d', $current);
    $dayOfWeek = date('N', $current);

    // 1. Determine if this is a Working Day
    $default_days = explode(',', $emp['work_days']);
    $isWorkingDay = in_array($dayOfWeek, $default_days);
    
    // Check Override
    if (isset($adjustments[$dateStr])) {
        $isWorkingDay = ($adjustments[$dateStr] === 'work');
    }

    if ($isWorkingDay) {
        $scheduled_work_days++;

        // 2. Check Attendance
        $scans = [];
        // Extract time from logs (re-querying array locally)
        foreach($logs as $log) {
            if(date('Y-m-d', strtotime($log['scanned_at'])) == $dateStr) {
                $scans[] = $log;
            }
        }
        // *Correction*: The fetchAll above might group by ID, let's simplify logic:
        // Re-filter the logs array for this specific date
        $dayLogs = array_filter($logs, function($log) use ($dateStr) {
             // Depending on FETCH_GROUP, structure varies. Let's assume flat fetch for simplicity in loop
             return false; 
        }); 
        
        // Actually, let's fix the Log Fetching for easier looping
        $dayHasLog = false;
        $dayIsLate = false;
        
        // Simple Query for specific day check (easier logic)
        $chk = $conn->prepare("SELECT * FROM attendance WHERE employee_id = ? AND DATE(scanned_at) = ?");
        $chk->execute([$empId, $dateStr]);
        $dayScan = $chk->fetchAll();

        if (count($dayScan) > 0) {
            $days_worked++;
            // Check Late
            foreach($dayScan as $s) {
                if ($s['type'] == 'morning' && $s['status'] == 'late') {
                    $dayIsLate = true;
                    
                    // Calculate Minutes Late (Assuming 10am start if not set)
                    $scanTime = strtotime($s['scanned_at']);
                    $shiftStart = strtotime($dateStr . ' ' . ($emp['shift_start'] ?? $rules['work_start_time']));
                    // Add buffer
                    $shiftStartWithBuffer = $shiftStart + ($rules['allow_early_punch_minutes'] * 60); 
                    
                    if ($scanTime > $shiftStart) {
                         $diff = ($scanTime - $shiftStart) / 60;
                         $total_late_minutes += $diff;
                    }
                    $late_occasions++;
                }
            }
        } else {
            // Absent? Check if on Leave
            $isOnLeave = false;
            foreach($leaves as $leave) {
                if ($dateStr >= $leave['from_date'] && $dateStr <= $leave['to_date']) {
                    $isOnLeave = true;
                    break;
                }
            }

            if (!$isOnLeave) {
                $days_absent++;
            }
        }
    }
    
    $current = strtotime('+1 day', $current);
}

// ---------------------------------------------------
// 3. CALCULATE FINANCIALS
// ---------------------------------------------------

// Rates
$basic = floatval($emp['salary_amount']);
$transport = floatval($emp['transport_allowance']);

// A. Earnings
$earned_basic = $basic;
$calc_commission = ($input_sales * floatval($rules['salesperson_commission'])) / 100;
$perf_bonus = 0;

// Logic: Prorate for Part-Timers OR Full-Timers with absences
if ($emp['employment_type'] === 'part_time') {
    // Part time: Basic is actually Hourly Rate usually, but if stored as fixed, we might need manual calc.
    // Assuming 'salary_amount' for part time is HOURLY RATE based on previous context
    // Let's assume 8 hours per day worked for estimation, or stick to Fixed if type is fixed.
    if ($emp['salary_type'] == 'hourly') {
        // Simple calc: Days Worked * 8 hours * Rate (You can enhance this with exact hours)
        $earned_basic = $days_worked * 8 * $basic; 
    }
} else {
    // Full Time: Deduction for unpaid absences
    if ($days_absent > 0) {
        $daily_rate = $basic / ($scheduled_work_days > 0 ? $scheduled_work_days : 26);
        $deduction_amt = $days_absent * $daily_rate;
        // Rules say double penalty?
        if ($rules['double_absence_penalty'] > 0) {
            // If the rule is a fixed amount penalty
            // $deduction_amt += ($days_absent * $rules['double_absence_penalty']); 
            
            // OR if the rule implies "Double Pay Deduction"
            $deduction_amt = $days_absent * $daily_rate * 2;
        }
        $earned_basic -= $deduction_amt;
    }
}

// Perfect Attendance (Only if 0 Late, 0 Absent)
if ($late_occasions == 0 && $days_absent == 0 && $days_worked > 0) {
    $perf_bonus = floatval($rules['perfect_attendance_bonus']);
}

// B. Deductions
$late_fine_amt = 0;
if ($total_late_minutes > 0) {
    // Round up to nearest 5 mins
    $blocks = ceil($total_late_minutes / 5);
    $late_fine_amt = $blocks * $rules['late_fine_per_5min'];
}

// C. Totals
$total_earnings = $earned_basic + $transport + $input_claims + $input_bonus + $calc_commission + $perf_bonus;
$total_deductions = $late_fine_amt; // Note: Absenteeism usually reduces Basic, doesn't add to deductions column visually, but we can separate if needed.

$net_salary = $total_earnings - $total_deductions;

// ---------------------------------------------------
// 4. PREPARE RESPONSE
// ---------------------------------------------------

$data = [
    'employee_id' => $empId,
    'month' => $month,
    'month_display' => date('F Y', strtotime($start_date)),
    'financials' => [
        'basic_salary' => round($earned_basic, 2),
        'transport_allowance' => $transport,
        'claims' => $input_claims,
        'manual_bonus' => $input_bonus,
        'commission' => round($calc_commission, 2),
        'perfect_attendance' => $perf_bonus,
        'ot_pay' => 0, // Implement OT logic if needed
        
        'late_deduction' => round($late_fine_amt, 2),
        'absent_deduction' => 0, // Already deducted from basic, or add specific fine here
        'leave_without_notice_fine' => 0,
        'rejected_leave_fine' => 0,
        'advance_salary' => 0,
        
        'gross_salary' => round($total_earnings, 2),
        'total_deductions' => round($total_deductions, 2),
        'net_salary' => round($net_salary, 2)
    ],
    'stats' => [
        'work_days' => $scheduled_work_days,
        'worked' => $days_worked,
        'absent' => $days_absent,
        'late_mins' => $total_late_minutes
    ]
];

// Generate HTML Preview
ob_start();
?>
<div class="border rounded p-4 bg-gray-50 text-sm">
    <div class="flex justify-between mb-2">
        <span>Working Days:</span> <span class="font-bold"><?= $data['stats']['work_days'] ?></span>
    </div>
    <div class="flex justify-between mb-2">
        <span>Days Present:</span> <span class="font-bold text-green-600"><?= $data['stats']['worked'] ?></span>
    </div>
    <div class="flex justify-between mb-2">
        <span>Days Absent:</span> <span class="font-bold text-red-600"><?= $data['stats']['absent'] ?></span>
    </div>
    <div class="flex justify-between mb-4 border-b pb-2">
        <span>Late Minutes:</span> <span class="font-bold text-yellow-600"><?= number_format($data['stats']['late_mins']) ?></span>
    </div>

    <h4 class="font-bold text-gray-700 mb-2">Earnings</h4>
    <div class="grid grid-cols-2 gap-2 mb-2">
        <label>Basic Salary</label>
        <input type="number" class="calc-input border rounded px-1 text-right" data-field="basic_salary" value="<?= $data['financials']['basic_salary'] ?>">
    </div>
    <div class="grid grid-cols-2 gap-2 mb-2">
        <label>Transport</label>
        <input type="number" class="calc-input border rounded px-1 text-right" data-field="transport_allowance" value="<?= $data['financials']['transport_allowance'] ?>">
    </div>
    <div class="grid grid-cols-2 gap-2 mb-2">
        <label>Commission</label>
        <input type="number" class="calc-input border rounded px-1 text-right" data-field="commission" value="<?= $data['financials']['commission'] ?>">
    </div>
    <div class="grid grid-cols-2 gap-2 mb-2">
        <label class="text-green-600">Perf. Bonus</label>
        <input type="number" class="calc-input border rounded px-1 text-right" data-field="perfect_attendance" value="<?= $data['financials']['perfect_attendance'] ?>">
    </div>

    <h4 class="font-bold text-gray-700 mt-4 mb-2">Deductions</h4>
    <div class="grid grid-cols-2 gap-2 mb-2">
        <label class="text-red-600">Late Fine</label>
        <input type="number" class="calc-input border rounded px-1 text-right" data-field="late_deduction" value="<?= $data['financials']['late_deduction'] ?>">
    </div>
    <div class="grid grid-cols-2 gap-2 mb-2">
        <label>Absent Fine</label>
        <input type="number" class="calc-input border rounded px-1 text-right" data-field="absent_deduction" value="<?= $data['financials']['absent_deduction'] ?>">
    </div>
</div>
<?php
$html = ob_get_clean();

echo json_encode([
    'status' => 'success',
    'data' => $data,
    'html' => $html
]);
?>