<?php
// admin/roster.php
session_start();
require_once '../config/db.php';

// Fetch Active Employees for the dropdown
$emps = $conn->query("SELECT id, first_name, last_name, employment_type FROM employees WHERE status='active' ORDER BY first_name ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Roster</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .day-card.working { background-color: #dcfce7; border-color: #22c55e; } /* Green */
        .day-card.off { background-color: #f3f4f6; border-color: #d1d5db; opacity: 0.8; } /* Gray */
    </style>
</head>
<body class="bg-gray-100 flex font-sans">
    
    <?php include 'includes/sidebar.php'; ?>

    <main class="flex-1 p-8 h-screen overflow-y-auto">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-bold text-gray-800">Roster & Shift Management</h1>
        </div>

        <div class="bg-white p-6 rounded-lg shadow mb-6">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-1">Select Employee</label>
                    <select id="employee_id" class="w-full border rounded px-3 py-2 bg-white">
                        <option value="">-- Choose Employee --</option>
                        <?php foreach($emps as $e): ?>
                            <option value="<?= $e['id'] ?>">
                                <?= $e['first_name'] . ' ' . $e['last_name'] ?> (<?= ucfirst($e['employment_type']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-1">Select Month</label>
                    <input type="month" id="month" value="<?= date('Y-m') ?>" class="w-full border rounded px-3 py-2">
                </div>
                <div class="flex items-end">
                    <button id="btn-load" class="bg-blue-600 text-white font-bold py-2 px-6 rounded hover:bg-blue-700 w-full">
                        Load Schedule
                    </button>
                </div>
            </div>
        </div>

        <div id="roster-view" class="hidden">
            
            <div class="bg-white p-4 rounded-lg shadow mb-6 sticky top-0 z-10 border-b-4 border-blue-500">
                <div class="flex flex-col md:flex-row justify-between items-center gap-4">
                    <div class="flex items-center gap-4">
                        <label class="font-bold text-gray-700">Apply Changes As:</label>
                        <div class="flex items-center gap-2">
                            <input type="radio" name="change_type" value="temporary" id="type_temp" checked class="w-4 h-4">
                            <label for="type_temp" class="text-sm">Temporary (Selected Dates Only)</label>
                        </div>
                        <div class="flex items-center gap-2">
                            <input type="radio" name="change_type" value="permanent" id="type_perm" class="w-4 h-4">
                            <label for="type_perm" class="text-sm font-bold text-red-600">Permanent (Update Profile)</label>
                        </div>
                    </div>
                    <button id="btn-save" class="bg-green-600 text-white font-bold py-2 px-8 rounded hover:bg-green-700 shadow-lg">
                        Save Changes
                    </button>
                </div>
            </div>

            <div id="calendar-grid" class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                </div>
        </div>

    </main>

    <script>
    $(document).ready(function() {
        
        // 1. LOAD SCHEDULE
        $('#btn-load').click(function() {
            const empId = $('#employee_id').val();
            const month = $('#month').val();

            if(!empId) { Swal.fire('Error', 'Please select an employee', 'error'); return; }

            Swal.fire({title: 'Loading...', didOpen: () => Swal.showLoading()});

            $.post('api_roster_actions.php', { action: 'fetch', employee_id: empId, month: month }, function(res) {
                Swal.close();
                if(res.status === 'success') {
                    renderCalendar(res.data);
                    $('#roster-view').removeClass('hidden');
                } else {
                    Swal.fire('Error', res.message, 'error');
                }
            }, 'json');
        });

        // 2. RENDER GRID
        function renderCalendar(days) {
            const container = $('#calendar-grid');
            container.empty();

            days.forEach(day => {
                const dateObj = new Date(day.date);
                const dayName = dateObj.toLocaleDateString('en-US', { weekday: 'short' });
                const dayNum = dateObj.getDate();
                
                const isWorking = day.is_working;
                const statusClass = isWorking ? 'working' : 'off';
                const checkedAttr = isWorking ? 'checked' : '';
                
                const badge = day.source === 'adjustment' 
                    ? `<span class="absolute top-2 right-2 text-xs bg-yellow-200 text-yellow-800 px-1 rounded">Override</span>` 
                    : '';

                const html = `
                    <div class="day-card ${statusClass} border-2 rounded-lg p-4 relative transition duration-200 cursor-pointer" data-date="${day.date}">
                        ${badge}
                        
                        <div class="flex justify-between items-center mb-2">
                            <div>
                                <span class="text-gray-500 text-xs font-bold uppercase">${dayName}</span>
                                <h3 class="text-xl font-bold text-gray-800">${dayNum}</h3>
                            </div>
                            <input type="checkbox" class="status-toggle w-6 h-6 cursor-pointer" ${checkedAttr}>
                        </div>

                        <div class="space-y-2 mt-2 time-inputs ${isWorking ? '' : 'hidden'}">
                            <div>
                                <label class="text-[10px] text-gray-500 uppercase">Start</label>
                                <input type="time" class="w-full text-sm border rounded px-1 input-start" value="${day.start_time || ''}">
                            </div>
                            <div>
                                <label class="text-[10px] text-gray-500 uppercase">End</label>
                                <input type="time" class="w-full text-sm border rounded px-1 input-end" value="${day.end_time || ''}">
                            </div>
                        </div>
                        
                        <div class="mt-2 text-center text-xs font-bold status-text text-gray-500">
                            ${isWorking ? 'WORKING' : 'OFF DAY'}
                        </div>
                    </div>
                `;
                container.append(html);
            });
        }

        // 3. HANDLE CLICK on CARD
        $(document).on('click', '.day-card', function(e) {
            if ($(e.target).is('input[type="time"]')) return;

            const checkbox = $(this).find('.status-toggle');
            const timeInputs = $(this).find('.time-inputs');
            const statusText = $(this).find('.status-text');

            if (!$(e.target).is('.status-toggle')) {
                checkbox.prop('checked', !checkbox.prop('checked'));
            }

            const isChecked = checkbox.prop('checked');

            if (isChecked) {
                $(this).removeClass('off').addClass('working');
                timeInputs.removeClass('hidden');
                statusText.text('WORKING');
            } else {
                $(this).removeClass('working').addClass('off');
                timeInputs.addClass('hidden');
                statusText.text('OFF DAY');
            }
        });

        // 4. SAVE CHANGES
        $('#btn-save').click(function() {
            const empId = $('#employee_id').val();
            const changeType = $('input[name="change_type"]:checked').val();
            
            let rosterData = [];

            $('.day-card').each(function() {
                const date = $(this).data('date');
                const isWorking = $(this).find('.status-toggle').prop('checked');
                const start = $(this).find('.input-start').val();
                const end = $(this).find('.input-end').val();

                rosterData.push({
                    date: date,
                    is_working: isWorking,
                    start_time: start,
                    end_time: end
                });
            });

            let confirmText = "This will update schedule adjustments for the selected dates.";
            if(changeType === 'permanent') {
                confirmText = "WARNING: This will UPDATE the employee's main profile and clear overrides from this month onwards.";
            }

            Swal.fire({
                title: 'Confirm Save?',
                text: confirmText,
                icon: changeType === 'permanent' ? 'warning' : 'question',
                showCancelButton: true,
                confirmButtonText: 'Yes, Save it'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({title: 'Saving...', didOpen: () => Swal.showLoading()});

                    $.post('api_roster_actions.php', {
                        action: 'save',
                        employee_id: empId,
                        change_type: changeType,
                        roster_data: JSON.stringify(rosterData)
                    }, function(res) {
                        if(res.status === 'success') {
                            Swal.fire({
                                title: 'Saved!',
                                text: res.message,
                                icon: 'success',
                                timer: 1500,
                                showConfirmButton: false
                            }).then(() => {
                                $('#btn-load').click(); // Auto-reload
                            });
                        } else {
                            Swal.fire('Error', res.message, 'error');
                        }
                    }, 'json');
                }
            });
        });

    });
    </script>
</body>
</html>