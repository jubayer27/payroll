<?php
// attender/break.php
session_start();
date_default_timezone_set('Asia/Kuala_Lumpur');
require_once '../config/db.php';

// 1. Security Check
if (!isset($_SESSION['user_role']) || ($_SESSION['user_role'] !== 'breaker' && $_SESSION['user_role'] !== 'admin')) {
    header("Location: ../index.php");
    exit;
}

// 2. Token Generation (AJAX)
if (isset($_POST['action']) && $_POST['action'] === 'generate_token') {
    // Clean old tokens
    $conn->query("DELETE FROM qr_tokens WHERE valid_until < NOW() - INTERVAL 1 MINUTE");

    $token = bin2hex(random_bytes(16));
    $valid_from = date('Y-m-d H:i:s');
    // Short validity for security (15 seconds)
    $valid_until = date('Y-m-d H:i:s', strtotime('+15 seconds')); 
    
    // Tag location as 'lunch_station'
    $stmt = $conn->prepare("INSERT INTO qr_tokens (token, valid_from, valid_until, created_by, location) VALUES (?, ?, ?, ?, 'lunch_station')");
    $stmt->execute([$token, $valid_from, $valid_until, $_SESSION['user_id']]);

    echo json_encode(['status' => 'success', 'token' => $token]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lunch Break Station</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body class="bg-yellow-50 flex flex-col items-center justify-center min-h-screen">

    <a href="../logout.php" class="absolute top-4 right-4 text-gray-500 hover:text-red-600 font-bold text-sm">Logout</a>

    <div class="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md text-center border-t-8 border-yellow-400">
        <h1 class="text-3xl font-bold text-gray-800 mb-2">🍽️ Lunch Station</h1>
        <p class="text-gray-500 mb-6">Scan to start or end your break</p>

        <div class="grid grid-cols-2 gap-4 mb-6">
            <button onclick="setMode('lunch_start')" id="btn-lunch_start" class="type-btn active-btn py-4 px-4 rounded-xl border-2 border-yellow-500 bg-yellow-500 text-white font-bold text-lg transition shadow-md">
                OUT for Lunch
            </button>
            <button onclick="setMode('lunch_end')" id="btn-lunch_end" class="type-btn py-4 px-4 rounded-xl border-2 border-gray-200 text-gray-600 hover:border-yellow-300 font-bold text-lg transition">
                BACK from Lunch
            </button>
        </div>

        <div class="flex justify-center mb-4 relative">
            <div id="qrcode" class="p-4 bg-white border-4 border-gray-800 rounded-lg"></div>
        </div>

        <div class="w-full bg-gray-200 rounded-full h-2.5 mb-4 overflow-hidden">
            <div id="progress-bar" class="bg-yellow-500 h-2.5 rounded-full transition-all duration-1000 ease-linear" style="width: 100%"></div>
        </div>

        <div class="text-sm text-gray-400">
            <p class="mt-1 text-xs">Current Mode: <span id="current-mode-text" class="font-bold text-gray-700">lunch_start</span></p>
        </div>
    </div>

    <script>
        let currentMode = 'lunch_start';
        const REFRESH_TIME = 10; 
        let timeLeft = REFRESH_TIME;

        $(document).ready(function() {
            generateToken();
            startTimer();
        });

        function setMode(mode) {
            currentMode = mode;
            $('.type-btn').removeClass('bg-yellow-500 text-white border-yellow-500 shadow-md').addClass('border-gray-200 text-gray-600');
            $('#btn-' + mode).addClass('bg-yellow-500 text-white border-yellow-500 shadow-md').removeClass('border-gray-200 text-gray-600');
            $('#current-mode-text').text(mode);
            timeLeft = 0; // Force refresh
        }

        function generateToken() {
            $.post('break.php', { action: 'generate_token' }, function(data) {
                try {
                    const res = JSON.parse(data);
                    if (res.status === 'success') {
                        $('#qrcode').empty();
                        new QRCode(document.getElementById("qrcode"), {
                            text: JSON.stringify({ token: res.token, type: currentMode }),
                            width: 200, height: 200,
                            colorDark : "#000000", colorLight : "#ffffff",
                            correctLevel : QRCode.CorrectLevel.L
                        });
                    }
                } catch(e) {}
            });
        }

        function startTimer() {
            setInterval(() => {
                timeLeft--;
                let percent = (timeLeft / REFRESH_TIME) * 100;
                $('#progress-bar').css('width', percent + '%');

                if (timeLeft <= 0) {
                    generateToken();
                    timeLeft = REFRESH_TIME;
                }
            }, 1000);
        }
    </script>
</body>
</html>