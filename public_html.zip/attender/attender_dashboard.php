<?php
// attender_dashboard.php
session_start();
date_default_timezone_set('Asia/Kuala_Lumpur');

require_once '../config/db.php'; 

// AJAX: Generate Token
if (isset($_POST['action']) && $_POST['action'] === 'generate_token') {
    // 1. Cleanup old tokens first to keep DB light
    $conn->query("DELETE FROM qr_tokens WHERE valid_until < NOW()");

    // 2. Create Token
    $token = bin2hex(random_bytes(16));
    $valid_from = date('Y-m-d H:i:s');
    
    // CHANGED: Valid for only 20 SECONDS
    $valid_until = date('Y-m-d H:i:s', strtotime('+20 seconds')); 
    
    $stmt = $conn->prepare("INSERT INTO qr_tokens (token, valid_from, valid_until, created_by, location) VALUES (?, ?, ?, 1, 'main_office')");
    $stmt->execute([$token, $valid_from, $valid_until]);

    echo json_encode(['status' => 'success', 'token' => $token]);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Kiosk</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">

    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        
        /* Button Styles */
        .mode-btn {
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .mode-btn:active { transform: scale(0.95); }
        
        /* Active State */
        .active-mode {
            background: #2563eb; color: white; border: 2px solid #2563eb;
            box-shadow: 0 10px 15px -3px rgba(37, 99, 235, 0.3);
        }
        /* Inactive State */
        .inactive-mode {
            background: white; color: #4b5563; border: 2px solid #e5e7eb;
        }
        .inactive-mode:hover {
            border-color: #2563eb; color: #2563eb;
        }

        /* Smooth Progress Bar */
        .progress-bar { transition: width 1s linear; }
    </style>
</head>
<body class="h-screen w-full flex flex-col lg:flex-row overflow-hidden">
    <a href="../logout.php" class="absolute top-6 left-6 z-20 flex items-center text-gray-400 hover:text-red-600 transition-colors duration-200 group">
    <div class="p-2 rounded-full bg-white border border-gray-200 group-hover:border-red-200 shadow-sm">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
        </svg>
    </div>
    <span class="ml-2 text-sm font-bold opacity-0 group-hover:opacity-100 transition-opacity duration-200 translate-x-[-10px] group-hover:translate-x-0 transform">
        Exit Kiosk
    </span>
</a>

    <div class="w-full lg:w-5/12 bg-white flex flex-col justify-center p-6 lg:p-12 border-b lg:border-b-0 lg:border-r border-gray-200 z-10 shadow-lg lg:shadow-none">
        
        <div class="mb-6 lg:mb-12">
            <div class="flex justify-between items-start">
                <div>
                    <h1 class="text-2xl lg:text-4xl font-extrabold text-gray-900 tracking-tight">Attendance<span class="text-blue-600">Station</span></h1>
                    <p class="text-sm lg:text-lg text-gray-500 mt-1">Select action & scan</p>
                </div>
                <div class="text-right">
                    <div id="live-clock" class="text-xl lg:text-2xl font-mono font-bold text-gray-800">--:--</div>
                    <div class="text-xs font-bold text-gray-400 uppercase tracking-wider"><?php echo date('D, d M'); ?></div>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-2 gap-3 lg:gap-4 flex-grow lg:flex-grow-0">
            <button onclick="setMode('morning')" id="btn-morning" class="mode-btn active-mode py-4 lg:py-8 px-4 rounded-2xl flex flex-col items-center justify-center gap-2">
                <span class="text-2xl lg:text-4xl">🌅</span>
                <span class="font-bold text-sm lg:text-lg">Clock In</span>
            </button>

            <button onclick="setMode('lunch_start')" id="btn-lunch_start" class="mode-btn inactive-mode py-4 lg:py-8 px-4 rounded-2xl flex flex-col items-center justify-center gap-2">
                <span class="text-2xl lg:text-4xl">🍽️</span>
                <span class="font-bold text-sm lg:text-lg">Lunch Out</span>
            </button>

            <button onclick="setMode('lunch_end')" id="btn-lunch_end" class="mode-btn inactive-mode py-4 lg:py-8 px-4 rounded-2xl flex flex-col items-center justify-center gap-2">
                <span class="text-2xl lg:text-4xl">✅</span>
                <span class="font-bold text-sm lg:text-lg">Lunch In</span>
            </button>

            <button onclick="setMode('leave')" id="btn-leave" class="mode-btn inactive-mode py-4 lg:py-8 px-4 rounded-2xl flex flex-col items-center justify-center gap-2">
                <span class="text-2xl lg:text-4xl">👋</span>
                <span class="font-bold text-sm lg:text-lg">Clock Out</span>
            </button>
        </div>
        
        <div class="mt-6 hidden lg:flex items-center text-sm text-gray-400">
            <span class="w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse"></span>
            Main Office &bull; Secure Connection
        </div>
    </div>

    <div class="w-full lg:w-7/12 bg-gray-50 flex flex-col items-center justify-center p-6 relative">
        
        <div class="text-center mb-6 lg:mb-10">
            <p class="text-xs lg:text-sm font-bold text-blue-600 uppercase tracking-widest mb-2">Current Mode</p>
            <h2 id="current-mode-display" class="text-3xl lg:text-5xl font-extrabold text-gray-900 capitalize">Morning In</h2>
        </div>

        <div class="bg-white p-2 rounded-3xl shadow-xl transform transition-all duration-300 hover:scale-105">
            <div id="qrcode" class="p-6 bg-white rounded-2xl border-4 border-gray-100"></div>
        </div>

        <div class="w-64 lg:w-80 mt-8">
            <div class="flex justify-between text-xs font-bold text-gray-400 mb-1 uppercase">
                <span>Security Refresh</span>
                <span id="timer-text">20s</span>
            </div>
            <div class="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                <div id="progress-bar" class="bg-blue-600 h-2 rounded-full progress-bar" style="width: 100%"></div>
            </div>
        </div>

    </div>

    <script>
        let currentMode = 'morning';
        const REFRESH_TIME = 20; // 20 Seconds
        let timeLeft = REFRESH_TIME;
        let timerInterval;

        $(document).ready(function() {
            generateToken();
            startTimer();
            updateClock();
            setInterval(updateClock, 1000);
        });

        // 1. Clock Logic
        function updateClock() {
            const now = new Date();
            const timeString = now.toLocaleTimeString('en-US', { hour12: true, hour: '2-digit', minute: '2-digit' });
            $('#live-clock').text(timeString);
        }

        // 2. Mode Switch Logic
        function setMode(mode) {
            currentMode = mode;
            
            // Visual Updates
            $('.mode-btn').removeClass('active-mode').addClass('inactive-mode');
            $('#btn-' + mode).removeClass('inactive-mode').addClass('active-mode');
            
            let displayText = mode.replace('lunch_', 'Lunch ').replace('_', ' '); 
            if(mode === 'morning') displayText = 'Morning In';
            if(mode === 'leave') displayText = 'Clock Out';
            $('#current-mode-display').text(displayText);

            // Immediate Refresh
            timeLeft = 0; 
        }

        // 3. Token Generation
        function generateToken() {
            $.post('attender_dashboard.php', { action: 'generate_token' }, function(data) {
                try {
                    const res = JSON.parse(data);
                    if (res.status === 'success') {
                        $('#qrcode').empty();
                        
                        const qrData = JSON.stringify({
                            token: res.token,
                            type: currentMode
                        });

                        new QRCode(document.getElementById("qrcode"), {
                            text: qrData,
                            width: window.innerWidth < 768 ? 200 : 280, // Responsive QR Size
                            height: window.innerWidth < 768 ? 200 : 280,
                            colorDark : "#111827",
                            colorLight : "#ffffff",
                            correctLevel : QRCode.CorrectLevel.L // Low correction scans faster
                        });
                    }
                } catch(e) {}
            });
        }

        // 4. Countdown Timer & Progress Bar
        function startTimer() {
            timerInterval = setInterval(() => {
                timeLeft--;
                
                // Update Text
                $('#timer-text').text(timeLeft + 's');

                // Update Bar Width
                let percent = (timeLeft / REFRESH_TIME) * 100;
                $('#progress-bar').css('width', percent + '%');

                // Visual Warning (Red color when low)
                if (timeLeft <= 5) {
                    $('#progress-bar').removeClass('bg-blue-600').addClass('bg-red-500');
                } else {
                    $('#progress-bar').removeClass('bg-red-500').addClass('bg-blue-600');
                }

                // Reset
                if (timeLeft <= 0) {
                    generateToken();
                    timeLeft = REFRESH_TIME;
                }
            }, 1000);
        }
    </script>
</body>
</html>