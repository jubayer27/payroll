</main>
<footer>
  <p style="font-family: Comic Sans MS;
    width: 100%;
    color: white;
    padding-top: 15px">&copy; <?=date('Y')?> Payroll System</p>
</footer>
</body>
</html>
